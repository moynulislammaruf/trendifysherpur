/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Translation {
  en: string;
  bn: string;
}

export interface Review {
  id: string;
  user: string;
  avatar?: string;
  rating: number;
  date: string;
  comment: Translation;
  images?: string[];
}

export interface Question {
  id: string;
  user: string;
  question: Translation;
  answer: Translation;
  date: string;
}

export interface ProductSpec {
  key: Translation;
  value: Translation;
}

export interface Product {
  id: string;
  name: Translation;
  brand: string;
  price: number;
  originalPrice: number; // For discount percentage calculation
  images: string[];
  videoUrl?: string;
  colors?: string[];
  sizes?: string[];
  description: Translation;
  specifications: ProductSpec[];
  reviews: Review[];
  questions: Question[];
  shippingInfo: Translation;
  returnPolicy: Translation;
  category: string; // 'men' | 'women' | 'watches' | 'perfume' | 'mobile-accessories' | 'fashion' | 'gift-items' | 'electronics'
  rating: number;
  reviewsCount: number;
  stockStatus: 'in-stock' | 'low-stock' | 'out-of-stock';
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
  isFlashSale?: boolean;
  flashSaleEndTime?: string; // ISO String
}

export interface CartItem {
  id: string; // composite id: productId_color_size
  product: Product;
  selectedColor?: string;
  selectedSize?: string;
  quantity: number;
}

export interface SavedAddress {
  id: string;
  label: string; // e.g., 'Home', 'Office'
  receiverName: string;
  phone: string;
  district: string;
  upazila: string;
  fullAddress: string;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  altPhone?: string;
  email: string;
  district: string;
  upazila: string;
  address: string;
  note?: string;
}

export interface TrackingStep {
  label: Translation;
  date: string;
  isCompleted: boolean;
  description: Translation;
}

export interface Order {
  id: string;
  date: string;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: CartItem[];
  subtotal: number;
  shippingCharge: number;
  discount: number;
  total: number;
  customerInfo: CustomerInfo;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'rocket' | 'sslcommerz';
  paymentStatus: 'pending' | 'paid';
  trackingSteps: TrackingStep[];
}

export interface AppNotification {
  id: string;
  title: Translation;
  message: Translation;
  date: string;
  isRead: boolean;
  type: 'order' | 'promo' | 'system';
}

export type ActiveView = 
  | 'home' 
  | 'product-details' 
  | 'cart' 
  | 'checkout' 
  | 'account' 
  | 'search-results';
