/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES_LIST, PRODUCTS_DATABASE } from '../data';
import { ProductCard } from '../components/ProductCard';
import { 
  Filter, 
  ChevronDown, 
  SlidersHorizontal, 
  Search, 
  Grid, 
  X,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const SearchView: React.FC = () => {
  const { 
    t, 
    searchQuery, 
    setSearchQuery, 
    selectedCategoryFilter, 
    setSelectedCategoryFilter 
  } = useApp();

  // Faceted filter states
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceMaxRange, setPriceMaxRange] = useState(50000);
  const [minRatingFilter, setMinRatingFilter] = useState(0);
  const [sortBy, setSortBy] = useState<'default' | 'price-low' | 'price-high' | 'rating' | 'latest'>('default');

  // Sidebar toggle state for responsive mobile devices
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Extract all unique brands from products database
  const brandsList = useMemo(() => {
    const list = PRODUCTS_DATABASE.map(p => p.brand);
    return Array.from(new Set(list));
  }, []);

  // Filter & sort logic
  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS_DATABASE];

    // 1. Text Search matches (Title, Brand, Description)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (p) => 
          p.name.en.toLowerCase().includes(q) || 
          p.name.bn.toLowerCase().includes(q) || 
          p.brand.toLowerCase().includes(q) || 
          p.description.en.toLowerCase().includes(q)
      );
    }

    // 2. Category tab select
    if (selectedCategoryFilter !== 'all') {
      result = result.filter((p) => p.category === selectedCategoryFilter);
    }

    // 3. Brand checkboxes select
    if (selectedBrands.length > 0) {
      result = result.filter((p) => selectedBrands.includes(p.brand));
    }

    // 4. Price range constrains
    result = result.filter((p) => p.price <= priceMaxRange);

    // 5. Rating stars filter
    if (minRatingFilter > 0) {
      result = result.filter((p) => p.rating >= minRatingFilter);
    }

    // Sort order preset applications
    if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'latest') {
      // simulate using product original price as secondary differentiator for latest
      result.sort((a, b) => b.originalPrice - a.originalPrice);
    }

    return result;
  }, [searchQuery, selectedCategoryFilter, selectedBrands, priceMaxRange, minRatingFilter, sortBy]);

  const handleBrandToggle = (brand: string) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter((b) => b !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const handleClearAllFilters = () => {
    setSelectedBrands([]);
    setPriceMaxRange(50000);
    setMinRatingFilter(0);
    setSortBy('default');
    setSelectedCategoryFilter('all');
    setSearchQuery('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 select-none">
      
      {/* 1. SEARCH STATUS DETAILS HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 pb-4 border-b border-gray-150 dark:border-zinc-900">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white uppercase tracking-wider">
            {t('Explore and Filter Products', 'পণ্য অনুসন্ধান ও ফিল্টার')}
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            {searchQuery.trim() ? (
              t(
                `Found ${filteredProducts.length} matching items for "${searchQuery}"`,
                `"${searchQuery}" এর জন্য ${filteredProducts.length}টি পণ্য পাওয়া গেছে`
              )
            ) : (
              t(
                `Showing ${filteredProducts.length} matching products`,
                `মোট ${filteredProducts.length}টি পণ্য রয়েছে`
              )
            )}
          </p>
        </div>

        {/* Sorting Dropdown & Mobile filters launcher */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button
            onClick={() => setShowMobileFilters(true)}
            className="md:hidden flex items-center justify-center gap-1.5 px-4 py-2 bg-gray-50 dark:bg-zinc-905 border border-gray-100 rounded-xl text-xs font-bold w-full"
          >
            <SlidersHorizontal size={14} />
            {t('Filters', 'ফিল্টার করুন')}
          </button>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs font-bold text-gray-400 whitespace-nowrap hidden md:inline">{t('Sort By:', 'সাজান:')}</span>
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="px-3.5 py-2 rounded-xl bg-gray-50/50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 text-xs font-semibold text-zinc-900 dark:text-gray-200 focus:outline-none w-full md:w-auto"
            >
              <option value="default">{t('Featured Recommendations', 'সেরা রিকমেন্ডেশন')}</option>
              <option value="price-low">{t('Price: Low to High', 'দাম: কম থেকে বেশি')}</option>
              <option value="price-high">{t('Price: High to Low', 'দাম: বেশি থেকে কম')}</option>
              <option value="rating">{t('Highest Rated Stars', 'শীর্ষ কাস্টমার রিভিউ')}</option>
              <option value="latest">{t('Newest Arrivals', 'নতুন সংযোজন')}</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* --- 2. FACETED SIDEBAR (3 cols) --- */}
        <div className="hidden lg:col-span-3 lg:block bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 rounded-3xl space-y-7">
          <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-800/80 pb-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-900 dark:text-white flex items-center gap-2">
              <Filter size={14} className="text-primary" />
              {t('Faceted Filters', 'ফিল্টার')}
            </h3>
            <button 
              onClick={handleClearAllFilters}
              className="text-[10px] font-bold text-primary hover:underline uppercase"
            >
              {t('Clear All', 'মুছে ফেলুন')}
            </button>
          </div>

          {/* Categories select sidebar list */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t('Categories', 'ক্যাটাগরি')}</span>
            <div className="space-y-1.5">
              <button
                onClick={() => setSelectedCategoryFilter('all')}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${selectedCategoryFilter === 'all' ? 'bg-primary/10 text-primary' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800/50'}`}
              >
                {t('All Collections', 'সকল পণ্য')}
              </button>
              {CATEGORIES_LIST.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategoryFilter(cat.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${selectedCategoryFilter === cat.id ? 'bg-primary/10 text-primary' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800/50'}`}
                >
                  {t(cat.name.en, cat.name.bn)}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range Slider constraint */}
          <div className="space-y-3 pt-4 border-t border-gray-50 dark:border-zinc-800">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t('Max Budget', 'সর্বোচ্চ বাজেট')}</span>
              <span className="text-xs font-extrabold text-primary">৳{priceMaxRange}</span>
            </div>
            <input 
              type="range"
              min={100}
              max={50000}
              step={100}
              value={priceMaxRange}
              onChange={(e) => setPriceMaxRange(parseInt(e.target.value, 10))}
              className="w-full accent-primary h-1 rounded-lg cursor-pointer bg-gray-100 dark:bg-zinc-800"
            />
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>৳100</span>
              <span>৳50,000</span>
            </div>
          </div>

          {/* Brand Checklist checkboxes */}
          <div className="space-y-3 pt-4 border-t border-gray-50 dark:border-zinc-800">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">{t('Brand Names', 'ব্র্যান্ড নেম')}</span>
            <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
              {brandsList.map((brand) => (
                <label key={brand} className="flex items-center gap-2.5 text-xs text-gray-600 dark:text-gray-300 cursor-pointer">
                  <input 
                    type="checkbox"
                    checked={selectedBrands.includes(brand)}
                    onChange={() => handleBrandToggle(brand)}
                    className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary accent-primary"
                  />
                  <span className="font-medium">{brand}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Min rating filter stars selection list */}
          <div className="space-y-3 pt-4 border-t border-gray-50 dark:border-zinc-800">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">{t('Minimum Rating', 'ন্যূনতম কাস্টমার রেটিং')}</span>
            <div className="space-y-2">
              {[4, 3, 2, 0].map((stars) => (
                <button
                  key={stars}
                  onClick={() => setMinRatingFilter(stars)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold w-full transition-all ${minRatingFilter === stars ? 'bg-zinc-950 dark:bg-white text-white dark:text-black shadow-md' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800'}`}
                >
                  {stars === 0 ? (
                    t('Any Rating', 'যেকোনো রেটিং')
                  ) : (
                    <>
                      <div className="flex text-amber-400">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} size={11} fill={i < stars ? 'currentColor' : 'none'} />
                        ))}
                      </div>
                      <span>& {t('Up', 'উর্ধ্বে')}</span>
                    </>
                  )}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* --- 3. DYNAMIC PRODUCTS GRID (9 cols) --- */}
        <div className="lg:col-span-9">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((prod) => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          ) : (
            /* Empty results illustration fallback */
            <div className="text-center py-20 bg-gray-50/50 dark:bg-zinc-900/30 border border-gray-100 dark:border-zinc-850 p-8 rounded-3xl select-none flex flex-col items-center">
              <span className="text-4xl block mb-4 animate-bounce">🔍</span>
              <h3 className="text-sm font-extrabold text-zinc-900 dark:text-white mb-2 uppercase tracking-wide">
                {t('No Matching Products Found', 'কোনো মিল পাওয়া যায়নি')}
              </h3>
              <p className="text-xs text-gray-400 max-w-sm leading-relaxed mb-6">
                {t('Try adjusting price ranges, choosing alternative brand checkboxes, or relaxing category filters.', 'দয়া করে বাজেট একটু বাড়িয়ে অথবা অন্য কোনো ক্যাটাগরি ফিল্টার নির্বাচন করে পুনরায় অনুসন্ধান করুন।')}
              </p>
              
              <button 
                onClick={handleClearAllFilters}
                className="px-5 py-2.5 bg-primary hover:bg-primary-dark text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all"
              >
                {t('Reset Search Criteria', 'ফিল্টার রিসেট করুন')}
              </button>
            </div>
          )}
        </div>

      </div>

      {/* --- MOBILE MODAL FILTERS SLIDEOVER DRAWER PANEL --- */}
      <AnimatePresence>
        {showMobileFilters && (
          <div className="fixed inset-0 z-50 lg:hidden flex justify-end">
            {/* Overlay backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileFilters(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />

            {/* Content drawer body */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="relative w-80 max-w-full h-full bg-white dark:bg-zinc-950 p-6 shadow-2xl flex flex-col justify-between overflow-y-auto"
            >
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-gray-150 dark:border-zinc-900 pb-3">
                  <h3 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                    <Filter size={14} className="text-primary" />
                    {t('Faceted Filters', 'ফিল্টার')}
                  </h3>
                  <button onClick={() => setShowMobileFilters(false)} className="p-1.5 text-gray-400 hover:text-black">
                    <X size={18} />
                  </button>
                </div>

                {/* Mobile Categories lists */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t('Categories', 'ক্যাটাগরি')}</span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => setSelectedCategoryFilter('all')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${selectedCategoryFilter === 'all' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-500'}`}
                    >
                      {t('All', 'সব')}
                    </button>
                    {CATEGORIES_LIST.map(cat => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategoryFilter(cat.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${selectedCategoryFilter === cat.id ? 'bg-primary text-white' : 'bg-gray-100 text-gray-505'}`}
                      >
                        {t(cat.name.en, cat.name.bn)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price max range mobile */}
                <div className="space-y-2 pt-4 border-t border-gray-100 dark:border-zinc-900">
                  <div className="flex justify-between text-[10px] text-gray-400">
                    <span>Budget Limit</span>
                    <span className="text-primary font-bold">৳{priceMaxRange}</span>
                  </div>
                  <input 
                    type="range"
                    min={100}
                    max={50000}
                    step={100}
                    value={priceMaxRange}
                    onChange={(e) => setPriceMaxRange(parseInt(e.target.value, 10))}
                    className="w-full accent-primary"
                  />
                </div>

                {/* Brand checkboxes mobile */}
                <div className="space-y-2 pt-4 border-t border-gray-100 dark:border-zinc-900">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">{t('Brand Names', 'ব্র্যান্ড নেম')}</span>
                  <div className="space-y-2.5 max-h-36 overflow-y-auto">
                    {brandsList.map((brand) => (
                      <label key={brand} className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                        <input 
                          type="checkbox"
                          checked={selectedBrands.includes(brand)}
                          onChange={() => handleBrandToggle(brand)}
                          className="w-4 h-4 text-primary focus:ring-primary accent-primary"
                        />
                        <span className="font-semibold">{brand}</span>
                      </label>
                    ))}
                  </div>
                </div>

              </div>

              <div className="pt-6 border-t border-gray-100 dark:border-zinc-900 flex gap-3">
                <button
                  onClick={handleClearAllFilters}
                  className="flex-1 py-3 bg-gray-100 text-zinc-800 text-xs font-bold rounded-xl uppercase tracking-wider"
                >
                  {t('Reset', 'মুছে ফেলুন')}
                </button>
                <button
                  onClick={() => setShowMobileFilters(false)}
                  className="flex-1 py-3 bg-primary text-white text-xs font-bold rounded-xl uppercase tracking-wider shadow-md shadow-primary/10"
                >
                  {t('Apply', 'প্রয়োগ')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
