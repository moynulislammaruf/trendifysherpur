/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { COUPONS_DATABASE } from '../data';
import { 
  Trash2, 
  ShoppingCart, 
  ArrowRight, 
  Tag, 
  ShoppingBag, 
  Info,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CartView: React.FC = () => {
  const { 
    cart, 
    updateCartQty, 
    removeFromCart, 
    setCurrentView, 
    t 
  } = useApp();

  const [couponCode, setCouponCode] = useState('');
  const [activeCoupon, setActiveCoupon] = useState<any | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');

    if (!couponCode.trim()) return;

    const matched = COUPONS_DATABASE.find(
      (c) => c.code.toUpperCase() === couponCode.trim().toUpperCase()
    );

    if (!matched) {
      setCouponError(t('Invalid coupon code.', 'ভুল কুপন কোড দিয়েছেন।'));
      setActiveCoupon(null);
      return;
    }

    if (subtotal < matched.minSpend) {
      setCouponError(
        t(
          `Minimum spend of ৳${matched.minSpend} required for this coupon.`,
          `এই কুপনের জন্য সর্বনিম্ন ৳${matched.minSpend} টাকার পণ্য কিনতে হবে।`
        )
      );
      setActiveCoupon(null);
      return;
    }

    setActiveCoupon(matched);
    setCouponSuccess(t(`Coupon applied! Saved ${matched.discountPercentage}%`, `কুপন কোড সফল হয়েছে! ${matched.discountPercentage}% ডিসকাউন্ট`));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountAmount = activeCoupon 
    ? Math.round(subtotal * (activeCoupon.discountPercentage / 100)) 
    : 0;
  const deliveryChargeEst = subtotal > 0 ? 60 : 0; // Default estimate (Sherpur Sadar delivery rate)
  const totalAmount = subtotal - discountAmount;

  const handleProceedToCheckout = () => {
    // Save current active coupon discount to localStorage for use in checkout view
    localStorage.setItem('ts_active_discount_amt', discountAmount.toString());
    localStorage.setItem('ts_active_coupon_code', activeCoupon ? activeCoupon.code : '');
    setCurrentView('checkout');
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 flex flex-col items-center text-center select-none">
        <div className="w-20 h-20 rounded-3xl bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 flex items-center justify-center text-gray-400 mb-6">
          <ShoppingBag size={36} />
        </div>
        <h2 className="text-xl font-extrabold text-zinc-900 dark:text-white">{t('Your Shopping Cart is Empty', 'আপনার শপিং কার্টটি শূন্য')}</h2>
        <p className="text-xs text-gray-400 max-w-sm mt-2 leading-relaxed">
          {t('Explore our premium collections of watches, perfumes, and Sherpur aromatic rice to add items.', 'আমাদের প্রিমিয়াম ঘড়ি, পারফিউম বা তুলশীমালা চালের সংগ্রহ থেকে আপনার কার্টে পণ্য যোগ করুন।')}
        </p>
        <button
          onClick={() => setCurrentView('home')}
          className="mt-8 px-6 py-3 bg-primary hover:bg-primary-dark text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-primary/10 transition-all"
        >
          {t('Start Shopping Now', 'এখনই শপিং শুরু করুন')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 select-none">
      
      <h1 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white mb-8 uppercase tracking-wide border-b border-gray-100 dark:border-zinc-900 pb-4">
        {t('Shopping Cart Basket', 'শপিং কার্ট ঝুড়ি')} ({cart.length} {t('Items', 'পণ্য')})
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* --- LEFT HAND SIDE: LIST OF PRODUCTS (8 cols) --- */}
        <div className="lg:col-span-8 space-y-4">
          <AnimatePresence>
            {cart.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -30 }}
                className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                {/* Product Meta Image/Title */}
                <div className="flex items-center gap-4 flex-1">
                  <img 
                    src={item.product.images[0]} 
                    alt={t(item.product.name.en, item.product.name.bn)} 
                    className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-xl border border-gray-100 dark:border-zinc-800 shrink-0" 
                  />
                  <div className="space-y-1 min-w-0">
                    <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest">{item.product.brand}</span>
                    <h3 className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate max-w-[280px]">
                      {t(item.product.name.en, item.product.name.bn)}
                    </h3>
                    <div className="flex flex-wrap gap-2 text-[10px] font-semibold text-gray-400">
                      {item.selectedColor && (
                        <span className="bg-gray-100 dark:bg-zinc-800 px-2.5 py-0.5 rounded-md text-zinc-700 dark:text-gray-300">
                          {t('Color:', 'রং:')} {item.selectedColor}
                        </span>
                      )}
                      {item.selectedSize && (
                        <span className="bg-gray-100 dark:bg-zinc-800 px-2.5 py-0.5 rounded-md text-zinc-700 dark:text-gray-300">
                          {t('Size:', 'সাইজ:')} {item.selectedSize}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Pricing, Quantity adjust, and removal triggers */}
                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto border-t sm:border-none pt-3 sm:pt-0">
                  
                  {/* Quantity adjusts */}
                  <div className="flex items-center border border-gray-200 dark:border-zinc-800 rounded-lg overflow-hidden bg-gray-50/50 dark:bg-zinc-950/20 shrink-0">
                    <button 
                      onClick={() => updateCartQty(item.id, item.quantity - 1)}
                      className="px-2.5 py-1.5 text-xs font-bold hover:bg-gray-100 dark:hover:bg-zinc-800"
                    >
                      -
                    </button>
                    <span className="px-2.5 text-xs font-bold w-8 text-center">{item.quantity}</span>
                    <button 
                      onClick={() => updateCartQty(item.id, item.quantity + 1)}
                      className="px-2.5 py-1.5 text-xs font-bold hover:bg-gray-100 dark:hover:bg-zinc-800"
                    >
                      +
                    </button>
                  </div>

                  {/* Price info */}
                  <div className="text-right min-w-[80px]">
                    <span className="text-sm font-extrabold text-primary block">৳{item.product.price * item.quantity}</span>
                    {item.quantity > 1 && (
                      <span className="text-[10px] text-gray-400">৳{item.product.price} / item</span>
                    )}
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all shrink-0"
                    title="Remove Item"
                  >
                    <Trash2 size={16} />
                  </button>

                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* --- RIGHT HAND SIDE: VOUCHER & SUMMARY (4 cols) --- */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Apply Coupon Box */}
          <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 rounded-2xl space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white flex items-center gap-1.5">
              <Tag size={14} className="text-primary" />
              {t('Apply Voucher / Coupon', 'ভাউচার / কুপন কোড')}
            </h3>

            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <input
                type="text"
                placeholder={t('Enter promo code...', 'কুপন কোড লিখুন...')}
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="bg-gray-50 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary flex-1 font-mono uppercase font-bold"
              />
              <button
                type="submit"
                className="bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all uppercase tracking-wide"
              >
                {t('Apply', 'প্রয়োগ')}
              </button>
            </form>

            {/* Error / Success logs */}
            {couponError && (
              <p className="text-[10px] text-red-500 font-semibold flex items-center gap-1">
                <XCircle size={12} />
                {couponError}
              </p>
            )}
            {couponSuccess && (
              <p className="text-[10px] text-success font-semibold flex items-center gap-1">
                <CheckCircle size={12} />
                {couponSuccess}
              </p>
            )}

            <div className="text-[10px] text-gray-400 bg-gray-50/50 dark:bg-zinc-950/20 p-2.5 rounded-xl border border-gray-100/50 dark:border-zinc-850/50 flex items-start gap-1.5">
              <Info size={12} className="text-primary shrink-0 mt-0.5" />
              <span>{t('Try "SHERPUR50" to enjoy 15% discount on products over BDT 1500.', '১৫০০ টাকার বেশি অর্ডারে ১৫% ডিসকাউন্টের জন্য "SHERPUR50" কোডটি ট্রাই করুন।')}</span>
            </div>
          </div>

          {/* Cart Order Summary Box */}
          <div className="bg-zinc-950 text-white rounded-2xl p-6 space-y-4 shadow-xl border border-zinc-900">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400 border-b border-zinc-900 pb-3">
              {t('Order Summary Checkout', 'অর্ডার সারাংশ চেকআউট')}
            </h3>

            <div className="space-y-2.5 text-xs text-gray-400 font-medium">
              <div className="flex justify-between">
                <span>{t('Subtotal Price:', 'মোট পণ্যের দাম:')}</span>
                <span className="text-white font-bold">৳{subtotal}</span>
              </div>

              {activeCoupon && (
                <div className="flex justify-between text-success">
                  <span>{t(`Coupon Discount (${activeCoupon.code}):`, `কুপন ডিসকাউন্ট (${activeCoupon.code}):`)}</span>
                  <span className="font-bold">-৳{discountAmount}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>{t('Est. Shipping Charge:', 'আনুমানিক ডেলিভারি চার্জ:')}</span>
                <span className="text-white font-bold">৳{deliveryChargeEst}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-zinc-900 flex justify-between items-baseline">
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">{t('Estimated Total:', 'মোট সর্বমোট মূল্য:')}</span>
              <span className="text-xl font-extrabold text-primary">৳{totalAmount + deliveryChargeEst}</span>
            </div>

            {/* Checkout action trigger button */}
            <button
              onClick={handleProceedToCheckout}
              className="w-full bg-primary hover:bg-primary-dark text-white font-extrabold py-3.5 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-primary/10 transition-all mt-4 hover:scale-103"
              id="proceed-to-checkout-btn"
            >
              <span>{t('Proceed to checkout', 'চেকআউটে এগিয়ে যান')}</span>
              <ArrowRight size={15} />
            </button>

            <p className="text-[10px] text-zinc-500 text-center">
              {t('Shipping charge adjusted during next checkout step based on your delivery address.', 'ডেলিভারি ঠিকানার ভিত্তিতে পরবর্তী ধাপে ডেলিভারি চার্জ চূড়ান্ত করা হবে।')}
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
