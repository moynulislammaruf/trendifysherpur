/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DISTRICTS_LIST } from '../data';
import { SavedAddress } from '../types';
import { 
  User, 
  ShoppingBag, 
  MapPin, 
  Heart, 
  Bell, 
  Headphones, 
  Trash2, 
  Plus, 
  CheckCircle, 
  Trash,
  ExternalLink,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const AccountView: React.FC = () => {
  const { 
    userProfile, 
    orders, 
    wishlist, 
    toggleWishlist,
    notifications, 
    markNotificationAsRead, 
    updateUserProfile, 
    addSavedAddress, 
    removeSavedAddress, 
    t,
    setCurrentView,
    setSelectedProduct
  } = useApp();

  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'address' | 'wishlist' | 'notifications' | 'support'>('orders');

  // Profile update form states
  const [profileName, setProfileName] = useState(userProfile.name);
  const [profileEmail, setProfileEmail] = useState(userProfile.email);
  const [profilePhone, setProfilePhone] = useState(userProfile.phone);
  const [profileUpdated, setProfileUpdated] = useState(false);

  // Address add form states
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [addrLabel, setAddrLabel] = useState('Home');
  const [addrName, setAddrName] = useState('');
  const [addrPhone, setAddrPhone] = useState('');
  const [addrDistrict, setAddrDistrict] = useState(DISTRICTS_LIST[0]);
  const [addrUpazila, setAddrUpazila] = useState(DISTRICTS_LIST[0].upazilas[0].name);
  const [addrFull, setAddrFull] = useState('');

  // Selected order details tracker state
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: profileName,
      email: profileEmail,
      phone: profilePhone
    });
    setProfileUpdated(true);
    setTimeout(() => setProfileUpdated(false), 3000);
  };

  const handleDistrictChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const dist = DISTRICTS_LIST.find((d) => d.name === e.target.value);
    if (dist) {
      setAddrDistrict(dist);
      setAddrUpazila(dist.upazilas[0].name);
    }
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrLabel || !addrName || !addrPhone || !addrFull) return;

    addSavedAddress({
      label: addrLabel,
      receiverName: addrName,
      phone: addrPhone,
      district: addrDistrict.name,
      upazila: addrUpazila,
      fullAddress: addrFull
    });

    setIsAddingAddress(false);
    // Reset
    setAddrName('');
    setAddrPhone('');
    setAddrFull('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 select-none">
      
      <h1 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white mb-8 uppercase tracking-wide border-b border-gray-100 dark:border-zinc-900 pb-4">
        {t('My Account Dashboard', 'আমার অ্যাকাউন্ট ড্যাশবোর্ড')}
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* --- LEFT NAVIGATION SIDEMENU (4 cols) --- */}
        <div className="lg:col-span-4 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 rounded-3xl space-y-6">
          
          {/* User brief profile header */}
          <div className="flex items-center gap-3 border-b border-gray-50 dark:border-zinc-800/80 pb-5">
            <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center font-bold text-lg uppercase shadow-inner">
              {userProfile.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-extrabold text-zinc-900 dark:text-white truncate">{userProfile.name}</h3>
              <p className="text-[10px] text-gray-400 mt-0.5 truncate">{userProfile.email}</p>
            </div>
          </div>

          {/* Navigation menus lists */}
          <div className="space-y-1">
            {[
              { id: 'orders', label: t('My Orders', 'আমার অর্ডারসমূহ'), count: orders.length, icon: <ShoppingBag size={16} /> },
              { id: 'profile', label: t('Profile Details', 'প্রোফাইল তথ্য'), icon: <User size={16} /> },
              { id: 'address', label: t('Saved Addresses', 'সংরক্ষিত ঠিকানা'), count: userProfile.savedAddresses.length, icon: <MapPin size={16} /> },
              { id: 'wishlist', label: t('My Wishlist', 'আমার উইশলিস্ট'), count: wishlist.length, icon: <Heart size={16} /> },
              { id: 'notifications', label: t('Notification History', 'বিজ্ঞপ্তি ইতিহাস'), count: notifications.length, icon: <Bell size={16} /> },
              { id: 'support', label: t('Support & Live Help', 'গ্রাহক সেবা'), icon: <Headphones size={16} /> }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as any); setSelectedOrder(null); }}
                className={`w-full px-4 py-3 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${activeTab === tab.id ? 'bg-primary text-white shadow-md shadow-primary/10' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-850/50'}`}
              >
                <div className="flex items-center gap-3">
                  {tab.icon}
                  <span>{tab.label}</span>
                </div>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${activeTab === tab.id ? 'bg-white text-primary' : 'bg-gray-100 dark:bg-zinc-800 text-gray-500'}`}>
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>

        </div>

        {/* --- RIGHT DETAILED VIEWS CONTENT PANEL (8 cols) --- */}
        <div className="lg:col-span-8 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 sm:p-8 rounded-3xl">
          
          {/* --- TAB: MY ORDERS LIST & TRANSIT TRACKER --- */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
                {t('My Orders', 'আমার অর্ডারসমূহ')}
              </h3>

              {selectedOrder ? (
                /* Specific order tracker detail card */
                <div className="space-y-6">
                  <button 
                    onClick={() => setSelectedOrder(null)}
                    className="text-xs text-primary hover:underline font-bold flex items-center gap-1 mb-4"
                  >
                    ← {t('Back to orders list', 'অর্ডার তালিকায় ফিরে যান')}
                  </button>

                  <div className="bg-gray-50/50 dark:bg-zinc-950/20 border border-gray-100 dark:border-zinc-850 p-5 sm:p-6 rounded-2xl space-y-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-100 dark:border-zinc-800 pb-4">
                      <div>
                        <p className="text-[10px] text-gray-400 font-bold">ORDER ID:</p>
                        <p className="font-mono text-sm font-extrabold text-zinc-900 dark:text-white uppercase">{selectedOrder.id}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 font-bold">PLACED ON:</p>
                        <p className="text-xs font-semibold text-zinc-800 dark:text-gray-200">{selectedOrder.date}</p>
                      </div>
                      <div className="sm:text-right">
                        <p className="text-[10px] text-gray-400 font-bold">TOTAL PRICE:</p>
                        <p className="text-sm font-extrabold text-primary">৳{selectedOrder.total}</p>
                      </div>
                    </div>

                    {/* Stepper tracking progress display */}
                    <div className="space-y-6 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100 dark:before:bg-zinc-800 pt-2">
                      {selectedOrder.trackingSteps.map((step: any, idx: number) => (
                        <div key={idx} className="flex gap-4 relative">
                          <div className={`w-6.5 h-6.5 rounded-full flex items-center justify-center border z-10 text-[10px] font-bold ${step.isCompleted ? 'bg-primary border-primary text-white' : 'bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400'}`}>
                            ✓
                          </div>
                          <div className="flex-1">
                            <h4 className={`text-xs font-bold ${step.isCompleted ? 'text-zinc-900 dark:text-white' : 'text-gray-400'}`}>
                              {t(step.label.en, step.label.bn)}
                            </h4>
                            <p className="text-[10px] text-gray-400 mt-0.5">{t(step.description.en, step.description.bn)}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Ordered items listing */}
                    <div className="border-t border-gray-100 dark:border-zinc-800 pt-5 space-y-3">
                      <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">{t('Ordered Items:', 'অর্ডারকৃত পণ্যসমূহ:')}</h4>
                      {selectedOrder.items.map((item: any) => (
                        <div key={item.id} className="flex gap-3 items-center">
                          <img src={item.product.images[0]} alt="" className="w-10 h-10 object-cover rounded-lg border border-gray-150" />
                          <div className="flex-1 min-w-0">
                            <h5 className="text-xs font-bold text-zinc-800 dark:text-gray-200 truncate">{t(item.product.name.en, item.product.name.bn)}</h5>
                            <p className="text-[10px] text-gray-400">Qty: {item.quantity} | Size: {item.selectedSize || 'N/A'}</p>
                          </div>
                          <span className="text-xs font-bold text-primary">৳{item.product.price * item.quantity}</span>
                        </div>
                      ))}
                    </div>

                  </div>
                </div>
              ) : orders.length > 0 ? (
                /* Interactive orders list table */
                <div className="divide-y divide-gray-50 dark:divide-zinc-850">
                  {orders.map((ord) => (
                    <div 
                      key={ord.id}
                      onClick={() => setSelectedOrder(ord)}
                      className="py-4 first:pt-0 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 cursor-pointer hover:bg-gray-50/50 dark:hover:bg-zinc-950/20 p-3 rounded-2xl transition-colors"
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-zinc-900 dark:text-white uppercase">#{ord.id}</span>
                          <span className="inline-block px-2.5 py-0.5 bg-primary/10 text-primary font-bold rounded-full text-[9px] uppercase tracking-wider">
                            {ord.status}
                          </span>
                        </div>
                        <p className="text-[10px] text-gray-400">{ord.date} | {ord.items.length} {t('Items purchased', 'টি পণ্য')}</p>
                        <p className="text-[11px] text-gray-500 font-medium truncate max-w-[320px]">
                          {t(ord.items[0].product.name.en, ord.items[0].product.name.bn)}
                          {ord.items.length > 1 && ` + ${ord.items.length - 1} more`}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 self-end sm:self-auto">
                        <div className="text-right">
                          <span className="text-xs font-extrabold text-primary block">৳{ord.total}</span>
                          <span className="text-[9px] text-gray-400 capitalize">{ord.paymentMethod}</span>
                        </div>
                        <ChevronRight size={16} className="text-gray-400" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-gray-400">
                  <p className="text-xs mb-3">{t('You have not placed any orders yet.', 'আপনি এখনো কোনো অর্ডার করেননি।')}</p>
                  <button onClick={() => setCurrentView('home')} className="px-5 py-2.5 bg-primary hover:bg-primary-dark text-white font-bold text-xs rounded-xl shadow-lg shadow-primary/10 transition-colors uppercase">
                    {t('Start Shopping', 'শপিং করুন')}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* --- TAB: PROFILE SETTINGS --- */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
                {t('Profile Information Details', 'প্রোফাইল তথ্য ও সেটিংস')}
              </h3>

              <form onSubmit={handleProfileSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">{t('Full Name', 'গ্রাহকের নাম')}</label>
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">{t('Email Address', 'ইমেইল ঠিকানা')}</label>
                    <input
                      type="email"
                      required
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">{t('Primary Mobile Number', 'মোবাইল নম্বর')}</label>
                  <input
                    type="tel"
                    required
                    value={profilePhone}
                    onChange={(e) => setProfilePhone(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark text-white font-extrabold px-6 py-2.5 rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-primary/10 transition-colors"
                >
                  {t('Update Profile Settings', 'প্রোফাইল আপডেট করুন')}
                </button>

                {profileUpdated && (
                  <motion.p 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }} 
                    className="text-[10px] text-success font-semibold"
                  >
                    ✓ {t('Profile information updated successfully!', 'প্রোফাইল তথ্য সফলভাবে আপডেট হয়েছে!')}
                  </motion.p>
                )}
              </form>
            </div>
          )}

          {/* --- TAB: SAVED ADDRESSES --- */}
          {activeTab === 'address' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3">
                  {t('Saved Delivery Addresses', 'সংরক্ষিত ডেলিভারি ঠিকানা')}
                </h3>
                
                <button
                  onClick={() => setIsAddingAddress(!isAddingAddress)}
                  className="px-3.5 py-2 bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  {isAddingAddress ? t('Cancel', 'বাতিল') : <><Plus size={14} /> {t('Add New', 'নতুন যোগ করুন')}</>}
                </button>
              </div>

              {/* Add Address Form overlay block */}
              <AnimatePresence>
                {isAddingAddress && (
                  <motion.form
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    onSubmit={handleAddAddress}
                    className="bg-gray-50/50 dark:bg-zinc-950/20 p-5 rounded-2xl border border-gray-100 dark:border-zinc-850 space-y-4 mb-6 overflow-hidden"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('Address Label (e.g. Home, Office)', 'ঠিকানার লেবেল')}</label>
                        <input
                          type="text"
                          required
                          value={addrLabel}
                          onChange={(e) => setAddrLabel(e.target.value)}
                          placeholder="Home"
                          className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('Receiver Full Name', 'প্রাপকের নাম')}</label>
                        <input
                          type="text"
                          required
                          value={addrName}
                          onChange={(e) => setAddrName(e.target.value)}
                          placeholder="Md. Maruf Islam"
                          className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('Contact Phone', 'মোবাইল নম্বর')}</label>
                        <input
                          type="tel"
                          required
                          value={addrPhone}
                          onChange={(e) => setAddrPhone(e.target.value)}
                          placeholder="01712345678"
                          className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('District', 'জেলা')}</label>
                        <select
                          value={addrDistrict.name}
                          onChange={handleDistrictChange}
                          className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none"
                        >
                          {DISTRICTS_LIST.map(d => (
                            <option key={d.name} value={d.name}>{t(d.name, d.bnName)}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('Upazila / Sub-district', 'উপজেলা')}</label>
                        <select
                          value={addrUpazila}
                          onChange={(e) => setAddrUpazila(e.target.value)}
                          className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none"
                        >
                          {addrDistrict.upazilas.map(upz => (
                            <option key={upz.name} value={upz.name}>{t(upz.name, upz.bnName)}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">{t('Full Address', 'পূর্ণ ঠিকানা')}</label>
                      <textarea
                        required
                        rows={2}
                        value={addrFull}
                        onChange={(e) => setAddrFull(e.target.value)}
                        placeholder="Village/Area, Holding info..."
                        className="w-full px-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs text-zinc-900 dark:text-white focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="bg-primary hover:bg-primary-dark text-white font-extrabold px-5 py-2.5 rounded-xl text-xs uppercase tracking-wide"
                    >
                      {t('Save New Address', 'ঠিকানা সংরক্ষণ করুন')}
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>

              {/* Render address listings cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {userProfile.savedAddresses.map((addr) => (
                  <div
                    key={addr.id}
                    className="p-5 border border-gray-100 dark:border-zinc-850 bg-gray-50/20 dark:bg-zinc-950/20 rounded-2xl flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="px-3 py-1 bg-primary/10 text-primary font-bold rounded-xl text-[10px] uppercase tracking-wide">
                          {addr.label}
                        </span>
                        
                        {/* Delete Address trigger */}
                        <button
                          onClick={() => removeSavedAddress(addr.id)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all"
                          title="Delete Address"
                        >
                          <Trash size={14} />
                        </button>
                      </div>
                      <h4 className="text-xs font-extrabold text-zinc-900 dark:text-white">{addr.receiverName}</h4>
                      <p className="text-[10px] text-gray-500 font-medium">{addr.phone}</p>
                      <p className="text-[11px] text-gray-400 leading-relaxed pt-1">{addr.fullAddress}</p>
                      <p className="text-[10px] text-gray-500 font-bold">{addr.upazila}, {addr.district}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --- TAB: WISHLIST --- */}
          {activeTab === 'wishlist' && (
            <div className="space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
                {t('My Saved Wishlist', 'আমার সংরক্ষিত উইশলিস্ট')}
              </h3>

              {wishlist.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {wishlist.map((prod) => (
                    <div
                      key={prod.id}
                      className="bg-gray-50/30 dark:bg-zinc-950/20 border border-gray-100 dark:border-zinc-850 p-3 rounded-2xl flex flex-col justify-between gap-3 text-center cursor-pointer"
                    >
                      <img src={prod.images[0]} alt="" className="w-full aspect-square object-cover rounded-xl" onClick={() => { setSelectedProduct(prod); setCurrentView('product-details'); }} />
                      <div onClick={() => { setSelectedProduct(prod); setCurrentView('product-details'); }}>
                        <h4 className="text-[11px] font-bold text-zinc-900 dark:text-white truncate">{t(prod.name.en, prod.name.bn)}</h4>
                        <span className="text-xs font-extrabold text-primary block mt-0.5">৳{prod.price}</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => { setSelectedProduct(prod); setCurrentView('product-details'); }}
                          className="flex-1 py-1.5 bg-black dark:bg-white text-white dark:text-black font-bold rounded-lg text-[9px] uppercase tracking-wide"
                        >
                          {t('View', 'দেখুন')}
                        </button>
                        <button
                          onClick={() => toggleWishlist(prod)}
                          className="p-1.5 rounded-lg border border-gray-200 dark:border-zinc-800 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all shrink-0"
                          title="Remove From Wishlist"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-gray-400">
                  <p className="text-xs">{t('Your wishlist is empty.', 'আপনার উইশলিস্টে কোনো পণ্য নেই।')}</p>
                </div>
              )}
            </div>
          )}

          {/* --- TAB: NOTIFICATION HISTORY --- */}
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
                {t('Notifications History logs', 'বিজ্ঞপ্তি ইতিহাস')}
              </h3>

              <div className="divide-y divide-gray-50 dark:divide-zinc-850">
                {notifications.map((notif) => (
                  <div 
                    key={notif.id}
                    onClick={() => markNotificationAsRead(notif.id)}
                    className={`py-4 first:pt-0 space-y-1.5 cursor-pointer p-3 rounded-xl hover:bg-gray-50/50 dark:hover:bg-zinc-950/10 ${!notif.isRead ? 'bg-primary/5' : ''}`}
                  >
                    <div className="flex justify-between items-start">
                      <h4 className="text-xs font-bold text-zinc-900 dark:text-white">{t(notif.title.en, notif.title.bn)}</h4>
                      <span className="text-[9px] text-gray-400">{new Date(notif.date).toLocaleDateString()}</span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">{t(notif.message.en, notif.message.bn)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --- TAB: SUPPORT DETAILS --- */}
          {activeTab === 'support' && (
            <div className="space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
                {t('Store Support and Live Help Desk', 'গ্রাহক সেবা ও লাইভ সাহায্য')}
              </h3>

              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed mb-6">
                {t(
                  "Have a query or order tracking issue? Our dedicated customer care managers are online to help you from 10 AM to 10 PM. Reach out using WhatsApp, Messenger, or email directly below.",
                  "কোনো প্রশ্ন বা অর্ডার ট্র্যাকিং নিয়ে জটিলতা? আমাদের গ্রাহক সেবা প্রতিনিধিরা প্রতিদিন সকাল ১০ টা থেকে রাত ১০ টা পর্যন্ত সক্রিয় আছেন। সরাসরি নিচের মাধ্যমে আমাদের সাথে যোগাযোগ করুন।"
                )}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                {/* WhatsApp Support channel */}
                <a 
                  href="https://wa.me/8801712345678" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-5 rounded-2xl bg-success/5 border border-success/20 hover:shadow-md transition-shadow text-center flex flex-col items-center gap-2.5"
                >
                  <span className="text-3xl block">🟢</span>
                  <span className="text-xs font-extrabold text-zinc-900 dark:text-white">{t('WhatsApp Chat', 'হোয়াটসঅ্যাপ চ্যাট')}</span>
                  <span className="text-[10px] text-gray-400 block">{t('Fastest 15-min responses', 'ইনস্ট্যান্ট মেসেজ পাঠান')}</span>
                </a>

                {/* Facebook support */}
                <a 
                  href="https://m.me/trendifysherpur" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-5 rounded-2xl bg-[#0084FF]/5 border border-[#0084FF]/20 hover:shadow-md transition-shadow text-center flex flex-col items-center gap-2.5"
                >
                  <span className="text-3xl block">🔵</span>
                  <span className="text-xs font-extrabold text-zinc-900 dark:text-white">{t('Messenger Chat', 'মেসেঞ্জার চ্যাট')}</span>
                  <span className="text-[10px] text-gray-400 block">{t('Chat with support reps', 'অফিসিয়াল ফেইসবুক চ্যাট')}</span>
                </a>

                {/* Direct Telephone line */}
                <div 
                  className="p-5 rounded-2xl bg-primary/5 border border-primary/20 text-center flex flex-col items-center gap-2.5 cursor-default"
                >
                  <span className="text-3xl block">📞</span>
                  <span className="text-xs font-extrabold text-zinc-900 dark:text-white">{t('Support Helpline', 'হেল্পলাইন কল করুন')}</span>
                  <span className="text-[10px] text-gray-400 block font-bold">+880 1712-345678</span>
                </div>

              </div>

              {/* Direct local live chat trigger */}
              <div className="bg-gray-50/50 dark:bg-zinc-950/20 p-5 rounded-2xl border border-gray-150 dark:border-zinc-850 flex justify-between items-center gap-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-zinc-900 dark:text-white">{t('Launch Interactive Support Chatbot', 'ইন্টারেক্টিভ চ্যাটবট চালু করুন')}</h4>
                  <p className="text-[10px] text-gray-400 leading-tight">{t('Query shipping details and Tulshimala rates instantaneously.', 'ডেলিভারি চার্জ ও ধানের দরদাম ইনস্ট্যান্ট জেনে নিন।')}</p>
                </div>
                
                <button
                  onClick={() => {
                    // Click floating bubble by ID simulation
                    const bub = document.getElementById('local-chat-trigger');
                    if (bub) bub.click();
                  }}
                  className="px-4 py-2 bg-primary hover:bg-primary-dark text-white font-bold text-xs rounded-lg flex items-center gap-1 transition-all"
                >
                  {t('Open Chat', 'চ্যাট খুলুন')}
                  <ChevronRight size={14} />
                </button>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};
