/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { HeroSlider } from '../components/HeroSlider';
import { ProductCard } from '../components/ProductCard';
import { CATEGORIES_LIST, PRODUCTS_DATABASE } from '../data';
import { 
  Flame, 
  Sparkles, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight, 
  Star, 
  User, 
  Clock,
  Sparkle
} from 'lucide-react';
import { motion } from 'motion/react';

export const HomeView: React.FC = () => {
  const { 
    t, 
    setCurrentView, 
    setSelectedCategoryFilter, 
    recentlyViewed,
    setSelectedProduct 
  } = useApp();

  // Flash Sale Timer calculations
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 59, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      
      const diff = endOfDay.getTime() - now.getTime();
      if (diff > 0) {
        const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const m = Math.floor((diff / (1000 * 60)) % 60);
        const s = Math.floor((diff / 1000) % 60);
        setTimeLeft({ hours: h, minutes: m, seconds: s });
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Filter collections
  const flashSaleProducts = PRODUCTS_DATABASE.filter(p => p.isFlashSale);
  const trendingProducts = PRODUCTS_DATABASE.slice(0, 4);
  const newArrivalProducts = PRODUCTS_DATABASE.filter(p => p.isNewArrival);
  const bestSellingProducts = PRODUCTS_DATABASE.filter(p => p.isBestSeller);
  const featuredProduct = PRODUCTS_DATABASE[0]; // tulshimala rice

  // Testimonials database
  const testimonials = [
    {
      name: 'Ashraful Islam',
      role: t('Local from Nalitabari', 'নালিতাবাড়ী নিবাসী'),
      rating: 5,
      comment: t(
        'Trendify Sherpur has made Tulshimala rice shopping so easy! The quality is premium and delivery is incredibly fast.',
        'ট্রেন্ডিফাই শেরপুর থেকে সুগন্ধি তুলশীমালা চাল কেনা এখন একদম সহজ! গুণগত মান অসাধারণ এবং সময়মতো কুরিয়ার পেয়েছি।'
      )
    },
    {
      name: 'Dr. Sabrina Yeasmin',
      role: t('Customer from Dhaka', 'ঢাকা নিবাসী'),
      rating: 5,
      comment: t(
        'I ordered the Oud Perfume. The luxury scent is long lasting and exactly as described. Truly premium experience!',
        'আমি ওদের উদ পারফিউমটি নিয়েছি। রাজকীয় ঘ্রাণটি দীর্ঘস্থায়ী এবং দেখতে চমৎকার। চমৎকার গ্রাহক সেবা!'
      )
    }
  ];

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. HERO SLIDER */}
      <HeroSlider />

      {/* 2. CIRCULAR CATEGORIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 select-none">
        <div className="text-center space-y-2 mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/10 rounded-full text-primary font-bold text-[10px] tracking-wider uppercase">
            <Sparkles size={11} />
            {t('Browse Collections', 'ক্যাটাগরি সমূহ')}
          </div>
          <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
            {t('Explore By Premium Category', 'আপনার পছন্দের ক্যাটাগরি শপ করুন')}
          </h2>
        </div>

        {/* Circular Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-7 gap-6 justify-center">
          {CATEGORIES_LIST.map((cat) => (
            <div 
              key={cat.id}
              onClick={() => {
                setSelectedCategoryFilter(cat.id);
                setCurrentView('search-results');
              }}
              className="flex flex-col items-center text-center group cursor-pointer"
            >
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800/80 flex items-center justify-center text-gray-700 dark:text-gray-300 group-hover:bg-primary group-hover:text-white group-hover:border-primary group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-300">
                <span className="text-sm font-bold uppercase tracking-widest font-mono">
                  {cat.id.substring(0, 2)}
                </span>
              </div>
              <span className="text-xs font-bold text-zinc-800 dark:text-gray-200 mt-3 group-hover:text-primary transition-colors">
                {t(cat.name.en, cat.name.bn)}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* 3. FLASH SALE CAMPAIGN SECTION */}
      {flashSaleProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary/5 dark:bg-zinc-900/30 border border-primary/20 dark:border-zinc-800 rounded-3xl p-6 sm:p-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="bg-primary text-white text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md animate-pulse">
                    <Flame size={12} />
                    {t('Flash Sale', 'ফ্ল্যাশ সেল')}
                  </span>
                  <span className="text-xs font-mono font-bold text-primary tracking-wide hidden sm:inline">
                    | {t('OFFER OF THE WEEK', 'সপ্তাহের সেরা ছাড়')}
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
                  {t('Luxury Deals on Limited Stock', 'সীমিত স্টকে রাজকীয় আকর্ষণ')}
                </h2>
              </div>

              {/* Countdown timer clock */}
              <div className="flex items-center gap-2 select-none">
                <Clock size={16} className="text-primary animate-pulse" />
                <span className="text-xs font-bold text-zinc-500 mr-2">{t('Ends In:', 'শেষ হবে:')}</span>
                <div className="flex gap-1.5 text-xs font-mono font-bold">
                  <div className="bg-black text-white px-2.5 py-1.5 rounded-lg text-center min-w-10">
                    {timeLeft.hours.toString().padStart(2, '0')}
                  </div>
                  <span className="text-zinc-500 self-center">:</span>
                  <div className="bg-black text-white px-2.5 py-1.5 rounded-lg text-center min-w-10">
                    {timeLeft.minutes.toString().padStart(2, '0')}
                  </div>
                  <span className="text-zinc-500 self-center">:</span>
                  <div className="bg-black text-white px-2.5 py-1.5 rounded-lg text-center min-w-10">
                    {timeLeft.seconds.toString().padStart(2, '0')}
                  </div>
                </div>
              </div>
            </div>

            {/* Products Row Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {flashSaleProducts.slice(0, 4).map((prod) => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 4. NEW ARRIVALS & TRENDING (Split section with beautiful layout tabs) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-black dark:bg-white text-white dark:text-black font-bold text-[10px] tracking-wider uppercase rounded-full">
              <TrendingUp size={11} />
              {t('New arrivals', 'নতুন কালেকশন')}
            </div>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
              {t('Fresh Additions for Modern Elegance', 'আভিজাত্য ও আধুনিকতার মেলবন্ধন')}
            </h2>
          </div>
          
          <button 
            onClick={() => { setSelectedCategoryFilter('all'); setCurrentView('search-results'); }}
            className="text-xs font-bold text-primary hover:text-primary-dark transition-colors flex items-center gap-1"
          >
            {t('View All Products', 'সকল পণ্য দেখুন')}
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {newArrivalProducts.slice(0, 4).map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 5. SPLIT LUXURY FEATURE BANNER (E.g. Tulshimala Rice) */}
      {featuredProduct && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-zinc-950 text-white rounded-3xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 border border-zinc-900">
            <div className="p-8 sm:p-12 lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/20 border border-primary/30 rounded-full text-primary font-mono text-[9px] font-bold uppercase tracking-widest w-fit">
                <Sparkle size={10} />
                {t('BEST OF BANGLADESH AGRO', 'বাংলার ঐতিহ্যবাহী সেরা কৃষি পণ্য')}
              </div>
              
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight leading-tight">
                {t(featuredProduct.name.en, featuredProduct.name.bn)}
              </h2>

              <p className="text-xs sm:text-sm text-gray-400 leading-relaxed">
                {t(
                  'Delight your family celebrations with the most fragrant rice of Mymensingh division. Extracted from the pristine soils of Sherpur Sadar, Tulshimala Rice is unpolished, keeping its rich natural vitamins and signature buttery jasmine aroma intact.',
                  'শেরপুরের আদি সুগন্ধি তুলশীমালা চালের সুবাসে সাজুক আপনার বিশেষ আয়োজন। সম্পূর্ণ অর্গানিক উপায়ে প্রস্তুতকৃত এবং আধুনিক উপায়ে প্যাকেজিং করা এই চাল আপনার রান্নায় যোগ করবে আভিজাত্য।'
                )}
              </p>

              <div className="flex gap-6 text-xs text-gray-300 font-semibold border-t border-zinc-900 pt-6">
                <div>
                  <span className="text-primary text-base font-extrabold block">100% Organic</span>
                  <span>{t('Zero Preservatives', 'প্রিজারভেটিভ মুক্ত')}</span>
                </div>
                <div className="border-l border-zinc-900 pl-6">
                  <span className="text-primary text-base font-extrabold block">Sherpur Pride</span>
                  <span>{t('Direct from Farmers', 'কৃষকদের থেকে সরাসরি')}</span>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => {
                    setSelectedProduct(featuredProduct);
                    setCurrentView('product-details');
                  }}
                  className="bg-primary hover:bg-primary-dark text-white font-extrabold px-6 py-3.5 rounded-xl text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-primary/25"
                >
                  {t('Get Premium Tulshimala Rice', 'তুলশীমালা চাল কিনুন')}
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 h-64 lg:h-auto relative">
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-zinc-950 to-transparent z-10" />
              <img 
                src={featuredProduct.images[0]} 
                alt="Tulshimala Featured" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </section>
      )}

      {/* 6. BEST SELLING PRODUCTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-success/10 text-success font-bold text-[10px] tracking-wider uppercase rounded-full">
              <CheckCircle size={11} />
              {t('Best Sellers', 'বেস্ট সেলিং পণ্য')}
            </div>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
              {t('Customer Favorites - Top Selling', 'গ্রাহকদের পছন্দের শীর্ষে থাকা পণ্যসমূহ')}
            </h2>
          </div>
          
          <button 
            onClick={() => { setSelectedCategoryFilter('all'); setCurrentView('search-results'); }}
            className="text-xs font-bold text-primary hover:text-primary-dark transition-colors flex items-center gap-1"
          >
            {t('Explore All Favorites', 'সব ফেভারিট দেখুন')}
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellingProducts.slice(0, 4).map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 7. DISCOUNT VOUCHER PROMO BOX */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-primary text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl shadow-primary/20 flex flex-col md:flex-row justify-between items-center gap-8">
          {/* Abstract geometric circle accents */}
          <div className="absolute -top-12 -right-12 w-64 h-64 bg-white/5 rounded-full" />
          <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-white/5 rounded-full" />

          <div className="space-y-3 max-w-lg text-center md:text-left z-10">
            <span className="bg-black/20 text-white font-mono text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-full border border-white/10">
              {t('FESTIVAL BONUS DISCOUNT', 'উৎসবকালীন বিশেষ অফার')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {t('Unlock Flat 15% Discount!', 'সরাসরি ১৫% ক্যাশব্যাক ছাড়!')}
            </h2>
            <p className="text-xs text-orange-50 leading-relaxed">
              {t(
                'Get flat 15% discount on checkout using exclusive coupon code: SHERPUR50. Min spend 1500 BDT. Code active till Eid.',
                'SHERPUR50 কোড ব্যবহার করে চেকআউটে সরাসরি ১৫% ছাড় উপভোগ করুন। সর্বনিম্ন অর্ডার ১৫০০ টাকা।'
              )}
            </p>
          </div>

          <div className="bg-black/15 border border-white/20 p-6 rounded-2xl text-center min-w-[200px] z-10">
            <span className="text-[10px] uppercase font-bold tracking-widest text-orange-200 block mb-1">Coupon Code</span>
            <span className="font-mono text-xl sm:text-2xl font-bold tracking-wider select-all block bg-white text-zinc-950 px-4 py-2 rounded-xl shadow-md uppercase">
              SHERPUR50
            </span>
          </div>
        </div>
      </section>

      {/* 8. RECENTLY VIEWED ROW */}
      {recentlyViewed.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-sm font-extrabold text-zinc-900 dark:text-white uppercase tracking-wider mb-6">
            {t('Recently Viewed Products', 'সম্প্রতি দেখা পণ্যসমূহ')}
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {recentlyViewed.map((prod) => (
              <div 
                key={prod.id}
                onClick={() => {
                  setSelectedProduct(prod);
                  setCurrentView('product-details');
                }}
                className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 p-2.5 rounded-2xl cursor-pointer hover:shadow-md transition-shadow flex flex-col gap-2"
              >
                <img src={prod.images[0]} alt={t(prod.name.en, prod.name.bn)} className="w-full aspect-square object-cover rounded-xl" />
                <h4 className="text-[11px] font-bold text-zinc-800 dark:text-gray-200 truncate leading-none mt-1">{t(prod.name.en, prod.name.bn)}</h4>
                <span className="text-xs font-bold text-primary">৳{prod.price}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 9. TESTIMONIALS / REVIEWS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-10">
          <span className="text-[10px] font-bold text-primary bg-primary/10 rounded-full px-3 py-1 uppercase tracking-widest inline-block">
            {t('TESTIMONIALS', 'গ্রাহক মতামত')}
          </span>
          <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
            {t('Loved By Thousands of Families', 'কেন আমাদের উপর ভরসা করবেন?')}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((test, idx) => (
            <div 
              key={idx}
              className="bg-gray-50/50 dark:bg-zinc-900 p-6 sm:p-8 rounded-3xl border border-gray-100 dark:border-zinc-800/80 flex flex-col justify-between space-y-4"
            >
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 leading-relaxed italic">
                "{test.comment}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/15 text-primary flex items-center justify-center font-bold text-sm">
                  {test.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-zinc-900 dark:text-white leading-none">{test.name}</h4>
                  <span className="text-[10px] text-gray-400 mt-1 block">{test.role}</span>
                </div>
                <div className="ml-auto flex text-amber-400">
                  {Array.from({ length: test.rating }).map((_, i) => (
                    <Star key={i} size={11} fill="currentColor" />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
