/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS_DATABASE } from '../data';
import { Product } from '../types';
import { 
  Star, 
  ShoppingCart, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Truck, 
  RefreshCw, 
  Share2, 
  Play, 
  ChevronRight,
  MessageSquare,
  HelpCircle,
  Sparkles,
  Plus,
  Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ProductCard } from '../components/ProductCard';

export const ProductView: React.FC = () => {
  const { 
    selectedProduct, 
    setSelectedProduct, 
    addToCart, 
    setCurrentView, 
    addToRecentlyViewed,
    t 
  } = useApp();

  const [selectedImgIdx, setSelectedImgIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'shipping' | 'return'>('desc');
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Frequently bought bundle checkbox state
  const [isBundleChecked, setIsBundleChecked] = useState(true);

  // Form question state
  const [userQuestion, setUserQuestion] = useState('');
  const [qSubmitted, setQSubmitted] = useState(false);

  useEffect(() => {
    if (selectedProduct) {
      addToRecentlyViewed(selectedProduct);
      // Reset defaults
      setSelectedImgIdx(0);
      setSelectedColor(selectedProduct.colors && selectedProduct.colors.length > 0 ? selectedProduct.colors[0] : '');
      setSelectedSize(selectedProduct.sizes && selectedProduct.sizes.length > 0 ? selectedProduct.sizes[0] : '');
      setQuantity(1);
      setIsPlayingVideo(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [selectedProduct]);

  if (!selectedProduct) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-500 mb-4">{t('No product selected.', 'কোনো পণ্য নির্বাচন করা হয়নি।')}</p>
        <button onClick={() => setCurrentView('home')} className="px-6 py-2.5 bg-primary text-white rounded-xl font-bold text-xs uppercase">
          {t('Back to Home', 'হোমপেজে ফিরে যান')}
        </button>
      </div>
    );
  }

  const product = selectedProduct;

  // Selected discount details
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  // Related products (same category, exclude current)
  const relatedProducts = PRODUCTS_DATABASE.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 4);

  // Frequently bought together companion item
  const companionProduct = PRODUCTS_DATABASE.find((p) => p.id !== product.id) || PRODUCTS_DATABASE[0];
  const combinedPrice = product.price + companionProduct.price;
  const bundleDiscountedPrice = Math.round(combinedPrice * 0.92); // 8% discount on bundle!

  const handleAddToCart = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    setCurrentView('cart');
  };

  const handleAddBundleToCart = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    if (isBundleChecked) {
      addToCart(companionProduct, companionProduct.colors?.[0], companionProduct.sizes?.[0], 1);
    }
    setCurrentView('cart');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handlePostQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuestion.trim()) return;
    
    setQSubmitted(true);
    setUserQuestion('');
    setTimeout(() => setQSubmitted(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 select-none">
      
      {/* BREADCRUMBS BAR */}
      <div className="flex items-center gap-2 text-xs text-gray-400 mb-8 font-medium">
        <span className="hover:text-primary cursor-pointer" onClick={() => setCurrentView('home')}>{t('Home', 'হোম')}</span>
        <ChevronRight size={12} />
        <span className="hover:text-primary cursor-pointer" onClick={() => { setCurrentView('search-results'); }}>{t('Shop', 'শপ')}</span>
        <ChevronRight size={12} />
        <span className="text-zinc-900 dark:text-gray-100 truncate max-w-[200px]">{t(product.name.en, product.name.bn)}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16">
        
        {/* --- LEFT IMAGE / MEDIA LAYOUT PANEL (5 cols) --- */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-gray-50/50 dark:bg-zinc-950/20 border border-gray-100 dark:border-zinc-850">
            
            {/* Visual stream rendering */}
            {isPlayingVideo && product.videoUrl ? (
              <video 
                src={product.videoUrl} 
                controls 
                autoPlay 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="zoom-container w-full h-full">
                <img 
                  src={product.images[selectedImgIdx]} 
                  alt={t(product.name.en, product.name.bn)} 
                  className="zoom-img w-full h-full object-cover"
                  id="main-product-image"
                />
              </div>
            )}

            {/* Float Badges Overlay */}
            <div className="absolute top-5 left-5 flex flex-col gap-2 z-10">
              {product.isFlashSale && (
                <span className="bg-primary text-white text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md">
                  <Flame size={12} className="animate-pulse" />
                  {t('Flash Sale', 'ফ্ল্যাশ সেল')}
                </span>
              )}
              {discountPercent > 0 && (
                <span className="bg-black dark:bg-white text-white dark:text-black text-[10px] font-extrabold px-3 py-1 rounded-full">
                  {discountPercent}% {t('OFF', 'ছাড়')}
                </span>
              )}
            </div>

            {/* Hover instruction for Apple-style premium zoom experience */}
            {!isPlayingVideo && (
              <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-xs text-[9px] text-gray-300 px-2.5 py-1 rounded-md">
                {t('Hover to zoom details', 'জুম করতে কার্সার রাখুন')}
              </div>
            )}
          </div>

          {/* Gallery Thumbnails List */}
          <div className="flex gap-3 overflow-x-auto pb-1 select-none">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => { setSelectedImgIdx(idx); setIsPlayingVideo(false); }}
                className={`w-16 h-16 rounded-xl overflow-hidden border bg-white shrink-0 transition-all ${selectedImgIdx === idx && !isPlayingVideo ? 'border-primary ring-2 ring-primary/20 scale-95' : 'border-gray-200 hover:border-gray-400'}`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}

            {/* Video button triggers */}
            {product.videoUrl && (
              <button
                onClick={() => setIsPlayingVideo(true)}
                className={`w-16 h-16 rounded-xl bg-zinc-950 border text-white flex flex-col items-center justify-center shrink-0 hover:bg-zinc-900 transition-all ${isPlayingVideo ? 'border-primary ring-2 ring-primary/20 scale-95' : 'border-gray-200'}`}
              >
                <Play size={18} fill="white" />
                <span className="text-[8px] font-bold uppercase tracking-widest mt-1">Video</span>
              </button>
            )}
          </div>
        </div>

        {/* --- RIGHT SPECIFICATION & ACTION PURCHASE PANEL (7 cols) --- */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div className="space-y-6">
            
            {/* Header info */}
            <div>
              <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block">{product.brand}</span>
              <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-white leading-tight tracking-tight mt-1">
                {t(product.name.en, product.name.bn)}
              </h1>
              
              {/* Rating stars row */}
              <div className="flex items-center gap-2 mt-3">
                <div className="flex text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={14} fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'} />
                  ))}
                </div>
                <span className="text-xs font-bold text-zinc-800 dark:text-gray-200">{product.rating}</span>
                <span className="text-xs text-gray-400">({product.reviewsCount} {t('Customer reviews', 'কাস্টমার রিভিউ')})</span>
              </div>
            </div>

            {/* Pricing Section */}
            <div className="flex items-baseline gap-3 bg-gray-50/50 dark:bg-zinc-900/50 p-4 rounded-2xl border border-gray-100/50 dark:border-zinc-800/50 w-fit">
              <span className="text-3xl font-extrabold text-primary">৳{product.price}</span>
              {product.originalPrice > product.price && (
                <span className="text-sm text-gray-400 line-through">৳{product.originalPrice}</span>
              )}
            </div>

            {/* Custom attributes color/size selects */}
            {product.colors && product.colors.length > 0 && (
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">{t('Color Option:', 'রং নির্বাচন করুন:')}</label>
                <div className="flex gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${selectedColor === color ? 'bg-primary border-primary text-white shadow-lg shadow-primary/10' : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-zinc-800 dark:text-gray-300 hover:border-gray-400'}`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.sizes && product.sizes.length > 0 && (
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">{t('Size Option:', 'সাইজ নির্বাচন করুন:')}</label>
                <div className="flex gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${selectedSize === size ? 'bg-black dark:bg-white border-black dark:border-white text-white dark:text-black shadow-md' : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-zinc-800 dark:text-gray-300 hover:border-gray-400'}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Stock and Shipping parameters */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-2 text-xs font-semibold">
                {product.stockStatus === 'in-stock' ? (
                  <span className="text-success flex items-center gap-1.5">
                    <CheckCircle2 size={15} />
                    {t('In Stock - Sourced fresh & ready to ship', 'স্টকে আছে - কুরিয়ারের জন্য প্রস্তুত')}
                  </span>
                ) : product.stockStatus === 'low-stock' ? (
                  <span className="text-amber-500 flex items-center gap-1.5">
                    <AlertTriangle size={15} />
                    {t('Low Stock - Only few left in our Sherpur vault!', 'সীমিত স্টক - দ্রুত অর্ডার করুন!')}
                  </span>
                ) : (
                  <span className="text-red-500 flex items-center gap-1.5">
                    <X size={15} />
                    {t('Out of Stock - Restocking shortly', 'স্টক শেষ - খুব শীঘ্রই আসছে')}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-4 text-xs text-gray-500 font-medium">
                <span className="flex items-center gap-1">
                  <Truck size={14} className="text-primary" />
                  {t('Free delivery inside Sherpur', 'শেরপুরে ফ্রি ডেলিভারি')}
                </span>
                <span className="flex items-center gap-1">
                  <RefreshCw size={14} className="text-primary" />
                  {t('7 Days replacement warranty', '৭ দিনের গ্যারান্টি')}
                </span>
              </div>
            </div>

            {/* Purchase triggers row */}
            <div className="pt-6 border-t border-gray-100 dark:border-zinc-850 space-y-4">
              <div className="flex gap-4">
                
                {/* Quantity */}
                <div className="flex items-center border border-gray-200 dark:border-zinc-850 rounded-xl overflow-hidden bg-gray-50/50 dark:bg-zinc-950/20">
                  <button 
                    disabled={quantity <= 1}
                    onClick={() => setQuantity(quantity - 1)}
                    className="px-4 py-3 text-sm font-extrabold hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-40"
                  >
                    -
                  </button>
                  <span className="px-4 text-xs font-bold w-12 text-center">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-4 py-3 text-sm font-extrabold hover:bg-gray-100 dark:hover:bg-zinc-800"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  onClick={handleAddToCart}
                  disabled={product.stockStatus === 'out-of-stock'}
                  className="bg-zinc-950 dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white disabled:bg-gray-200 dark:disabled:bg-zinc-800 disabled:text-gray-400 font-bold px-8 py-3.5 rounded-xl text-xs flex-1 transition-all flex items-center justify-center gap-2.5 uppercase tracking-wider shadow-lg shadow-zinc-900/10 dark:shadow-none"
                  id="main-add-to-cart-btn"
                >
                  <ShoppingCart size={16} />
                  {t('Add to Cart Bag', 'শপিং ব্যাগে যোগ করুন')}
                </button>
              </div>

              {/* Buy Now & Share */}
              <div className="flex gap-4">
                <button
                  onClick={handleBuyNow}
                  disabled={product.stockStatus === 'out-of-stock'}
                  className="bg-primary hover:bg-primary-dark disabled:bg-gray-200 dark:disabled:bg-zinc-800 disabled:text-gray-400 text-white font-extrabold px-8 py-4 rounded-xl text-xs flex-1 transition-all uppercase tracking-wider flex items-center justify-center shadow-lg shadow-primary/20"
                  id="main-buy-now-btn"
                >
                  {t('Order Directly (Cash On Delivery)', 'সরাসরি ক্যাশ অন ডেলিভারি অর্ডার')}
                </button>
                
                <button
                  onClick={handleShare}
                  className="border border-gray-200 dark:border-zinc-800 hover:bg-gray-50 dark:hover:bg-zinc-800 p-4 rounded-xl text-gray-500 hover:text-zinc-900 dark:hover:text-white transition-all relative"
                  title="Copy Product Link"
                >
                  <Share2 size={18} />
                  {copiedLink && (
                    <span className="absolute bottom-full mb-2 right-0 bg-black text-white text-[9px] px-2.5 py-1 rounded-md whitespace-nowrap">
                      Link Copied!
                    </span>
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* --- EXTRA DETAILED SPECIFICATIONS TABS (Description, Specs, Shipping, Returns) --- */}
      <section className="border-t border-gray-100 dark:border-zinc-850 pt-12 mb-16 select-none">
        
        {/* Tab Headers */}
        <div className="flex border-b border-gray-100 dark:border-zinc-850 overflow-x-auto gap-8 mb-8 text-xs font-bold uppercase tracking-wider pb-1">
          {[
            { id: 'desc', label: t('Description', 'পণ্য বিবরণী') },
            { id: 'specs', label: t('Specifications', 'বৈশিষ্ট্যসমূহ') },
            { id: 'shipping', label: t('Shipping Details', 'ডেলিভারি তথ্য') },
            { id: 'return', label: t('Return Policy', 'রিটার্ন পলিসি') }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-4 transition-colors relative font-extrabold shrink-0 ${activeTab === tab.id ? 'text-primary' : 'text-gray-400 hover:text-zinc-900 dark:hover:text-white'}`}
            >
              {tab.label}
              {activeTab === tab.id && (
                <motion.div layoutId="activeTabIndicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          ))}
        </div>

        {/* Tab Content Render */}
        <div className="bg-gray-50/40 dark:bg-zinc-900/40 border border-gray-50 dark:border-zinc-850 p-6 sm:p-8 rounded-3xl min-h-[160px]">
          {activeTab === 'desc' && (
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed max-w-4xl whitespace-pre-line">
              {t(product.description.en, product.description.bn)}
            </p>
          )}

          {activeTab === 'specs' && (
            <div className="max-w-xl divide-y divide-gray-100 dark:divide-zinc-800">
              {product.specifications.map((spec, idx) => (
                <div key={idx} className="grid grid-cols-2 py-3 text-xs">
                  <span className="font-extrabold text-zinc-900 dark:text-gray-200">{t(spec.key.en, spec.key.bn)}</span>
                  <span className="text-gray-500 dark:text-gray-400 font-medium">{t(spec.value.en, spec.value.bn)}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'shipping' && (
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed max-w-4xl">
              {t(product.shippingInfo.en, product.shippingInfo.bn)}
            </p>
          )}

          {activeTab === 'return' && (
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 leading-relaxed max-w-4xl">
              {t(product.returnPolicy.en, product.returnPolicy.bn)}
            </p>
          )}
        </div>

      </section>

      {/* --- INTERACTIVE FREQUENTLY BOUGHT TOGETHER BUNDLER (Conversion Hack!) --- */}
      <section className="bg-primary/5 dark:bg-zinc-900/30 border border-primary/10 dark:border-zinc-800 p-6 sm:p-8 rounded-3xl mb-16">
        <h3 className="text-xs font-bold uppercase tracking-widest text-primary mb-4 flex items-center gap-1.5">
          <Sparkles size={14} className="animate-pulse" />
          {t('Frequently Bought Together Bundle Offer!', 'গ্রাহকদের পছন্দের বান্ডেল অফার!')}
        </h3>

        <div className="flex flex-col md:flex-row items-center gap-6 justify-between select-none">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            
            {/* Current Item */}
            <div className="flex items-center gap-3 bg-white dark:bg-zinc-950 p-2.5 rounded-2xl border border-gray-100 dark:border-zinc-850">
              <img src={product.images[0]} alt="" className="w-12 h-12 object-cover rounded-lg" />
              <div>
                <h4 className="text-[11px] font-bold text-zinc-900 dark:text-white max-w-[150px] truncate">{t(product.name.en, product.name.bn)}</h4>
                <span className="text-xs font-bold text-primary">৳{product.price}</span>
              </div>
            </div>

            <Plus size={16} className="text-gray-400" />

            {/* Companion Item */}
            <div className="flex items-center gap-3 bg-white dark:bg-zinc-950 p-2.5 rounded-2xl border border-gray-100 dark:border-zinc-850 relative">
              <div className="absolute top-2 left-2 z-10">
                <input 
                  type="checkbox" 
                  checked={isBundleChecked}
                  onChange={(e) => setIsBundleChecked(e.target.checked)}
                  className="w-4.5 h-4.5 rounded border-gray-300 text-primary focus:ring-primary accent-primary cursor-pointer"
                />
              </div>
              <img src={companionProduct.images[0]} alt="" className="w-12 h-12 object-cover rounded-lg pl-5" />
              <div>
                <h4 className="text-[11px] font-bold text-zinc-900 dark:text-white max-w-[150px] truncate">{t(companionProduct.name.en, companionProduct.name.bn)}</h4>
                <span className="text-xs font-bold text-primary">৳{companionProduct.price}</span>
              </div>
            </div>

          </div>

          {/* Bundle Summary & checkout triggers */}
          <div className="text-center md:text-right space-y-2 shrink-0">
            <div>
              <span className="text-[10px] text-gray-400 block">{t('Total Bundle Price:', 'বান্ডেল মোট মূল্য:')}</span>
              <div className="flex items-baseline gap-2 justify-center md:justify-end">
                <span className="text-sm text-gray-400 line-through">৳{isBundleChecked ? combinedPrice : product.price}</span>
                <span className="text-lg font-extrabold text-success">৳{isBundleChecked ? bundleDiscountedPrice : product.price}</span>
              </div>
              {isBundleChecked && (
                <span className="text-[10px] text-success font-semibold block">🎉 {t('8% Bundle Saving Applied!', '৮% বিশেষ বান্ডেল ছাড় যোগ হয়েছে!')}</span>
              )}
            </div>

            <button
              onClick={handleAddBundleToCart}
              className="bg-zinc-950 dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white font-bold px-6 py-2.5 rounded-xl text-xs transition-all uppercase tracking-wide flex items-center justify-center gap-1.5"
            >
              <ShoppingCart size={13} />
              {t('Buy Bundle Together', 'পুরো বান্ডেল একসাথে কিনুন')}
            </button>
          </div>
        </div>
      </section>

      {/* --- COMMUNITY DISCUSSIONS & QUESTIONS FEED --- */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-12 border-t border-gray-100 dark:border-zinc-850 pt-12 mb-16">
        
        {/* Column 1: Client Reviews */}
        <div className="space-y-6">
          <h3 className="text-sm font-extrabold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3">
            {t(`Customer Reviews (${product.reviews.length})`, `কাস্টমার রিভিউ (${product.reviews.length})`)}
          </h3>

          <div className="space-y-5 divide-y divide-gray-50 dark:divide-zinc-850">
            {product.reviews.map((rev) => (
              <div key={rev.id} className="pt-4 first:pt-0 space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                      {rev.user.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-zinc-900 dark:text-white leading-none">{rev.user}</h4>
                      <span className="text-[9px] text-gray-400 mt-1 block">{rev.date}</span>
                    </div>
                  </div>

                  <div className="flex text-amber-400">
                    {Array.from({ length: rev.rating }).map((_, i) => (
                      <Star key={i} size={11} fill="currentColor" />
                    ))}
                  </div>
                </div>

                <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                  {t(rev.comment.en, rev.comment.bn)}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Column 2: Simulated Q&A Panel */}
        <div className="space-y-6">
          <h3 className="text-sm font-extrabold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3">
            {t(`Product Discussions & Questions`, `জিজ্ঞাসা ও প্রশ্নোত্তর`)}
          </h3>

          <div className="space-y-5 divide-y divide-gray-50 dark:divide-zinc-850">
            {product.questions.map((q) => (
              <div key={q.id} className="pt-4 first:pt-0 space-y-3 text-xs leading-relaxed">
                <div>
                  <span className="font-extrabold text-zinc-900 dark:text-white flex items-center gap-1">
                    <HelpCircle size={12} className="text-primary shrink-0" />
                    {t('Q:', 'প্রশ্ন:')} {t(q.question.en, q.question.bn)}
                  </span>
                  <p className="text-[10px] text-gray-400 pl-4 mt-0.5">{t('Asked by', 'জানতে চেয়েছেন')} {q.user} | {q.date}</p>
                </div>
                <div className="pl-4">
                  <p className="text-gray-500 dark:text-gray-400 bg-gray-50/50 dark:bg-zinc-950/20 p-2.5 rounded-xl border border-gray-100/50 dark:border-zinc-850/50">
                    <span className="font-bold text-zinc-900 dark:text-white block mb-0.5">{t('A: Store Representative Response', 'উত্তর: শপ প্রতিনিধি')}</span>
                    {t(q.answer.en, q.answer.bn)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Ask custom question form */}
          <form onSubmit={handlePostQuestion} className="bg-gray-50/30 dark:bg-zinc-950/20 p-5 rounded-2xl border border-gray-100 dark:border-zinc-850 space-y-3 mt-8">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">{t('Have a question? Ask our store experts:', 'আপনার কি কোনো জিজ্ঞাসা আছে? বিশেষজ্ঞদের জিজ্ঞেস করুন:')}</label>
            <div className="flex gap-2">
              <input
                type="text"
                required
                placeholder={t('Will this arrive before Eid?', 'এটি কি ঈদের আগে পৌঁছাবে?')}
                value={userQuestion}
                onChange={(e) => setUserQuestion(e.target.value)}
                className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl px-4 py-2 text-xs focus:outline-none focus:border-primary text-zinc-900 dark:text-white flex-1"
              />
              <button
                type="submit"
                className="bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white font-bold px-4 py-2 rounded-xl text-xs transition-colors"
              >
                {t('Post', 'জমা দিন')}
              </button>
            </div>
            {qSubmitted && (
              <motion.p 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                className="text-[10px] text-success font-semibold"
              >
                ✓ {t('Thank you! Your question has been submitted for moderation.', 'ধন্যবাদ! আপনার প্রশ্নটি অনুমোদনের জন্য জমা নেওয়া হয়েছে।')}
              </motion.p>
            )}
          </form>
        </div>

      </section>

      {/* --- RELATED PRODUCTS SECTION GRID --- */}
      {relatedProducts.length > 0 && (
        <section className="border-t border-gray-100 dark:border-zinc-850 pt-12">
          <h3 className="text-sm font-extrabold text-zinc-900 dark:text-white uppercase tracking-wider mb-8">
            {t('Related Products You May Like', 'সম্পর্কিত অন্যান্য কিছু চমৎকার পণ্য')}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

    </div>
  );
};
