/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DISTRICTS_LIST } from '../data';
import { Order, CartItem, CustomerInfo } from '../types';
import { 
  CreditCard, 
  CheckCircle, 
  Truck, 
  HelpCircle, 
  Phone, 
  FileText, 
  User, 
  ShoppingBag,
  ArrowLeft,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const CheckoutView: React.FC = () => {
  const { 
    cart, 
    clearCart, 
    placeOrder, 
    setCurrentView, 
    userProfile, 
    t 
  } = useApp();

  // --- Form input fields state ---
  const [name, setName] = useState(userProfile.name);
  const [email, setEmail] = useState(userProfile.email);
  const [phone, setPhone] = useState(userProfile.phone);
  const [altPhone, setAltPhone] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState(DISTRICTS_LIST[0]); // Sherpur by default
  const [selectedUpazilaName, setSelectedUpazilaName] = useState(DISTRICTS_LIST[0].upazilas[0].name);
  const [address, setAddress] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash' | 'nagad' | 'rocket' | 'sslcommerz'>('cod');

  // Load applied coupon details from local storage
  const [discountAmount, setDiscountAmount] = useState(0);
  const [couponCode, setCouponCode] = useState('');

  // Success flow control states
  const [isOrdering, setIsOrdering] = useState(false);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);

  useEffect(() => {
    // If cart is empty, redirect back to cart
    if (cart.length === 0 && !successOrder) {
      setCurrentView('cart');
    }

    const savedDiscount = localStorage.getItem('ts_active_discount_amt');
    const savedCode = localStorage.getItem('ts_active_coupon_code');
    if (savedDiscount) setDiscountAmount(parseInt(savedDiscount, 10));
    if (savedCode) setCouponCode(savedCode);
  }, [cart, successOrder]);

  const handleDistrictChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const dist = DISTRICTS_LIST.find((d) => d.name === e.target.value);
    if (dist) {
      setSelectedDistrict(dist);
      setSelectedUpazilaName(dist.upazilas[0].name);
    }
  };

  const handleSavedAddressSelect = (addr: any) => {
    setName(addr.receiverName);
    setPhone(addr.phone);
    setAddress(addr.fullAddress);
    
    const dist = DISTRICTS_LIST.find(d => d.name.toLowerCase() === addr.district.toLowerCase());
    if (dist) {
      setSelectedDistrict(dist);
      const matchingUpazila = dist.upazilas.find(u => u.name.toLowerCase() === addr.upazila.toLowerCase());
      if (matchingUpazila) {
        setSelectedUpazilaName(matchingUpazila.name);
      }
    }
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const deliveryCharge = selectedDistrict.deliveryCharge;
  const finalTotal = subtotal - discountAmount + deliveryCharge;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !address) return;

    setIsOrdering(true);

    // Simulate placing order with minor delay for highly premium look & feel
    setTimeout(() => {
      const orderId = `TS-${Math.floor(100000 + Math.random() * 900000)}`;
      
      const trackingSteps = [
        { 
          label: { en: 'Order Registered', bn: 'অর্ডার সম্পন্ন' }, 
          date: new Date().toLocaleDateString(), 
          isCompleted: true, 
          description: { en: 'Your payment details and order are registered.', bn: 'আপনার অর্ডারটি সিস্টেমে গ্রহণ করা হয়েছে।' } 
        },
        { 
          label: { en: 'Verified & Approved', bn: 'যাচাই ও অনুমোদন' }, 
          date: new Date().toLocaleDateString(), 
          isCompleted: true, 
          description: { en: 'Our representative approved shipping details.', bn: 'আমাদের সাপোর্ট ম্যানেজার তথ্য যাচাই করেছেন।' } 
        },
        { 
          label: { en: 'In Transit', bn: 'কুরিয়ারে প্রেরিত' }, 
          date: '--/--/--', 
          isCompleted: false, 
          description: { en: 'Handing over to Pathao/Steadfast logistics.', bn: 'কুরিয়ার সার্ভিসে পণ্য হস্তান্তরের কাজ চলছে।' } 
        },
        { 
          label: { en: 'Delivered', bn: 'ডেলিভারি সম্পন্ন' }, 
          date: '--/--/--', 
          isCompleted: false, 
          description: { en: 'Courier boy will deliver package to your address.', bn: 'কুরিয়ার প্রতিনিধি আপনার ঠিকানায় প্যাকেজটি দিয়ে যাবে।' } 
        }
      ];

      const newOrder: Order = {
        id: orderId,
        date: new Date().toLocaleDateString(),
        status: 'processing',
        items: [...cart],
        subtotal,
        shippingCharge: deliveryCharge,
        discount: discountAmount,
        total: finalTotal,
        customerInfo: {
          name,
          phone,
          altPhone,
          email,
          district: selectedDistrict.name,
          upazila: selectedUpazilaName,
          address,
          note: orderNote
        },
        paymentMethod,
        paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid',
        trackingSteps
      };

      placeOrder(newOrder);
      setSuccessOrder(newOrder);
      setIsOrdering(false);
      
      // Clean applied discount storage
      localStorage.removeItem('ts_active_discount_amt');
      localStorage.removeItem('ts_active_coupon_code');
    }, 1800);
  };

  // --- RENDER ORDER CONFIRMED SCREEN ---
  if (successOrder) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center select-none">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-8 sm:p-12 rounded-3xl shadow-2xl space-y-6"
        >
          <div className="w-20 h-20 bg-success/10 text-success rounded-full flex items-center justify-center mx-auto relative">
            <CheckCircle size={44} className="animate-heartBeat" />
            <span className="absolute inset-0 rounded-full bg-success/20 animate-ping"></span>
          </div>

          <div className="space-y-2">
            <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white uppercase tracking-wider">{t('Order Confirmed Successfully!', 'অর্ডার সফলভাবে গ্রহণ করা হয়েছে!')}</h2>
            <p className="text-xs text-gray-400">
              {t(`Thank you! Your order #${successOrder.id} has been registered. Our representative will call you for verification shortly.`, `ধন্যবাদ! আপনার অর্ডার #${successOrder.id} সফলভাবে সম্পন্ন হয়েছে। কিছুক্ষণের মধ্যে আমাদের প্রতিনিধি আপনার ফোনে কল দিয়ে অর্ডারটি নিশ্চিত করবেন।`)}
            </p>
          </div>

          {/* Receipt details */}
          <div className="bg-gray-50/50 dark:bg-zinc-950/20 border border-gray-100 dark:border-zinc-850 p-6 rounded-2xl text-left text-xs divide-y divide-gray-100 dark:divide-zinc-800 space-y-3 divide-solid">
            <div className="pb-3 flex justify-between font-mono">
              <span className="text-gray-400 font-bold">ORDER ID:</span>
              <span className="font-extrabold text-zinc-900 dark:text-white uppercase">{successOrder.id}</span>
            </div>
            <div className="py-3 flex justify-between">
              <span className="text-gray-400 font-bold">{t('Receiver Name:', 'প্রাপকের নাম:')}</span>
              <span className="font-bold text-zinc-800 dark:text-gray-200">{successOrder.customerInfo.name}</span>
            </div>
            <div className="py-3 flex justify-between">
              <span className="text-gray-400 font-bold">{t('Delivery Destination:', 'ডেলিভারি ঠিকানা:')}</span>
              <span className="font-bold text-zinc-800 dark:text-gray-200 text-right truncate max-w-[200px]" title={successOrder.customerInfo.address}>
                {successOrder.customerInfo.upazila}, {successOrder.customerInfo.district}
              </span>
            </div>
            <div className="py-3 flex justify-between">
              <span className="text-gray-400 font-bold">{t('Payment Mode:', 'পেমেন্ট মাধ্যম:')}</span>
              <span className="font-bold text-primary uppercase">{successOrder.paymentMethod}</span>
            </div>
            <div className="pt-3 flex justify-between font-bold">
              <span className="text-zinc-900 dark:text-white uppercase">{t('Total Amount Paid:', 'সর্বমোট পেমেন্ট মূল্য:')}</span>
              <span className="text-primary text-sm">৳{successOrder.total}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-4 justify-center">
            <button
              onClick={() => setCurrentView('account')}
              className="px-6 py-3.5 bg-black dark:bg-white text-white dark:text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-colors hover:bg-zinc-900"
            >
              {t('Track Order Progress', 'অর্ডার ট্র্যাক করুন')}
            </button>
            <button
              onClick={() => setCurrentView('home')}
              className="px-6 py-3.5 bg-primary hover:bg-primary-dark text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-primary/15 transition-all"
            >
              {t('Continue Shopping', 'শপিং করতে থাকুন')}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 select-none">
      
      {/* Back button */}
      <button 
        onClick={() => setCurrentView('cart')}
        className="flex items-center gap-1.5 text-xs font-bold text-gray-400 hover:text-primary mb-6 transition-colors"
      >
        <ArrowLeft size={14} />
        {t('Back to Cart basket', 'কার্ট ঝুড়িতে ফিরে যান')}
      </button>

      <h1 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-white mb-8 uppercase tracking-wide border-b border-gray-100 dark:border-zinc-900 pb-4">
        {t('Complete Your Order Checkout', 'অর্ডার চেকআউট সম্পন্ন করুন')}
      </h1>

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* --- LEFT COLUMN: DELIVERY DETAILS (7 cols) --- */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Quick-select address block if logged in */}
          {userProfile.savedAddresses.length > 0 && (
            <div className="bg-gray-50/50 dark:bg-zinc-900/30 p-5 rounded-2xl border border-gray-100 dark:border-zinc-850">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-3">{t('Quick Select Saved Address:', 'সংরক্ষিত ঠিকানা থেকে নির্বাচন করুন:')}</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {userProfile.savedAddresses.map((addr) => (
                  <div
                    key={addr.id}
                    onClick={() => handleSavedAddressSelect(addr)}
                    className="p-3 bg-white dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl cursor-pointer hover:border-primary hover:bg-primary/5 transition-all text-xs"
                  >
                    <span className="font-extrabold block text-zinc-900 dark:text-white mb-1">{addr.label}</span>
                    <p className="text-gray-400 truncate">{addr.receiverName} - {addr.phone}</p>
                    <p className="text-gray-400 truncate mt-0.5">{addr.fullAddress}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 sm:p-8 rounded-3xl space-y-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
              {t('Delivery Address Info', 'ডেলিভারি ঠিকানা ও তথ্য')}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  <User size={12} className="text-primary" />
                  {t('Receiver Name', 'গ্রাহকের নাম')} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Md. Maruf Islam"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
                />
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  ✉ {t('Email Address', 'ইমেইল ঠিকানা')}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="marufislam614@gmail.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Phone */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  <Phone size={12} className="text-primary" />
                  {t('Phone Number', 'মোবাইল নম্বর')} *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 01712345678"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
                />
              </div>

              {/* Alt Phone */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  <Phone size={12} className="text-gray-400" />
                  {t('Alternative Phone', 'বিকল্প মোবাইল নম্বর')}
                </label>
                <input
                  type="tel"
                  value={altPhone}
                  onChange={(e) => setAltPhone(e.target.value)}
                  placeholder="e.g. 01912345678"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* District Select */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  🗺 {t('District', 'জেলা')} *
                </label>
                <select
                  value={selectedDistrict.name}
                  onChange={handleDistrictChange}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white focus:outline-none"
                >
                  {DISTRICTS_LIST.map((dist) => (
                    <option key={dist.name} value={dist.name}>
                      {t(dist.name, dist.bnName)} (৳{dist.deliveryCharge})
                    </option>
                  ))}
                </select>
              </div>

              {/* Upazila Select */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                  🗺 {t('Upazila / Sub-district', 'উপজেলা')} *
                </label>
                <select
                  value={selectedUpazilaName}
                  onChange={(e) => setSelectedUpazilaName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white focus:outline-none"
                >
                  {selectedDistrict.upazilas.map((upz) => (
                    <option key={upz.name} value={upz.name}>
                      {t(upz.name, upz.bnName)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Address */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                📍 {t('Full Delivery Address', 'পূর্ণ ঠিকানা')} *
              </label>
              <textarea
                required
                rows={3}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={t('e.g. Village/Area, House Holding, Road details...', 'গ্রাম/মহল্লা, বাসা/হোল্ডিং নম্বর ও রোডের বিবরণ লিখুন...')}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
              />
            </div>

            {/* Note */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                <FileText size={12} className="text-gray-400" />
                {t('Order Note', 'অর্ডার নোট')}
              </label>
              <textarea
                rows={2}
                value={orderNote}
                onChange={(e) => setOrderNote(e.target.value)}
                placeholder={t('e.g. Special courier instructions, call details...', 'ডেলিভারি নিয়ে কোনো বিশেষ নির্দেশনা থাকলে লিখুন...')}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-950 text-xs text-zinc-900 dark:text-white"
              />
            </div>

          </div>

          {/* --- PAYMENT OPTIONS BLOCK --- */}
          <div className="bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-850 p-6 sm:p-8 rounded-3xl space-y-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-900 dark:text-white border-l-2 border-primary pl-3 mb-6">
              {t('Select Payment Method', 'পেমেন্ট মাধ্যম নির্বাচন করুন')}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'cod', title: t('Cash On Delivery', 'ক্যাশ অন ডেলিভারি'), desc: t('Pay with cash on arrival', 'পণ্য বুঝে পেয়ে মূল্য পরিশোধ করুন'), icon: '📦' },
                { id: 'bkash', title: t('bKash Payment', 'বিকাশ পেমেন্ট'), desc: t('Simulated bKash sandbox', 'বিকাশ ওয়ালেট থেকে ইনস্ট্যান্ট পেমেন্ট'), icon: '৳' },
                { id: 'nagad', title: t('Nagad Wallet', 'নগদ পেমেন্ট'), desc: t('Simulated Nagad sandbox', 'নগদ ওয়ালেট থেকে সহজ পেমেন্ট'), icon: '৳' },
                { id: 'rocket', title: t('Rocket Wallet', 'রকেট পেমেন্ট'), desc: t('Rocket simulated sandbox', 'রকেট ওয়ালেট থেকে সহজ পেমেন্ট'), icon: '৳' },
                { id: 'sslcommerz', title: t('SSLCommerz Card', 'ভিসা/মাস্টারকার্ড'), desc: t('Direct local banking cards', 'ডেবিট/ক্রেডিট কার্ডের মাধ্যমে পেমেন্ট'), icon: '💳' }
              ].map((pm) => (
                <div
                  key={pm.id}
                  onClick={() => setPaymentMethod(pm.id as any)}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${paymentMethod === pm.id ? 'border-primary bg-primary/5 shadow-md' : 'border-gray-150 dark:border-zinc-800 bg-white dark:bg-zinc-950/40 hover:border-gray-300'}`}
                >
                  <span className="text-xl block mb-2">{pm.icon}</span>
                  <span className="text-xs font-extrabold block text-zinc-900 dark:text-white">{pm.title}</span>
                  <span className="text-[10px] text-gray-400 block mt-1 leading-relaxed">{pm.desc}</span>
                </div>
              ))}
            </div>

          </div>

        </div>

        {/* --- RIGHT COLUMN: ORDER SUMMARY (5 cols) --- */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-zinc-950 text-white rounded-3xl p-6 sm:p-8 space-y-6 border border-zinc-900 shadow-2xl">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400 border-b border-zinc-900 pb-3">
              {t('Order Summary Checkout', 'অর্ডার সারাংশ চেকআউট')}
            </h3>

            {/* Cart products list review */}
            <div className="divide-y divide-zinc-900 space-y-3.5 max-h-64 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={item.id} className="flex gap-3 items-center pt-3.5 first:pt-0">
                  <img src={item.product.images[0]} alt="" className="w-12 h-12 object-cover rounded-xl border border-zinc-900 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-gray-200 truncate leading-tight">{t(item.product.name.en, item.product.name.bn)}</h4>
                    <p className="text-[10px] text-gray-400 mt-0.5">{item.selectedColor || 'Default'} | {item.selectedSize || 'Standard'}</p>
                    <p className="text-[10px] text-zinc-500">Qty: {item.quantity}</p>
                  </div>
                  <span className="text-xs font-bold text-primary shrink-0">৳{item.product.price * item.quantity}</span>
                </div>
              ))}
            </div>

            {/* Receipt price sums */}
            <div className="border-t border-zinc-900 pt-5 space-y-3 text-xs text-gray-400 font-medium">
              <div className="flex justify-between">
                <span>{t('Total Products Price:', 'মোট পণ্যের দাম:')}</span>
                <span className="text-white font-bold">৳{subtotal}</span>
              </div>

              {couponCode && (
                <div className="flex justify-between text-success">
                  <span>{t(`Applied Discount (${couponCode}):`, `কুপন ডিসকাউন্ট (${couponCode}):`)}</span>
                  <span className="font-bold">-৳{discountAmount}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>{t('Shipping Delivery Fee:', 'ডেলিভারি চার্জ:')}</span>
                <span className="text-white font-bold">৳{deliveryCharge}</span>
              </div>
            </div>

            {/* Total */}
            <div className="pt-5 border-t border-zinc-900 flex justify-between items-baseline">
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">{t('Grand Total:', 'সর্বমোট পরিশোধ মূল্য:')}</span>
              <span className="text-2xl font-extrabold text-primary">৳{finalTotal}</span>
            </div>

            {/* Submit trigger button */}
            <button
              type="submit"
              disabled={isOrdering}
              className="w-full bg-primary hover:bg-primary-dark disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-extrabold py-4 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-primary/25 transition-all mt-4 hover:scale-103"
              id="confirm-checkout-btn"
            >
              {isOrdering ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>{t('Processing Secure Checkout...', 'অর্ডার প্লেস হচ্ছে...')}</span>
                </>
              ) : (
                <>
                  <CheckCircle size={15} />
                  <span>{t('Confirm Order (Cash on Delivery)', 'অর্ডার নিশ্চিত করুন')}</span>
                </>
              )}
            </button>

            <p className="text-[9px] text-zinc-500 text-center leading-relaxed">
              {t('By placing order, you agree to the Terms of Service & Refund policies of Trendify Sherpur. All payments are secured.', 'অর্ডার সাবমিট করার সাথে সাথে আপনি ট্রেন্ডীফাই শেরপুরের শর্তাবলী ও রিফান্ড নীতিমালার সাথে একমত পোষণ করছেন।')}
            </p>
          </div>
        </div>

      </form>

    </div>
  );
};
