/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  CartItem, 
  Order, 
  AppNotification, 
  ActiveView, 
  SavedAddress,
  CustomerInfo
} from '../types';
import { DEFAULT_SAVED_ADDRESSES, PRODUCTS_DATABASE } from '../data';

interface AppContextType {
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  cart: CartItem[];
  addToCart: (product: Product, color?: string, size?: string, qty?: number) => void;
  updateCartQty: (cartItemId: string, qty: number) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  wishlist: Product[];
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;
  currentView: ActiveView;
  setCurrentView: (view: ActiveView) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategoryFilter: string;
  setSelectedCategoryFilter: (cat: string) => void;
  priceRangeFilter: [number, number];
  setPriceRangeFilter: (range: [number, number]) => void;
  ratingFilter: number | null;
  setRatingFilter: (rating: number | null) => void;
  brandFilter: string;
  setBrandFilter: (brand: string) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  recentlyViewed: Product[];
  addToRecentlyViewed: (product: Product) => void;
  notifications: AppNotification[];
  addNotification: (titleEn: string, titleBn: string, messageEn: string, messageBn: string, type: 'order' | 'promo' | 'system') => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  userProfile: {
    name: string;
    email: string;
    phone: string;
    savedAddresses: SavedAddress[];
  };
  updateUserProfile: (profile: { name: string; email: string; phone: string }) => void;
  addSavedAddress: (address: Omit<SavedAddress, 'id'>) => void;
  removeSavedAddress: (id: string) => void;
  orders: Order[];
  placeOrder: (order: Order) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  isLoggedIn: boolean;
  setIsLoggedIn: (loggedIn: boolean) => void;
  t: (keyEn: string, keyBn: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- Language state ---
  const [language, setLanguageState] = useState<'en' | 'bn'>(() => {
    return (localStorage.getItem('ts_language') as 'en' | 'bn') || 'en';
  });

  const setLanguage = (lang: 'en' | 'bn') => {
    setLanguageState(lang);
    localStorage.setItem('ts_language', lang);
  };

  // --- Theme state ---
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('ts_theme') as 'light' | 'dark') || 'light';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('ts_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // --- View and Product states ---
  const [currentView, setCurrentView] = useState<ActiveView>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // --- Search & Filter states ---
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('all');
  const [priceRangeFilter, setPriceRangeFilter] = useState<[number, number]>([0, 25000]);
  const [ratingFilter, setRatingFilter] = useState<number | null>(null);
  const [brandFilter, setBrandFilter] = useState('all');
  const [sortBy, setSortBy] = useState('trending');

  // --- Cart state ---
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('ts_cart');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('ts_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product, color?: string, size?: string, qty: number = 1) => {
    const compColor = color || (product.colors && product.colors.length > 0 ? product.colors[0] : undefined);
    const compSize = size || (product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined);
    const id = `${product.id}_${compColor || 'none'}_${compSize || 'none'}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.id === id);
      if (existing) {
        return prev.map((item) => 
          item.id === id ? { ...item, quantity: item.quantity + qty } : item
        );
      }
      return [...prev, { id, product, selectedColor: compColor, selectedSize: compSize, quantity: qty }];
    });

    addNotification(
      'Added to Cart',
      'কার্টে যোগ করা হয়েছে',
      `"${product.name.en}" has been added to your shopping cart.`,
      `"${product.name.bn}" আপনার শপিং কার্টে যোগ করা হয়েছে।`,
      'system'
    );
  };

  const updateCartQty = (cartItemId: string, qty: number) => {
    if (qty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) => 
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity: qty } : item))
    );
  };

  const removeFromCart = (cartItemId: string) => {
    const item = cart.find(i => i.id === cartItemId);
    setCart((prev) => prev.filter((i) => i.id !== cartItemId));
    if (item) {
      addNotification(
        'Removed from Cart',
        'কার্ট থেকে বাদ দেওয়া হয়েছে',
        `"${item.product.name.en}" was removed from your cart.`,
        `"${item.product.name.bn}" আপনার কার্ট থেকে সরানো হয়েছে।`,
        'system'
      );
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  // --- Wishlist state ---
  const [wishlist, setWishlist] = useState<Product[]>(() => {
    const saved = localStorage.getItem('ts_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('ts_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const toggleWishlist = (product: Product) => {
    const isExist = wishlist.some((p) => p.id === product.id);
    if (isExist) {
      setWishlist((prev) => prev.filter((p) => p.id !== product.id));
      addNotification(
        'Removed from Wishlist',
        'উইশলিস্ট থেকে সরানো হয়েছে',
        `"${product.name.en}" removed from wishlist.`,
        `"${product.name.bn}" উইশলিস্ট থেকে সরানো হয়েছে।`,
        'system'
      );
    } else {
      setWishlist((prev) => [...prev, product]);
      addNotification(
        'Added to Wishlist',
        'উইশলিস্টে যোগ করা হয়েছে',
        `"${product.name.en}" saved to your wishlist.`,
        `"${product.name.bn}" আপনার উইশলিস্টে সংরক্ষণ করা হয়েছে।`,
        'system'
      );
    }
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some((p) => p.id === productId);
  };

  // --- Recently Viewed ---
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>(() => {
    const saved = localStorage.getItem('ts_recent');
    return saved ? JSON.parse(saved) : [];
  });

  const addToRecentlyViewed = (product: Product) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((p) => p.id !== product.id);
      const updated = [product, ...filtered].slice(0, 6); // Keep last 6 items
      localStorage.setItem('ts_recent', JSON.stringify(updated));
      return updated;
    });
  };

  // --- Notifications state ---
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem('ts_notifications');
    if (saved) return JSON.parse(saved);
    
    // Default initial notification
    return [
      {
        id: 'notif-welcome',
        title: { en: 'Welcome to Trendify Sherpur!', bn: 'ট্রেন্ডিফাই শেরপুরে আপনাকে স্বাগতম!' },
        message: { 
          en: 'Get premium products directly from Sherpur & global brands with flat home delivery. Enjoy 15% discount using coupon: SHERPUR50', 
          bn: 'সেরা মানের পণ্য সরাসরি শেরপুর ও বৈশ্বিক ব্রান্ড থেকে হোম ডেলিভারি পান। SHERPUR50 কুপন ব্যবহার করে উপভোগ করুন ১৫% ডিসকাউন্ট।' 
        },
        date: new Date().toISOString(),
        isRead: false,
        type: 'promo'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('ts_notifications', JSON.stringify(notifications));
  }, [notifications]);

  const addNotification = (titleEn: string, titleBn: string, messageEn: string, messageBn: string, type: 'order' | 'promo' | 'system') => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: { en: titleEn, bn: titleBn },
      message: { en: messageEn, bn: messageBn },
      date: new Date().toISOString(),
      isRead: false,
      type
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => 
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  // --- Login State ---
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('ts_is_logged_in') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('ts_is_logged_in', isLoggedIn ? 'true' : 'false');
  }, [isLoggedIn]);

  // --- User Profile & Address state ---
  const [userProfile, setUserProfile] = useState(() => {
    const saved = localStorage.getItem('ts_profile');
    if (saved) return JSON.parse(saved);
    return {
      name: 'Md. Maruf Islam',
      email: 'marufislam614@gmail.com',
      phone: '01712345678',
      savedAddresses: DEFAULT_SAVED_ADDRESSES
    };
  });

  useEffect(() => {
    localStorage.setItem('ts_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  const updateUserProfile = (profile: { name: string; email: string; phone: string }) => {
    setUserProfile((prev: any) => ({
      ...prev,
      ...profile
    }));
    addNotification(
      'Profile Updated',
      'প্রোফাইল আপডেট করা হয়েছে',
      'Your account profile information has been successfully updated.',
      'আপনার অ্যাকাউন্ট প্রোফাইল তথ্য সফলভাবে আপডেট করা হয়েছে।',
      'system'
    );
  };

  const addSavedAddress = (address: Omit<SavedAddress, 'id'>) => {
    const newAddr: SavedAddress = {
      ...address,
      id: `addr-${Date.now()}`
    };
    setUserProfile((prev: any) => ({
      ...prev,
      savedAddresses: [...prev.savedAddresses, newAddr]
    }));
    addNotification(
      'Address Added',
      'ঠিকানা যোগ করা হয়েছে',
      `New address "${address.label}" added to your profile.`,
      `নতুন ঠিকানা "${address.label}" আপনার প্রোফাইলে যোগ করা হয়েছে।`,
      'system'
    );
  };

  const removeSavedAddress = (id: string) => {
    setUserProfile((prev: any) => ({
      ...prev,
      savedAddresses: prev.savedAddresses.filter((a: any) => a.id !== id)
    }));
    addNotification(
      'Address Removed',
      'ঠিকানা মুছে ফেলা হয়েছে',
      'An address was deleted from your account dashboard.',
      'আপনার অ্যাকাউন্ট ড্যাশবোর্ড থেকে একটি ঠিকানা মুছে ফেলা হয়েছে।',
      'system'
    );
  };

  // --- Orders database state ---
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('ts_orders');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('ts_orders', JSON.stringify(orders));
  }, [orders]);

  const placeOrder = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    clearCart();
    addNotification(
      'Order Placed Successfully!',
      'অর্ডার সফলভাবে সম্পন্ন হয়েছে!',
      `Thank you! Order #${order.id} has been placed. Track status inside your account.`,
      `ধন্যবাদ! আপনার অর্ডার #${order.id} সফলভাবে গ্রহণ করা হয়েছে। আপনার অ্যাকাউন্ট থেকে ট্র্যাক করুন।`,
      'order'
    );
  };

  // --- Helper translator function ---
  const t = (keyEn: string, keyBn: string) => {
    return language === 'en' ? keyEn : keyBn;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        toggleTheme,
        cart,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearCart,
        wishlist,
        toggleWishlist,
        isInWishlist,
        currentView,
        setCurrentView,
        selectedProduct,
        setSelectedProduct,
        searchQuery,
        setSearchQuery,
        selectedCategoryFilter,
        setSelectedCategoryFilter,
        priceRangeFilter,
        setPriceRangeFilter,
        ratingFilter,
        setRatingFilter,
        brandFilter,
        setBrandFilter,
        sortBy,
        setSortBy,
        recentlyViewed,
        addToRecentlyViewed,
        notifications,
        addNotification,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        userProfile,
        updateUserProfile,
        addSavedAddress,
        removeSavedAddress,
        orders,
        placeOrder,
        quickViewProduct,
        setQuickViewProduct,
        isLoggedIn,
        setIsLoggedIn,
        t
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
