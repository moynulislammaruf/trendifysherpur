/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { LiveChat } from './components/LiveChat';
import { QuickViewModal } from './components/QuickViewModal';

// Views
import { HomeView } from './views/HomeView';
import { ProductView } from './views/ProductView';
import { CartView } from './views/CartView';
import { CheckoutView } from './views/CheckoutView';
import { AccountView } from './views/AccountView';
import { SearchView } from './views/SearchView';

import { motion, AnimatePresence } from 'motion/react';

// Wrapper component to consume AppContext and manage theme class on html
const AppContent: React.FC = () => {
  const { currentView, theme, t } = useApp();

  // Handle active theme class binding on DOM element
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Render view router based on current global routing state
  const renderActiveView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView />;
      case 'product-details':
        return <ProductView />;
      case 'cart':
        return <CartView />;
      case 'checkout':
        return <CheckoutView />;
      case 'account':
        return <AccountView />;
      case 'search-results':
        return <SearchView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors duration-300 flex flex-col justify-between font-sans">
      
      {/* 1. STICKY BRAND HEADER */}
      <Header />

      {/* 2. DYNAMIC MAIN PORTION WITH PAGE ROUTING AND TRANSITIONS */}
      <main className="flex-grow pt-24 pb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="w-full"
          >
            {renderActiveView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 3. PREMIUM PERSISTENT FOOTER WITH COMPREHENSIVE LINKS */}
      <Footer />

      {/* 4. OVERLAYS & PORTALS */}
      <QuickViewModal />
      <LiveChat />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
