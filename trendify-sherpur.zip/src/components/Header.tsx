/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS_DATABASE } from '../data';
import { Product } from '../types';
import { 
  Search, 
  Heart, 
  ShoppingBag, 
  Bell, 
  User, 
  Mic, 
  Menu, 
  X, 
  Globe, 
  Sun, 
  Moon, 
  Sparkles,
  LogOut,
  ChevronRight,
  Sparkle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    cart,
    wishlist,
    currentView,
    setCurrentView,
    setSelectedProduct,
    searchQuery,
    setSearchQuery,
    setSelectedCategoryFilter,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isLoggedIn,
    setIsLoggedIn,
    userProfile,
    t
  } = useApp();

  // Component States
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [searchSuggestions, setSearchSuggestions] = useState<Product[]>([]);
  const [isVoiceSearching, setIsVoiceSearching] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Login Form States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [registerName, setRegisterName] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');

  const searchRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Handle Search Input Change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (query.trim() === '') {
      setSearchSuggestions([]);
    } else {
      const filtered = PRODUCTS_DATABASE.filter(p => 
        p.name.en.toLowerCase().includes(query.toLowerCase()) || 
        p.name.bn.includes(query) ||
        p.brand.toLowerCase().includes(query.toLowerCase())
      );
      setSearchSuggestions(filtered.slice(0, 5));
    }
  };

  const handleSuggestionClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentView('product-details');
    setIsSearchFocused(false);
    setSearchQuery('');
  };

  const executeSearch = (queryStr: string) => {
    setSearchQuery(queryStr);
    setSelectedCategoryFilter('all');
    setCurrentView('search-results');
    setIsSearchFocused(false);
  };

  // Simulated Voice Search
  const startVoiceSearch = () => {
    setIsVoiceSearching(true);
    setVoiceText(t('Listening...', 'শুনছি...'));
    
    const phrases = [
      t('Premium Perfume', 'পারফিউম'),
      t('Tulshimala Rice', 'তুলশীমালা চাল'),
      t('Luxury Watch', 'বিলাসবহুল ঘড়ি'),
      t('Men Punjabi', 'পাঞ্জাবি')
    ];
    
    // Choose a random phrase to simulate voice recognition
    setTimeout(() => {
      const recognized = phrases[Math.floor(Math.random() * phrases.length)];
      setVoiceText(`"${recognized}"`);
      setTimeout(() => {
        setIsVoiceSearching(false);
        executeSearch(recognized);
      }, 1200);
    }, 2000);
  };

  // Handle Login/Register Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) return;
    
    setIsLoggedIn(true);
    setIsLoginModalOpen(false);
    // Update profile email if custom input
    if (loginEmail.includes('@')) {
      userProfile.email = loginEmail;
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerName || !loginEmail || !loginPassword || !registerPhone) return;
    
    setIsLoggedIn(true);
    setIsLoginModalOpen(false);
    userProfile.name = registerName;
    userProfile.email = loginEmail;
    userProfile.phone = registerPhone;
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsProfileMenuOpen(false);
    setCurrentView('home');
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <>
      {/* --- UPPER BRAND MOTTO HEADER --- */}
      <div className="bg-black text-white py-1 px-4 text-xs font-medium tracking-wide flex justify-between items-center select-none">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-primary animate-pulse"></span>
          <span className="text-[10px] md:text-xs">
            {t('Motto:', 'মূলমন্ত্র:')} <span className="text-primary italic">"ভোগে নয়, ত্যাগে প্রকৃত সুখ 🥰"</span>
          </span>
        </div>
        <div className="flex items-center gap-4 text-[10px] md:text-xs text-gray-300">
          <span>{t('Free Delivery inside Sherpur Sadar', 'শেরপুর সদরের ভেতর ফ্রি ডেলিভারি')}</span>
          <span className="hidden md:inline">|</span>
          <span className="hidden md:inline">{t('Support: 01712-345678', 'সহায়তা: ০১৭১২-৩৪৫৬৭৮')}</span>
        </div>
      </div>

      {/* --- PRIMARY MAIN NAVIGATION HEADER --- */}
      <header className="sticky top-0 z-50 bg-white dark:bg-zinc-950 border-b border-gray-100 dark:border-zinc-900 shadow-xs backdrop-blur-md bg-opacity-95 dark:bg-opacity-95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-4">
            
            {/* LOGO & BRAND */}
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 -ml-2 text-gray-600 dark:text-gray-300 lg:hidden focus:outline-none"
                id="mobile-menu-btn"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>

              <div 
                onClick={() => { setCurrentView('home'); setSearchQuery(''); }}
                className="flex items-center gap-2 cursor-pointer select-none"
                id="brand-logo"
              >
                <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white shadow-md shadow-primary/20 relative overflow-hidden">
                  <span className="font-extrabold text-xl tracking-tighter">T</span>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-black rotate-45 flex items-center justify-center">
                    <Sparkle size={6} className="text-white -rotate-45" />
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="font-bold text-lg md:text-xl tracking-tight text-zinc-900 dark:text-white leading-tight">
                    Trendify <span className="text-primary">Sherpur</span>
                  </span>
                  <span className="text-[9px] text-gray-500 tracking-widest font-mono uppercase leading-none">
                    {t('ELEGANCE REDEFINED', 'আভিজাত্যের প্রতীক')}
                  </span>
                </div>
              </div>
            </div>

            {/* SMART SEARCH BAR (DESKTOP) */}
            <div ref={searchRef} className="hidden lg:flex flex-1 max-w-lg relative">
              <div className="relative w-full flex items-center">
                <input
                  type="text"
                  placeholder={t('Search premium perfums, watches, rice...', 'পারফিউম, ঘড়ি, তুলশীমালা চাল খুঁজুন...')}
                  value={searchQuery}
                  onChange={handleSearchChange}
                  onFocus={() => setIsSearchFocused(true)}
                  onKeyDown={(e) => e.key === 'Enter' && executeSearch(searchQuery)}
                  className="w-full px-4 py-2.5 pl-10 pr-12 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white dark:focus:bg-zinc-950 focus:border-primary dark:focus:border-primary focus:ring-1 focus:ring-primary text-sm transition-all duration-200 text-zinc-900 dark:text-white"
                  id="desktop-search-input"
                />
                <Search size={18} className="absolute left-3.5 text-gray-400" />
                <button 
                  onClick={startVoiceSearch}
                  className="absolute right-3.5 p-1 rounded-md text-gray-400 hover:text-primary hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors"
                  title="Voice Search"
                  id="voice-search-btn"
                >
                  <Mic size={16} />
                </button>
              </div>

              {/* SEARCH SUGGESTIONS DROP-DOWN */}
              <AnimatePresence>
                {isSearchFocused && (searchQuery.trim().length > 0 || searchSuggestions.length > 0) && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-xl overflow-hidden z-50 p-2"
                  >
                    {searchSuggestions.length > 0 ? (
                      <div>
                        <div className="text-[10px] uppercase font-bold tracking-wider text-gray-400 px-3 py-1.5 border-b border-gray-50 dark:border-zinc-800/50">
                          {t('Matching Products', 'সম্পর্কিত পণ্যসমূহ')}
                        </div>
                        {searchSuggestions.map((prod) => (
                          <div 
                            key={prod.id}
                            onClick={() => handleSuggestionClick(prod)}
                            className="flex items-center gap-3 p-2 hover:bg-gray-50 dark:hover:bg-zinc-800/50 rounded-xl cursor-pointer transition-colors"
                          >
                            <img src={prod.images[0]} alt={prod.name.en} className="w-10 h-10 object-cover rounded-lg bg-gray-100" />
                            <div className="flex-1 min-w-0">
                              <h4 className="text-xs font-semibold text-zinc-900 dark:text-white truncate">{t(prod.name.en, prod.name.bn)}</h4>
                              <p className="text-[10px] text-gray-400">{prod.brand}</p>
                            </div>
                            <div className="text-right">
                              <span className="text-xs font-bold text-primary">৳{prod.price}</span>
                              {prod.originalPrice > prod.price && (
                                <p className="text-[9px] text-gray-400 line-through">৳{prod.originalPrice}</p>
                              )}
                            </div>
                          </div>
                        ))}
                        <div 
                          onClick={() => executeSearch(searchQuery)}
                          className="mt-1 p-2 text-center text-xs font-semibold text-primary hover:bg-primary/5 rounded-xl cursor-pointer transition-colors"
                        >
                          {t(`View all results for "${searchQuery}"`, `"${searchQuery}" এর সব ফলাফল দেখুন`)}
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 text-center text-xs text-gray-500">
                        {t('No suggestions found. Press Enter to search.', 'কোনো সাজেশন পাওয়া যায়নি। খুঁজতে এন্টার চাপুন।')}
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* ACTIONS / CONTROLS */}
            <div className="flex items-center gap-2 md:gap-4">
              
              {/* THEME TOGGLE */}
              <button 
                onClick={toggleTheme}
                className="p-2.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300 transition-colors"
                title="Toggle Theme"
                id="theme-toggle-btn"
              >
                {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
              </button>

              {/* LANGUAGE SWITCHER */}
              <button 
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="px-2.5 py-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300 font-semibold text-xs flex items-center gap-1.5 transition-colors border border-gray-100 dark:border-zinc-800"
                title="Switch Language"
                id="language-switch-btn"
              >
                <Globe size={14} className="text-primary" />
                <span>{language === 'en' ? 'BN' : 'EN'}</span>
              </button>

              {/* WISHLIST BUTTON */}
              <button 
                onClick={() => setCurrentView('account')}
                className="p-2.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300 transition-colors relative hidden sm:inline-flex"
                title="Wishlist"
                id="wishlist-header-btn"
              >
                <Heart size={20} />
                {wishlist.length > 0 && (
                  <motion.span 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-1.5 right-1.5 w-4 h-4 bg-primary text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-xs"
                  >
                    {wishlist.length}
                  </motion.span>
                )}
              </button>

              {/* DYNAMIC CART FLOATING BAG */}
              <button 
                onClick={() => setCurrentView('cart')}
                className="p-2.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300 transition-colors relative"
                title="Shopping Cart"
                id="cart-header-btn"
              >
                <ShoppingBag size={20} />
                {cartCount > 0 && (
                  <motion.span 
                    key={cartCount}
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 bg-black dark:bg-white dark:text-black text-white text-[9px] font-extrabold rounded-full flex items-center justify-center shadow-xs"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </button>

              {/* NOTIFICATION HUB */}
              <div ref={notifRef} className="relative">
                <button 
                  onClick={() => setIsNotificationOpen(!isNotificationOpen)}
                  className="p-2.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-gray-300 transition-colors relative"
                  title="Notifications"
                  id="notifications-header-btn"
                >
                  <Bell size={20} />
                  {unreadCount > 0 && (
                    <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 border-2 border-white dark:border-zinc-950 rounded-full"></span>
                  )}
                </button>

                <AnimatePresence>
                  {isNotificationOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      className="absolute right-0 mt-3 w-80 sm:w-96 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-xl overflow-hidden z-50"
                    >
                      <div className="p-4 border-b border-gray-100 dark:border-zinc-800/80 flex justify-between items-center bg-gray-50/50 dark:bg-zinc-900/50">
                        <h3 className="text-xs font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                          <Bell size={14} className="text-primary" />
                          {t('Notifications', 'বিজ্ঞপ্তি সমূহ')} ({unreadCount})
                        </h3>
                        {unreadCount > 0 && (
                          <button 
                            onClick={markAllNotificationsAsRead}
                            className="text-[10px] text-primary hover:underline font-semibold"
                          >
                            {t('Mark all as read', 'সব পঠিত করুন')}
                          </button>
                        )}
                      </div>
                      <div className="max-h-72 overflow-y-auto divide-y divide-gray-50 dark:divide-zinc-800/50">
                        {notifications.length > 0 ? (
                          notifications.map((notif) => (
                            <div 
                              key={notif.id}
                              onClick={() => markNotificationAsRead(notif.id)}
                              className={`p-4 hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 transition-colors cursor-pointer ${!notif.isRead ? 'bg-primary/5 dark:bg-primary/5' : ''}`}
                            >
                              <div className="flex justify-between items-start gap-2 mb-1">
                                <h4 className="text-xs font-bold text-zinc-900 dark:text-white">{t(notif.title.en, notif.title.bn)}</h4>
                                <span className="text-[9px] text-gray-400 shrink-0">{new Date(notif.date).toLocaleDateString()}</span>
                              </div>
                              <p className="text-[11px] text-gray-500 dark:text-gray-400 leading-relaxed">{t(notif.message.en, notif.message.bn)}</p>
                            </div>
                          ))
                        ) : (
                          <div className="p-6 text-center text-xs text-gray-400">
                            {t('No notifications found.', 'কোনো বিজ্ঞপ্তি পাওয়া যায়নি।')}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* USER PROFILE ACTION BUTTON */}
              <div ref={profileRef} className="relative">
                {isLoggedIn ? (
                  <button 
                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                    className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer border border-gray-100 dark:border-zinc-800"
                    id="profile-menu-trigger-btn"
                  >
                    <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold text-xs uppercase">
                      {userProfile.name.charAt(0)}
                    </div>
                    <span className="text-xs font-bold text-zinc-800 dark:text-gray-200 hidden md:inline truncate max-w-[100px]">
                      {userProfile.name.split(' ')[0]}
                    </span>
                  </button>
                ) : (
                  <button 
                    onClick={() => setIsLoginModalOpen(true)}
                    className="p-2.5 rounded-xl bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white transition-colors cursor-pointer flex items-center justify-center"
                    title="Login / Register"
                    id="login-trigger-btn"
                  >
                    <User size={18} />
                  </button>
                )}

                {/* USER LOGGED IN DROP-DOWN MENU */}
                <AnimatePresence>
                  {isProfileMenuOpen && isLoggedIn && (
                    <motion.div 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      className="absolute right-0 mt-3 w-56 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-xl overflow-hidden z-50 p-1"
                    >
                      <div className="px-3 py-2.5 border-b border-gray-50 dark:border-zinc-800/80 mb-1">
                        <p className="text-xs font-extrabold text-zinc-900 dark:text-white truncate">{userProfile.name}</p>
                        <p className="text-[10px] text-gray-400 truncate">{userProfile.email}</p>
                      </div>
                      <button 
                        onClick={() => { setCurrentView('account'); setIsProfileMenuOpen(false); }}
                        className="w-full text-left px-3 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-800/50 rounded-xl transition-colors flex items-center justify-between"
                      >
                        <span>{t('Dashboard', 'ড্যাশবোর্ড')}</span>
                        <ChevronRight size={14} className="text-gray-400" />
                      </button>
                      <button 
                        onClick={() => { setCurrentView('account'); setIsProfileMenuOpen(false); }}
                        className="w-full text-left px-3 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-800/50 rounded-xl transition-colors flex items-center justify-between"
                      >
                        <span>{t('My Orders', 'আমার অর্ডারসমূহ')}</span>
                        <ChevronRight size={14} className="text-gray-400" />
                      </button>
                      <button 
                        onClick={handleLogout}
                        className="w-full text-left px-3 py-2 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl transition-colors flex items-center justify-between mt-1"
                      >
                        <span>{t('Logout', 'লগআউট')}</span>
                        <LogOut size={14} />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

            </div>
          </div>
        </div>

        {/* --- MOBILE SEARCH BAR (STICKY ROW) --- */}
        <div className="lg:hidden px-4 pb-4 pt-1 border-t border-gray-50 dark:border-zinc-900">
          <div className="relative w-full flex items-center">
            <input
              type="text"
              placeholder={t('Search premium perfumes, watches, rice...', 'পারফিউম, ঘড়ি, তুলশীমালা চাল খুঁজুন...')}
              value={searchQuery}
              onChange={handleSearchChange}
              onFocus={() => setIsSearchFocused(true)}
              onKeyDown={(e) => e.key === 'Enter' && executeSearch(searchQuery)}
              className="w-full px-4 py-2 pl-10 pr-12 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white focus:border-primary text-xs text-zinc-900 dark:text-white"
              id="mobile-search-input"
            />
            <Search size={16} className="absolute left-3 text-gray-400" />
            <button 
              onClick={startVoiceSearch}
              className="absolute right-3 p-1 rounded-md text-gray-400 hover:text-primary transition-colors"
              id="mobile-voice-search-btn"
            >
              <Mic size={14} />
            </button>
          </div>
        </div>
      </header>

      {/* --- MOBILE CATEGORY NAVIGATION DRAWER --- */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            ></motion.div>

            {/* Menu panel */}
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-80 max-w-sm bg-white dark:bg-zinc-950 p-6 shadow-2xl flex flex-col h-full z-50 overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <span className="font-bold text-lg dark:text-white">Trendify <span className="text-primary">Sherpur</span></span>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 -mr-2 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-500"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Navigation list */}
              <div className="space-y-4">
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t('Categories', 'ক্যাটাগরি')}</div>
                {[
                  { id: 'men', en: "Men's Fashion", bn: 'পুরুষদের ফ্যাশন' },
                  { id: 'women', en: "Women's Fashion", bn: 'নারীদের ফ্যাশন' },
                  { id: 'watches', en: 'Luxury Watches', bn: 'ঘড়ি' },
                  { id: 'perfume', en: 'Exquisite Perfume', bn: 'পারফিউম' },
                  { id: 'mobile-accessories', en: 'Mobile Accessories', bn: 'মোবাইল এক্সেসরিজ' },
                  { id: 'gift-items', en: 'Gift Items & Agro', bn: 'উপহার ও কৃষি পণ্য' },
                  { id: 'electronics', en: 'Electronics', bn: 'ইলেকট্রনিক্স' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSelectedCategoryFilter(item.id);
                      setCurrentView('search-results');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left py-2.5 px-3 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-xl text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors flex items-center justify-between"
                  >
                    <span>{t(item.en, item.bn)}</span>
                    <ChevronRight size={14} className="text-gray-400" />
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-gray-100 dark:border-zinc-900 space-y-4 text-xs font-medium text-gray-600 dark:text-gray-400">
                <button 
                  onClick={() => { setCurrentView('account'); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2.5 hover:text-primary transition-colors py-1.5"
                >
                  <User size={16} />
                  <span>{t('My Dashboard', 'আমার ড্যাশবোর্ড')}</span>
                </button>
                <button 
                  onClick={() => { setCurrentView('account'); setIsMobileMenuOpen(false); }}
                  className="flex items-center gap-2.5 hover:text-primary transition-colors py-1.5"
                >
                  <Heart size={16} />
                  <span>{t('Saved Wishlist', 'সংরক্ষিত উইশলিস্ট')}</span>
                </button>
              </div>

              <div className="mt-auto pt-6 border-t border-gray-100 dark:border-zinc-900 text-center">
                <p className="text-[10px] text-gray-400">© 2026 Trendify Sherpur</p>
                <p className="text-[9px] text-primary italic font-medium mt-1">"ভোগে নয়, ত্যাগে প্রকৃত সুখ 🥰"</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SIMULATED VOICE SEARCH MODAL OVERLAY --- */}
      <AnimatePresence>
        {isVoiceSearching && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-zinc-900 p-8 rounded-3xl max-w-sm w-full mx-4 shadow-2xl flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4 relative">
                <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping"></div>
                <Mic size={28} />
              </div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-2">{t('Voice Search', 'ভয়েস সার্চ')}</h3>
              <p className="text-lg font-bold text-zinc-900 dark:text-white min-h-[40px] flex items-center justify-center">{voiceText}</p>
              <p className="text-xs text-gray-500 mt-2">{t('Try saying: "Tulshimala Rice" or "Perfume"', 'বলুন: "তুলশীমালা চাল" অথবা "পারফিউম"')}</p>
              
              <button 
                onClick={() => setIsVoiceSearching(false)}
                className="mt-6 px-6 py-2 bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-gray-300 text-xs font-bold rounded-xl hover:bg-red-500 hover:text-white transition-all"
              >
                {t('Cancel', 'বাতিল')}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- LOGIN & REGISTER POPUP DIALOG --- */}
      <AnimatePresence>
        {isLoginModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLoginModalOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            ></motion.div>

            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md bg-white dark:bg-zinc-900 p-8 rounded-3xl shadow-2xl z-50 border border-gray-100 dark:border-zinc-800"
            >
              <button 
                onClick={() => setIsLoginModalOpen(false)}
                className="absolute top-5 right-5 p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-400 transition-colors"
              >
                <X size={18} />
              </button>

              <div className="text-center mb-6">
                <span className="font-extrabold text-2xl dark:text-white">Trendify <span className="text-primary">Sherpur</span></span>
                <p className="text-xs text-gray-400 mt-1">
                  {isRegistering 
                    ? t('Create your premium customer account', 'আপনার কাস্টমার অ্যাকাউন্ট তৈরি করুন') 
                    : t('Sign in to access orders & loyalty points', 'অর্ডার ও লয়্যালটি অ্যাক্সেস করতে সাইন ইন করুন')}
                </p>
              </div>

              <form onSubmit={isRegistering ? handleRegisterSubmit : handleLoginSubmit} className="space-y-4">
                {isRegistering && (
                  <>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-500 uppercase mb-1.5">{t('Full Name', 'পুরো নাম')}</label>
                      <input 
                        type="text" 
                        required
                        value={registerName}
                        onChange={(e) => setRegisterName(e.target.value)}
                        placeholder="e.g. Md. Maruf Islam"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white text-xs text-zinc-950 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-500 uppercase mb-1.5">{t('Mobile Number', 'মোবাইল নম্বর')}</label>
                      <input 
                        type="tel" 
                        required
                        value={registerPhone}
                        onChange={(e) => setRegisterPhone(e.target.value)}
                        placeholder="e.g. 01712345678"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white text-xs text-zinc-950 dark:text-white"
                      />
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-[11px] font-bold text-gray-500 uppercase mb-1.5">{t('Email Address', 'ইমেইল ঠিকানা')}</label>
                  <input 
                    type="email" 
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="marufislam614@gmail.com"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white text-xs text-zinc-950 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-500 uppercase mb-1.5">{t('Password', 'পাসওয়ার্ড')}</label>
                  <input 
                    type="password" 
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 focus:bg-white text-xs text-zinc-950 dark:text-white"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-3 bg-primary hover:bg-primary-dark text-white text-xs font-bold rounded-xl shadow-lg shadow-primary/20 transition-all uppercase tracking-wider mt-2"
                >
                  {isRegistering ? t('Create Account', 'অ্যাকাউন্ট তৈরি করুন') : t('Sign In', 'সাইন ইন')}
                </button>
              </form>

              <div className="text-center mt-6 pt-4 border-t border-gray-50 dark:border-zinc-800/80">
                <button 
                  onClick={() => setIsRegistering(!isRegistering)}
                  className="text-xs text-gray-500 hover:text-primary transition-colors"
                >
                  {isRegistering 
                    ? t('Already have an account? Sign In', 'ইতিমধ্যে অ্যাকাউন্ট আছে? সাইন ইন করুন') 
                    : t("Don't have an account? Register now", 'অ্যাকাউন্ট নেই? নতুন অ্যাকাউন্ট তৈরি করুন')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
