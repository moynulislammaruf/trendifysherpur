/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  ShoppingCart, 
  Flame, 
  Star, 
  Share2, 
  Truck, 
  CheckCircle2, 
  AlertTriangle,
  Play
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const QuickViewModal: React.FC = () => {
  const { 
    quickViewProduct, 
    setQuickViewProduct, 
    addToCart, 
    setCurrentView,
    setSelectedProduct,
    t 
  } = useApp();

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;

  // Set default variants if not set
  if (!selectedColor && product.colors && product.colors.length > 0) {
    setSelectedColor(product.colors[0]);
  }
  if (!selectedSize && product.sizes && product.sizes.length > 0) {
    setSelectedSize(product.sizes[0]);
  }

  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleAddToCart = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    setQuickViewProduct(null); // Close modal
  };

  const handleBuyNow = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    setQuickViewProduct(null); // Close modal
    setCurrentView('cart');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleMoreDetails = () => {
    setSelectedProduct(product);
    setQuickViewProduct(null);
    setCurrentView('product-details');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 select-none">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => setQuickViewProduct(null)}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs"
      ></motion.div>

      <motion.div 
        initial={{ scale: 0.95, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 15 }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className="relative w-full max-w-4xl bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl z-50 overflow-hidden border border-gray-100 dark:border-zinc-800"
      >
        {/* Close Button */}
        <button 
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-5 right-5 p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-400 hover:text-gray-900 transition-colors z-20"
        >
          <X size={18} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[85vh] overflow-y-auto">
          
          {/* LEFT COLUMN: IMAGES & MEDIA */}
          <div className="p-6 sm:p-8 flex flex-col justify-between bg-gray-50/50 dark:bg-zinc-950/20 border-r border-gray-100 dark:border-zinc-850/50">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800">
              
              {/* Image / Video render */}
              {isPlayingVideo && product.videoUrl ? (
                <video 
                  src={product.videoUrl} 
                  controls 
                  autoPlay 
                  className="w-full h-full object-cover"
                />
              ) : (
                <img 
                  src={product.images[selectedImageIdx]} 
                  alt={t(product.name.en, product.name.bn)} 
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                />
              )}

              {/* Badges Overlay */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.isFlashSale && (
                  <span className="bg-primary text-white text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md">
                    <Flame size={12} className="animate-pulse" />
                    {t('Flash Sale', 'ফ্ল্যাশ সেল')}
                  </span>
                )}
                {discountPercent > 0 && (
                  <span className="bg-black dark:bg-white text-white dark:text-black text-[10px] font-extrabold px-3 py-1 rounded-full">
                    {discountPercent}% {t('OFF', 'ছাড়')}
                  </span>
                )}
              </div>
            </div>

            {/* Thumbnail Selectors */}
            <div className="flex gap-2.5 mt-4 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => { setSelectedImageIdx(idx); setIsPlayingVideo(false); }}
                  className={`w-14 h-14 rounded-lg overflow-hidden border bg-white shrink-0 transition-all ${selectedImageIdx === idx && !isPlayingVideo ? 'border-primary ring-2 ring-primary/20 scale-95' : 'border-gray-200 hover:border-gray-400'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}

              {/* Video button if present */}
              {product.videoUrl && (
                <button
                  onClick={() => setIsPlayingVideo(true)}
                  className={`w-14 h-14 rounded-lg bg-zinc-900 border text-white flex flex-col items-center justify-center shrink-0 hover:bg-zinc-800 relative transition-all ${isPlayingVideo ? 'border-primary ring-2 ring-primary/20 scale-95' : 'border-gray-200'}`}
                >
                  <Play size={16} fill="white" />
                  <span className="text-[8px] font-bold uppercase tracking-widest mt-1">Video</span>
                </button>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN: INFORMATION & VARIANTS */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              
              {/* Product Metadata */}
              <div>
                <p className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">{product.brand}</p>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900 dark:text-white mt-1 leading-snug">
                  {t(product.name.en, product.name.bn)}
                </h2>
                
                {/* Rating & Reviews */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} size={13} fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'} />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-zinc-800 dark:text-gray-200">{product.rating}</span>
                  <span className="text-xs text-gray-400">({product.reviewsCount} {t('reviews', 'রিভিউ')})</span>
                </div>
              </div>

              {/* Price Tag */}
              <div className="flex items-baseline gap-3 bg-gray-50/50 dark:bg-zinc-900/50 p-3 rounded-2xl border border-gray-100/50 dark:border-zinc-800/50">
                <span className="text-2xl font-extrabold text-primary">৳{product.price}</span>
                {product.originalPrice > product.price && (
                  <span className="text-sm text-gray-400 line-through">৳{product.originalPrice}</span>
                )}
              </div>

              {/* Description */}
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed truncate-3-lines">
                {t(product.description.en, product.description.bn)}
              </p>

              {/* Variants: Colors */}
              {product.colors && product.colors.length > 0 && (
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">{t('Select Color', 'রং নির্বাচন করুন')}</label>
                  <div className="flex gap-2">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${selectedColor === color ? 'bg-primary border-primary text-white shadow-md shadow-primary/10 scale-95' : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-zinc-800 dark:text-gray-300 hover:border-gray-400'}`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Variants: Sizes */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">{t('Select Size', 'সাইজ নির্বাচন করুন')}</label>
                  <div className="flex gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${selectedSize === size ? 'bg-black dark:bg-white border-black dark:border-white text-white dark:text-black shadow-md scale-95' : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-zinc-800 dark:text-gray-300 hover:border-gray-400'}`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Stock Status Indicator */}
              <div className="flex items-center gap-1.5 text-xs font-semibold pt-1">
                {product.stockStatus === 'in-stock' ? (
                  <span className="text-success flex items-center gap-1">
                    <CheckCircle2 size={14} />
                    {t('In Stock - Ready for immediate dispatch', 'স্টকে আছে - দ্রুত ডেলিভারি')}
                  </span>
                ) : product.stockStatus === 'low-stock' ? (
                  <span className="text-amber-500 flex items-center gap-1">
                    <AlertTriangle size={14} />
                    {t('Only a few items left in stock!', 'সীমিত স্টক - দ্রুত অর্ডার করুন')}
                  </span>
                ) : (
                  <span className="text-red-500 flex items-center gap-1">
                    <X size={14} />
                    {t('Out of Stock - Restocking soon', 'স্টক শেষ - দ্রুত আসবে')}
                  </span>
                )}
              </div>

            </div>

            {/* CTA ACTIONS ROW */}
            <div className="mt-8 space-y-3 pt-4 border-t border-gray-100 dark:border-zinc-850">
              
              {/* Quantity Select & Add to Cart */}
              <div className="flex gap-3">
                
                {/* Quantity */}
                <div className="flex items-center border border-gray-200 dark:border-zinc-800 rounded-xl overflow-hidden bg-gray-50/50 dark:bg-zinc-950/20">
                  <button 
                    disabled={quantity <= 1}
                    onClick={() => setQuantity(quantity - 1)}
                    className="px-3 py-2 text-sm font-extrabold hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-40"
                  >
                    -
                  </button>
                  <span className="px-3 text-xs font-bold w-10 text-center">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-sm font-extrabold hover:bg-gray-100 dark:hover:bg-zinc-800"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  onClick={handleAddToCart}
                  disabled={product.stockStatus === 'out-of-stock'}
                  className="bg-zinc-950 dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white disabled:bg-gray-200 dark:disabled:bg-zinc-800 disabled:text-gray-400 font-bold px-6 py-3 rounded-xl text-xs flex-1 transition-all flex items-center justify-center gap-2 uppercase tracking-wider"
                >
                  <ShoppingCart size={15} />
                  {t('Add to Cart', 'কার্টে যোগ করুন')}
                </button>
              </div>

              {/* Buy Now & Share */}
              <div className="flex gap-3">
                <button
                  onClick={handleBuyNow}
                  disabled={product.stockStatus === 'out-of-stock'}
                  className="bg-primary hover:bg-primary-dark disabled:bg-gray-200 dark:disabled:bg-zinc-800 disabled:text-gray-400 text-white font-bold px-6 py-3 rounded-xl text-xs flex-1 transition-all uppercase tracking-wider flex items-center justify-center shadow-lg shadow-primary/10"
                >
                  {t('Buy Now', 'সরাসরি কিনুন')}
                </button>
                
                <button
                  onClick={handleShare}
                  className="border border-gray-200 dark:border-zinc-800 hover:bg-gray-50 dark:hover:bg-zinc-800 p-3 rounded-xl text-gray-500 hover:text-zinc-900 dark:hover:text-white transition-all relative"
                  title="Share Link"
                >
                  <Share2 size={16} />
                  {copiedLink && (
                    <span className="absolute bottom-full mb-1 right-0 bg-black text-white text-[9px] px-2 py-0.5 rounded-md whitespace-nowrap">
                      Copied!
                    </span>
                  )}
                </button>
              </div>

              {/* View More details button */}
              <button 
                onClick={handleMoreDetails}
                className="w-full text-center text-[11px] font-semibold text-gray-400 hover:text-primary tracking-wide transition-colors mt-2"
              >
                {t('View Full Product Specifications & Customer Reviews →', 'সম্পূর্ণ বিবরণ এবং কাস্টমার রিভিউ দেখুন →')}
              </button>

            </div>

          </div>

        </div>
      </motion.div>
    </div>
  );
};
