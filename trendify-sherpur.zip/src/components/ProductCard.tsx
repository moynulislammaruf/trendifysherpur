/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { 
  Heart, 
  Eye, 
  ShoppingCart, 
  Star, 
  Share2, 
  Flame,
  Check,
  AlertCircle
} from 'lucide-react';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    language, 
    toggleWishlist, 
    isInWishlist, 
    addToCart, 
    setCurrentView, 
    setSelectedProduct, 
    setQuickViewProduct,
    t 
  } = useApp();

  const [isHovered, setIsHovered] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const favorited = isInWishlist(product.id);
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleCardClick = () => {
    setSelectedProduct(product);
    setCurrentView('product-details');
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsAdding(true);
    addToCart(product);
    setTimeout(() => setIsAdding(false), 1200);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    setCurrentView('cart');
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(`${window.location.origin}/?product=${product.id}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    setQuickViewProduct(product);
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product);
  };

  return (
    <motion.div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-3xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col h-full select-none cursor-pointer"
      onClick={handleCardClick}
      id={`product-card-${product.id}`}
    >
      
      {/* --- IMAGE & HOVER INTERACTIVE ACTIONS CONTAINER --- */}
      <div className="relative aspect-[4/3] sm:aspect-square w-full overflow-hidden bg-gray-50/50 dark:bg-zinc-950/20">
        
        {/* Dynamic Badges overlay */}
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-1.5">
          {product.isFlashSale && (
            <span className="bg-primary text-white text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md">
              <Flame size={10} className="animate-pulse" />
              {t('Flash', 'ফ্ল্যাশ')}
            </span>
          )}
          {discountPercent > 0 && (
            <span className="bg-black dark:bg-white text-white dark:text-black text-[9px] font-extrabold px-2.5 py-1 rounded-full shadow-md">
              {discountPercent}% {t('OFF', 'ছাড়')}
            </span>
          )}
        </div>

        {/* Wishlist overlay button */}
        <button
          onClick={handleWishlistClick}
          className={`absolute top-4 right-4 z-10 w-9 h-9 rounded-xl flex items-center justify-center transition-all shadow-md ${favorited ? 'bg-primary text-white scale-95' : 'bg-white/80 hover:bg-white dark:bg-zinc-900/80 dark:hover:bg-zinc-900 text-gray-500 hover:text-primary dark:text-gray-300 dark:hover:text-primary'}`}
          title="Add to Wishlist"
        >
          <Heart size={16} fill={favorited ? 'currentColor' : 'none'} className={favorited ? 'animate-heartBeat' : ''} />
        </button>

        {/* Hover Quick actions Overlay menu */}
        <div className="absolute inset-0 bg-black/25 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-10">
          <button
            onClick={handleQuickView}
            className="w-10 h-10 rounded-xl bg-white text-zinc-900 hover:bg-primary hover:text-white flex items-center justify-center shadow-lg transition-all hover:scale-110"
            title="Quick View"
          >
            <Eye size={16} />
          </button>
          
          <button
            onClick={handleShare}
            className="w-10 h-10 rounded-xl bg-white text-zinc-900 hover:bg-primary hover:text-white flex items-center justify-center shadow-lg transition-all hover:scale-110 relative"
            title="Share Link"
          >
            <Share2 size={16} />
            {copiedLink && (
              <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-black text-white text-[8px] px-2 py-0.5 rounded-md whitespace-nowrap">
                Copied!
              </span>
            )}
          </button>
        </div>

        {/* Actual Image */}
        <img
          src={product.images[0]}
          alt={t(product.name.en, product.name.bn)}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
        />
      </div>

      {/* --- CONTENT INFORMATION CONTAINER --- */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div className="space-y-1.5">
          {/* Brand */}
          <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">
            {product.brand}
          </span>

          {/* Name */}
          <h3 className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white leading-snug hover:text-primary transition-colors h-10 overflow-hidden line-clamp-2">
            {t(product.name.en, product.name.bn)}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5">
            <div className="flex text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={11} fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'} />
              ))}
            </div>
            <span className="text-[10px] font-bold text-zinc-800 dark:text-gray-300">{product.rating}</span>
            <span className="text-[9px] text-gray-400">({product.reviewsCount})</span>
          </div>

          {/* Stock state */}
          <div className="pt-1">
            {product.stockStatus === 'in-stock' ? (
              <span className="text-[9px] font-semibold text-success bg-success/10 px-2 py-0.5 rounded-md inline-block">
                {t('In Stock', 'স্টকে আছে')}
              </span>
            ) : product.stockStatus === 'low-stock' ? (
              <span className="text-[9px] font-semibold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-md inline-block">
                {t('Low Stock', 'সীমিত স্টক')}
              </span>
            ) : (
              <span className="text-[9px] font-semibold text-red-500 bg-red-500/10 px-2 py-0.5 rounded-md inline-block">
                {t('Out of Stock', 'স্টক শেষ')}
              </span>
            )}
          </div>
        </div>

        {/* Price & Primary Action Buttons */}
        <div className="mt-4 pt-3.5 border-t border-gray-50 dark:border-zinc-850/50 space-y-3">
          
          {/* Price Tag */}
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-extrabold text-primary">৳{product.price}</span>
            {product.originalPrice > product.price && (
              <span className="text-[10px] sm:text-xs text-gray-400 line-through">৳{product.originalPrice}</span>
            )}
          </div>

          {/* Primary Shopping CTA Row */}
          <div className="flex gap-2.5">
            <button
              onClick={handleAddToCart}
              disabled={product.stockStatus === 'out-of-stock'}
              className={`flex-1 py-2 rounded-xl text-[10px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 border transition-all ${isAdding ? 'bg-success border-success text-white' : 'bg-white dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-zinc-800 dark:text-gray-300 hover:border-primary hover:text-primary dark:hover:text-primary dark:hover:border-primary disabled:opacity-40 disabled:hover:border-gray-200'}`}
              title="Add to Cart"
              id={`add-to-cart-${product.id}`}
            >
              {isAdding ? (
                <>
                  <Check size={12} />
                  {t('Added', 'যোগ হয়েছে')}
                </>
              ) : (
                <>
                  <ShoppingCart size={11} />
                  {t('Cart', 'কার্ট')}
                </>
              )}
            </button>

            <button
              onClick={handleBuyNow}
              disabled={product.stockStatus === 'out-of-stock'}
              className="flex-1 py-2 bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white disabled:opacity-40 font-bold rounded-xl text-[10px] uppercase tracking-wider transition-all flex items-center justify-center"
              title="Buy Now"
              id={`buy-now-${product.id}`}
            >
              {t('Buy Now', 'কিনুন')}
            </button>
          </div>

        </div>

      </div>

    </motion.div>
  );
};
