/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Facebook, 
  Instagram, 
  Youtube, 
  Truck, 
  ShieldCheck, 
  RefreshCw, 
  HelpCircle, 
  Mail, 
  PhoneCall, 
  MapPin, 
  Sparkles,
  ArrowRight,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Footer: React.FC = () => {
  const { t, orders } = useApp();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [trackOrderId, setTrackOrderId] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<any | null>(null);
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsSubscribed(true);
    setEmail('');
    setTimeout(() => setIsSubscribed(false), 4000);
  };

  const handleTrackOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackOrderId.trim()) return;

    const matched = orders.find(o => o.id === trackOrderId.trim());
    if (matched) {
      setTrackedOrder(matched);
    } else {
      // Simulate generic order for demonstration if no orders placed yet
      setTrackedOrder({
        id: trackOrderId.trim(),
        status: 'processing',
        date: new Date().toLocaleDateString(),
        total: 18500,
        trackingSteps: [
          { label: { en: 'Order Placed', bn: 'অর্ডার সম্পন্ন' }, isCompleted: true, description: { en: 'Your order was registered.', bn: 'আপনার অর্ডারটি নিবন্ধিত হয়েছে।' } },
          { label: { en: 'Verified & Confirmed', bn: 'যাচাই ও নিশ্চিতকৃত' }, isCompleted: true, description: { en: 'Our agent verified your details.', bn: 'আমাদের প্রতিনিধি তথ্য যাচাই করেছেন।' } },
          { label: { en: 'Dispatched', bn: 'কুরিয়ারে প্রেরিত' }, isCompleted: false, description: { en: 'Handing over to Pathao/Steadfast.', bn: 'পাঠাও/স্টিডফাস্টে হস্তান্তরের প্রক্রিয়া চলছে।' } },
          { label: { en: 'Delivered', bn: 'ডেলিভারি সম্পন্ন' }, isCompleted: false, description: { en: 'Item will arrive at your doorstep.', bn: 'পণ্য আপনার ঠিকানায় পৌঁছাবে।' } }
        ]
      });
    }
  };

  return (
    <>
      <footer className="bg-zinc-950 text-gray-400 pt-16 pb-8 border-t border-zinc-900 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* TOP USP CARDS (Daraz/Apple grade trust badges) */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 mb-12 border-b border-zinc-900">
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-900/40 border border-zinc-900">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <Truck size={24} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">{t('Fast Delivery', 'দ্রুত ডেলিভারি')}</h4>
                <p className="text-xs text-gray-400 mt-1">{t('24-48 Hours delivery in Sherpur', 'শেরপুরে ২৪-৪৮ ঘণ্টায় ডেলিভারি')}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-900/40 border border-zinc-900">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <ShieldCheck size={24} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">{t('100% Authentic', 'শতভাগ আসল পণ্য')}</h4>
                <p className="text-xs text-gray-400 mt-1">{t('Directly sourced premium brands', 'সরাসরি ব্রান্ড থেকে আমদানিকৃত')}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-900/40 border border-zinc-900">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <RefreshCw size={24} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">{t('Easy Return', 'সহজ রিটার্ন পলিসি')}</h4>
                <p className="text-xs text-gray-400 mt-1">{t('7-Day replacement warranty', '৭ দিনের রিপ্লেসমেন্ট সুবিধা')}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-900/40 border border-zinc-900">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <HelpCircle size={24} />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">{t('Dedicated Support', 'গ্রাহক সেবা')}</h4>
                <p className="text-xs text-gray-400 mt-1">{t('Call/Chat active 10 AM - 10 PM', 'সকাল ১০ টা থেকে রাত ১০ টা')}</p>
              </div>
            </div>
          </div>

          {/* MAIN FOOTER LINK GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 pb-12">
            
            {/* COLUMN 1: BRAND DETAIL */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white font-extrabold text-sm">
                  T
                </div>
                <span className="font-bold text-lg text-white">Trendify <span className="text-primary">Sherpur</span></span>
              </div>
              <p className="text-xs leading-relaxed text-gray-400">
                {t(
                  'Redefining elegance with handpicked premium products. Proudly presenting organic Tulshimala rice from Sherpur, royal perfumes, luxury watches, and contemporary fashion designed for those who appreciate premium quality.',
                  'শেরপুরের বিখ্যাত সুগন্ধি তুলশীমালা চাল, রাজকীয় পারফিউম, বিলাসবহুল ঘড়ি এবং ট্রেন্ডি ফ্যাশন সামগ্রী নিয়ে আপনার আভিজাত্যের বিশ্বস্ত ঠিকানা।'
                )}
              </p>
              <div className="pt-2 text-xs font-bold text-primary italic">
                "ভোগে নয়, ত্যাগে প্রকৃত সুখ 🥰"
              </div>
            </div>

            {/* COLUMN 2: CUSTOMER CARE */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider border-l-2 border-primary pl-3">
                {t('Customer Care', 'গ্রাহক সেবা')}
              </h4>
              <ul className="space-y-2.5 text-xs">
                <li>
                  <button onClick={() => setIsTrackModalOpen(true)} className="hover:text-primary transition-colors flex items-center gap-1">
                    <ChevronRight size={12} className="text-primary" />
                    {t('Track Order Status', 'অর্ডার ট্র্যাকিং')}
                  </button>
                </li>
                <li>
                  <a href="#faq" className="hover:text-primary transition-colors flex items-center gap-1">
                    <ChevronRight size={12} className="text-primary" />
                    {t('Frequently Asked Questions', 'জিজ্ঞাসিত প্রশ্নাবলী (FAQ)')}
                  </a>
                </li>
                <li>
                  <span className="flex items-center gap-1 cursor-default text-gray-500">
                    <ChevronRight size={12} className="text-zinc-800" />
                    {t('Become a Seller (Closed)', 'বিক্রেতা হোন (বন্ধ আছে)')}
                  </span>
                </li>
                <li>
                  <a href="#privacy" className="hover:text-primary transition-colors flex items-center gap-1">
                    <ChevronRight size={12} className="text-primary" />
                    {t('Privacy & Cookie Policy', 'গোপনীয়তা নীতিমালা')}
                  </a>
                </li>
                <li>
                  <a href="#refund" className="hover:text-primary transition-colors flex items-center gap-1">
                    <ChevronRight size={12} className="text-primary" />
                    {t('Refund & Replacement Policy', 'রিফান্ড ও রিটার্ন নীতি')}
                  </a>
                </li>
              </ul>
            </div>

            {/* COLUMN 3: CONTACT INFO */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider border-l-2 border-primary pl-3">
                {t('Contact Details', 'যোগাযোগ')}
              </h4>
              <ul className="space-y-3.5 text-xs">
                <li className="flex items-start gap-2.5">
                  <MapPin size={16} className="text-primary shrink-0 mt-0.5" />
                  <span>{t('Nayanibazar Road, Sherpur Sadar, Sherpur, Mymensingh, Bangladesh', 'নয়ানি বাজার রোড, শেরপুর সদর, শেরপুর, ময়মনসিংহ, বাংলাদেশ')}</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <PhoneCall size={16} className="text-primary shrink-0" />
                  <span>+880 1712-345678</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Mail size={16} className="text-primary shrink-0" />
                  <span>support@trendifysherpur.com</span>
                </li>
              </ul>
            </div>

            {/* COLUMN 4: NEWSLETTER & SOCIALS */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider border-l-2 border-primary pl-3">
                {t('Newsletter', 'নিউজলেটার সাবস্ক্রিপশন')}
              </h4>
              <p className="text-xs text-gray-400">
                {t('Subscribe to receive exclusive voucher codes and festival discount updates.', 'উৎসবের অফার ও ডিসকাউন্ট ভাউচার সরাসরি পেতে ইমেইল দিয়ে সাবস্ক্রাইব করুন।')}
              </p>
              
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder={t('Your Email', 'আপনার ইমেইল')}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-primary text-white flex-1"
                />
                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark text-white p-2 rounded-xl transition-all shrink-0"
                >
                  <ArrowRight size={14} />
                </button>
              </form>

              {isSubscribed && (
                <motion.p 
                  initial={{ opacity: 0, y: 5 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  className="text-[10px] text-success font-semibold"
                >
                  🎉 {t('Subscribed successfully! Thank you.', 'সফলভাবে সাবস্ক্রাইব হয়েছে! ধন্যবাদ।')}
                </motion.p>
              )}

              {/* SOCIAL MEDIA HANDLES */}
              <div className="pt-3">
                <div className="text-[10px] uppercase font-bold tracking-wider text-gray-500 mb-2">{t('Follow Us', 'সোশ্যাল মিডিয়া')}</div>
                <div className="flex gap-3">
                  <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg bg-zinc-900 hover:bg-[#1877F2] hover:text-white flex items-center justify-center transition-all">
                    <Facebook size={16} />
                  </a>
                  <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg bg-zinc-900 hover:bg-[#E4405F] hover:text-white flex items-center justify-center transition-all">
                    <Instagram size={16} />
                  </a>
                  <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg bg-zinc-900 hover:bg-[#CD201F] hover:text-white flex items-center justify-center transition-all">
                    <Youtube size={16} />
                  </a>
                  <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 rounded-lg bg-zinc-900 hover:bg-white hover:text-black flex items-center justify-center transition-all font-bold text-xs">
                    🎵
                  </a>
                </div>
              </div>
            </div>

          </div>

          {/* BOTTOM COPYRIGHT ROW */}
          <div className="pt-8 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
            <p className="text-gray-500 text-center md:text-left">
              © 2026 <span className="text-white font-bold">Trendify Sherpur</span>. {t('All Rights Reserved. Developed with premium luxury care.', 'সর্বস্বত্ব সংরক্ষিত। এটি একটি প্রিমিয়াম লাক্সারি শপ।')}
            </p>
            <div className="flex gap-4 text-gray-500">
              <a href="#terms" className="hover:text-primary transition-colors">{t('Terms of Service', 'ব্যবহারের শর্তাবলী')}</a>
              <span>•</span>
              <a href="#privacy" className="hover:text-primary transition-colors">{t('Privacy Policy', 'গোপনীয়তা নীতি')}</a>
              <span>•</span>
              <a href="#refund" className="hover:text-primary transition-colors">{t('Refund Policy', 'ফেরত নীতি')}</a>
            </div>
          </div>

        </div>
      </footer>

      {/* --- TRACK ORDER OVERLAY MODAL --- */}
      <AnimatePresence>
        {isTrackModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setIsTrackModalOpen(false); setTrackedOrder(null); setTrackOrderId(''); }}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            ></motion.div>

            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-lg bg-white dark:bg-zinc-900 p-8 rounded-3xl shadow-2xl z-50 border border-gray-100 dark:border-zinc-800"
            >
              <button 
                onClick={() => { setIsTrackModalOpen(false); setTrackedOrder(null); setTrackOrderId(''); }}
                className="absolute top-5 right-5 p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-400 transition-colors"
              >
                ✕
              </button>

              <div className="text-center mb-6">
                <Truck className="mx-auto text-primary mb-2" size={32} />
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white uppercase tracking-wider">{t('Track Your Order', 'অর্ডার ট্র্যাক করুন')}</h3>
                <p className="text-xs text-gray-400 mt-1">{t('Enter your 8-digit order number below to check transit status.', 'ট্রানজিট কন্ডিশন দেখতে আপনার ৮ সংখ্যার অর্ডার নাম্বারটি দিন।')}</p>
              </div>

              <form onSubmit={handleTrackOrder} className="flex gap-2 mb-6">
                <input
                  type="text"
                  required
                  placeholder="e.g. TS-583012"
                  value={trackOrderId}
                  onChange={(e) => setTrackOrderId(e.target.value)}
                  className="bg-gray-50/50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-primary text-zinc-900 dark:text-white flex-1 font-mono uppercase font-bold"
                />
                <button
                  type="submit"
                  className="bg-black dark:bg-white text-white dark:text-black hover:bg-primary dark:hover:bg-primary hover:text-white dark:hover:text-white font-bold px-5 py-3 rounded-xl text-xs transition-all uppercase tracking-wide"
                >
                  {t('Track', 'ট্র্যাক')}
                </button>
              </form>

              {/* TRACKING PROGRESS STEPS RESULT */}
              {trackedOrder && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6 pt-4 border-t border-gray-100 dark:border-zinc-800"
                >
                  <div className="flex justify-between items-center text-xs">
                    <div>
                      <p className="text-gray-400 font-medium">{t('Order Number:', 'অর্ডার নম্বর:')}</p>
                      <p className="font-mono font-bold text-zinc-900 dark:text-white uppercase">{trackedOrder.id}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-400 font-medium">{t('Status:', 'অবস্থা:')}</p>
                      <span className="inline-block px-2.5 py-0.5 bg-primary/10 text-primary font-bold rounded-full text-[10px]">
                        {trackedOrder.status.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Verticle Stepper */}
                  <div className="space-y-6 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100 dark:before:bg-zinc-800">
                    {trackedOrder.trackingSteps.map((step: any, idx: number) => (
                      <div key={idx} className="flex gap-4 relative">
                        <div className={`w-6.5 h-6.5 rounded-full flex items-center justify-center shrink-0 border z-10 text-[10px] font-bold ${step.isCompleted ? 'bg-primary border-primary text-white' : 'bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400'}`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className={`text-xs font-bold ${step.isCompleted ? 'text-zinc-900 dark:text-white' : 'text-gray-400'}`}>
                            {t(step.label.en, step.label.bn)}
                          </h4>
                          <p className="text-[10px] text-gray-400 mt-0.5">{t(step.description.en, step.description.bn)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
