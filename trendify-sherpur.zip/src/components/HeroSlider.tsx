/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ChevronLeft, ChevronRight, Sparkles, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Slide {
  id: number;
  image: string;
  tagline: { en: string; bn: string };
  title: { en: string; bn: string };
  description: { en: string; bn: string };
  btnText: { en: string; bn: string };
  category: string;
}

const HERO_SLIDES: Slide[] = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&q=80&w=1200',
    tagline: { en: 'LIMITED EDITION COLLECTION', bn: 'লিমিটেড এডিশন কালেকশন' },
    title: { en: 'Royal Horology & Precision Watches', bn: 'রাজকীয় আভিজাত্যের প্রিমিয়াম ঘড়ি' },
    description: { 
      en: 'Experience premium Japanese & Swiss-grade automatic watches designed for luxury and built to last.', 
      bn: 'আভিজাত্য ও আধুনিক প্রযুক্তির নিখুঁত সমন্বয়ে তৈরি স্বয়ংক্রিয় মেকানিক্যাল ঘড়ির সমাহার।' 
    },
    btnText: { en: 'Explore Watches', bn: 'ঘড়ি কালেকশন দেখুন' },
    category: 'watches'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&q=80&w=1200',
    tagline: { en: 'SENSORY ROYALTY OUD', bn: 'রাজকীয় উদ সুবাস' },
    title: { en: 'Exquisite Pure Oud Perfumes', bn: 'মনমুগ্ধকর ও রাজকীয় খাঁটি পারফিউম' },
    description: { 
      en: 'Crafted with Cambodia Agarwood, amber, and saffron for an aroma that stays fresh up to 48 hours.', 
      bn: 'খাঁটি কম্বোডিয়ান আগরউড ও জাফরানের মিশ্রণে তৈরি সুবাস, যা আপনাকে দেবে দীর্ঘস্থায়ী তাজাতা।' 
    },
    btnText: { en: 'Shop Royal Perfumes', bn: 'পারফিউম শপ করুন' },
    category: 'perfume'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1536304997881-a372c179924b?auto=format&fit=crop&q=80&w=1200',
    tagline: { en: 'HERITAGE OF SHERPUR, BANGLADESH', bn: 'শেরপুরের ঐতিহ্যবাহী সুগন্ধি' },
    title: { en: 'Premium Tulshimala Aromatic Rice', bn: 'শেরপুরের খাঁটি তুলশীমালা চাল' },
    description: { 
      en: 'The legendary "King of Rice". Hand-picked, organically farmed, and packed with heritage aroma.', 
      bn: 'উৎসবের পোলাও, বিরিয়ানি ও পায়েসের রান্নায় শেরপুরের সুগন্ধি তুলশীমালা চালের কোনো বিকল্প নেই।' 
    },
    btnText: { en: 'Order Fresh Stock', bn: 'এখনই অর্ডার করুন' },
    category: 'gift-items'
  }
];

export const HeroSlider: React.FC = () => {
  const { t, setCurrentView, setSelectedCategoryFilter } = useApp();
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto sliding carousel
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, []);

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const handleActionClick = (category: string) => {
    setSelectedCategoryFilter(category);
    setCurrentView('search-results');
  };

  return (
    <div className="relative h-[420px] md:h-[550px] w-full overflow-hidden bg-black select-none">
      
      {/* Slides view wrapper */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0.8 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0.8 }}
          transition={{ duration: 0.6 }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Background Image with elegant vignette gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-black/80 z-10" />
          <img 
            src={HERO_SLIDES[currentSlide].image} 
            alt="Hero Banner" 
            className="absolute inset-0 w-full h-full object-cover object-center transform scale-105" 
          />

          {/* Animated Slide Content (Apple-Style) */}
          <div className="absolute inset-0 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
            <div className="max-w-2xl text-left space-y-4 md:space-y-6">
              
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15, duration: 0.5 }}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/25 border border-primary/40 rounded-full text-white font-mono text-[9px] md:text-[10px] font-bold uppercase tracking-widest"
              >
                <Sparkles size={12} className="text-primary animate-pulse" />
                {t(HERO_SLIDES[currentSlide].tagline.en, HERO_SLIDES[currentSlide].tagline.bn)}
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white leading-tight tracking-tight"
              >
                {t(HERO_SLIDES[currentSlide].title.en, HERO_SLIDES[currentSlide].title.bn)}
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45, duration: 0.6 }}
                className="text-xs sm:text-sm md:text-base text-gray-300 leading-relaxed max-w-lg"
              >
                {t(HERO_SLIDES[currentSlide].description.en, HERO_SLIDES[currentSlide].description.bn)}
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.5 }}
                className="pt-2"
              >
                <button
                  onClick={() => handleActionClick(HERO_SLIDES[currentSlide].category)}
                  className="bg-primary hover:bg-primary-dark text-white font-extrabold px-6 py-3.5 rounded-xl text-xs uppercase tracking-wider flex items-center gap-2.5 shadow-lg shadow-primary/20 transition-all hover:scale-103"
                >
                  <ShoppingBag size={15} />
                  {t(HERO_SLIDES[currentSlide].btnText.en, HERO_SLIDES[currentSlide].btnText.bn)}
                </button>
              </motion.div>

            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* --- CAROUSEL NAVIGATION CONTROLS --- */}
      <button 
        onClick={handlePrev}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 w-11 h-11 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white backdrop-blur-xs transition-colors"
      >
        <ChevronLeft size={20} />
      </button>

      <button 
        onClick={handleNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 w-11 h-11 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white backdrop-blur-xs transition-colors"
      >
        <ChevronRight size={20} />
      </button>

      {/* --- SLIDE PROGRESS PIP DOTS --- */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex gap-2">
        {HERO_SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-1.5 rounded-full transition-all duration-300 ${currentSlide === idx ? 'w-6 bg-primary' : 'w-1.5 bg-white/40'}`}
          />
        ))}
      </div>

    </div>
  );
};
