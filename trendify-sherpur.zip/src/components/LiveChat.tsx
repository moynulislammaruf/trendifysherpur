/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  MessageSquare, 
  Send, 
  X, 
  Sparkles, 
  MessageCircle, 
  ChevronRight,
  Headphones
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  time: string;
}

export const LiveChat: React.FC = () => {
  const { t } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'agent',
      text: t(
        "Assalamu Alaikum! Welcome to Trendify Sherpur support. How can we elevate your shopping experience today? 😇",
        "আসসালামু আলাইকুম! ট্রেন্ডীফাই শেরপুর কাস্টমার কেয়ারে স্বাগতম। আজ আপনাকে কীভাবে সহযোগিতা করতে পারি? 😇"
      ),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    // Context-aware auto-replies
    setTimeout(() => {
      let replyText = t(
        "Thank you for contacting us! A Trendify representative is reviewing your message and will reply shortly. Feel free to call us at 01712-345678 for instant help.",
        "যোগাযোগের জন্য ধন্যবাদ! আমাদের প্রতিনিধি খুব দ্রুত আপনার মেসেজের উত্তর দিচ্ছেন। জরুরি প্রয়োজনে ফোন করুন: ০১৭১২-৩৪৫৬৭৮ নাম্বারে।"
      );

      const normalized = text.toLowerCase();
      if (normalized.includes('tulshimala') || normalized.includes('চাল') || normalized.includes('rice')) {
        replyText = t(
          "Our premium Tulshimala Rice is organically grown in Sherpur. It is handpicked, highly aromatic, and available in 1 KG and 5 KG packages. Would you like to buy now?",
          "আমাদের প্রিমিয়াম তুলশীমালা চাল সরাসরি শেরপুরের কৃষকদের থেকে সংগৃহীত। এটি সম্পূর্ণ অর্গানিক, সুগন্ধি ও ধবধবে সাদা। ১ ও ৫ কেজির প্যাকেটে পাওয়া যাচ্ছে। আপনি কি অর্ডার করতে চান?"
        );
      } else if (normalized.includes('delivery') || normalized.includes('ডেলিভারি') || normalized.includes('charge') || normalized.includes('পাঠানো')) {
        replyText = t(
          "Delivery is absolutely free within Sherpur Sadar. For Dhaka, Mymensingh, and other districts, delivery charge is BDT 100-150 and takes 48-72 hours.",
          "শেরপুর সদরের ভেতর ডেলিভারি একদম ফ্রি! ঢাকা, ময়মনসিংহ ও অন্যান্য জেলায় ডেলিভারি চার্জ ১০০-১৫০ টাকা এবং ৪৮-৭২ ঘণ্টার মধ্যে ডেলিভারি সম্পন্ন হয়।"
        );
      } else if (normalized.includes('bkash') || normalized.includes('পেমেন্ট') || normalized.includes('payment') || normalized.includes('nagad')) {
        replyText = t(
          "We support Cash On Delivery, as well as secure payments through bKash, Nagad, Rocket, and SSLCommerz cards during checkout.",
          "আমরা ক্যাশ অন ডেলিভারি (COD) সমর্থন করি। এছাড়া চেকআউটের সময় বিকাশ (bKash), নগদ (Nagad), রকেট ও কার্ড পেমেন্ট করতে পারবেন নিশ্চিন্তে।"
        );
      } else if (normalized.includes('track') || normalized.includes('অর্ডার ট্র্যাকিং') || normalized.includes('কোথায়')) {
        replyText = t(
          "You can track your order live inside the Account dashboard, or enter your order number in the 'Track Order' modal in the footer.",
          "আপনি আপনার অর্ডার ড্যাশবোর্ড থেকে লাইভ ট্র্যাক করতে পারেন, অথবা ফুটারের 'অর্ডার ট্র্যাকিং' অপশনে অর্ডার নাম্বার দিয়ে কন্ডিশন দেখতে পারেন।"
        );
      }

      const agentMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'agent',
        text: replyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setIsTyping(false);
      setMessages((prev) => [...prev, agentMsg]);
    }, 1500);
  };

  // Quick preset questions
  const quickQuestions = [
    t('Tulshimala Rice Price?', 'তুলশীমালা চালের দাম?'),
    t('Is delivery free?', 'ডেলিভারি চার্জ কত?'),
    t('Supported payment methods?', 'পেমেন্ট কীভাবে করব?'),
    t('How to track order?', 'অর্ডার ট্র্যাক করব কীভাবে?')
  ];

  return (
    <>
      {/* --- FLOATING CHAT TRIGGER BUTTONS --- */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
        
        {/* WhatsApp shortcut */}
        <motion.a 
          href="https://wa.me/8801712345678"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.05 }}
          className="w-12 h-12 rounded-full bg-[#25D366] text-white shadow-lg flex items-center justify-center hover:shadow-[#25D366]/30 transition-shadow duration-300"
          title="WhatsApp Live Chat"
        >
          <MessageCircle size={22} />
        </motion.a>

        {/* Messenger shortcut */}
        <motion.a 
          href="https://m.me/trendifysherpur"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.05 }}
          className="w-12 h-12 rounded-full bg-[#0084FF] text-white shadow-lg flex items-center justify-center hover:shadow-[#0084FF]/30 transition-shadow duration-300"
          title="Messenger Live Chat"
        >
          <MessageSquare size={20} />
        </motion.a>

        {/* Primary local chat button */}
        <motion.button 
          onClick={() => setIsOpen(!isOpen)}
          whileHover={{ scale: 1.05 }}
          className="w-14 h-14 rounded-2xl bg-primary text-white shadow-xl flex items-center justify-center hover:shadow-primary/30 transition-all duration-300 relative"
          id="local-chat-trigger"
        >
          {isOpen ? <X size={24} /> : <Headphones size={24} />}
          {!isOpen && (
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-success border-2 border-white dark:border-zinc-950 rounded-full animate-pulse"></span>
          )}
        </motion.button>
      </div>

      {/* --- CHAT BOX CONTAINER --- */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="fixed bottom-24 right-6 w-80 sm:w-96 h-[480px] bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-zinc-800 flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-zinc-950 text-white p-4 flex justify-between items-center relative">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center text-primary relative">
                  <Headphones size={18} />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-success border-2 border-zinc-950 rounded-full"></span>
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1">
                    Trendify Care
                    <Sparkles size={12} className="text-primary" />
                  </h3>
                  <p className="text-[10px] text-gray-400">{t('Active Assistance', 'অনলাইন সাপোর্ট প্রতিনিধি')}</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg hover:bg-zinc-900 text-gray-400 hover:text-white transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            {/* Chat Body Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-gray-50/30 dark:bg-zinc-900/10">
              {messages.map((msg) => (
                <div 
                  key={msg.id}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[75%] rounded-2xl p-3 text-xs leading-relaxed ${msg.sender === 'user' ? 'bg-primary text-white rounded-tr-none' : 'bg-gray-100 dark:bg-zinc-800 text-zinc-800 dark:text-gray-200 rounded-tl-none'}`}>
                    <p>{msg.text}</p>
                    <span className={`block text-[9px] text-right mt-1.5 ${msg.sender === 'user' ? 'text-orange-200' : 'text-gray-400'}`}>
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}

              {/* Typing loader */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 dark:bg-zinc-800 rounded-2xl rounded-tl-none p-3 text-xs text-gray-400 flex items-center gap-1">
                    <span>{t('Representative is typing', 'প্রতিনিধি লিখছেন')}</span>
                    <span className="w-1 h-1 bg-gray-400 rounded-full animate-bounce"></span>
                    <span className="w-1 h-1 bg-gray-400 rounded-full animate-bounce delay-100"></span>
                    <span className="w-1 h-1 bg-gray-400 rounded-full animate-bounce delay-200"></span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Quick Questions Helper Panel */}
            <div className="p-3 border-t border-gray-100 dark:border-zinc-800/80 bg-white dark:bg-zinc-900">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">{t('Quick Questions', 'সহজ প্রশ্নসমূহ')}</p>
              <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
                {quickQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(q)}
                    className="text-[10px] font-medium bg-gray-100 dark:bg-zinc-800 hover:bg-primary/10 hover:text-primary dark:hover:bg-primary/20 rounded-lg px-2.5 py-1 text-zinc-600 dark:text-gray-300 transition-colors border border-gray-200/40 dark:border-zinc-800 flex items-center gap-1"
                  >
                    <span>{q}</span>
                    <ChevronRight size={10} />
                  </button>
                ))}
              </div>
            </div>

            {/* Form Input */}
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSendMessage(inputVal); }}
              className="p-3 border-t border-gray-100 dark:border-zinc-800/80 flex gap-2 bg-white dark:bg-zinc-900"
            >
              <input
                type="text"
                placeholder={t('Type your message here...', 'আপনার বার্তাটি লিখুন...')}
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="bg-gray-50 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-primary flex-1"
              />
              <button
                type="submit"
                disabled={!inputVal.trim()}
                className="bg-primary hover:bg-primary-dark disabled:bg-gray-200 dark:disabled:bg-zinc-850 disabled:text-gray-400 text-white p-2.5 rounded-xl transition-all"
              >
                <Send size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
