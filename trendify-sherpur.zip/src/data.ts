/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, SavedAddress, Translation } from './types';

// Bangladeshi Districts & Upazilas
export interface DistrictData {
  name: string;
  bnName: string;
  deliveryCharge: number;
  upazilas: { name: string; bnName: string }[];
}

export const DISTRICTS_LIST: DistrictData[] = [
  {
    name: 'Sherpur',
    bnName: 'শেরপুর',
    deliveryCharge: 60,
    upazilas: [
      { name: 'Sherpur Sadar', bnName: 'শেরপুর সদর' },
      { name: 'Nalitabari', bnName: 'নালিতাবাড়ী' },
      { name: 'Nakla', bnName: 'নকলা' },
      { name: 'Sreebardi', bnName: 'শ্রীবরদী' },
      { name: 'Jhenaigati', bnName: 'ঝিনাইগাতী' }
    ]
  },
  {
    name: 'Dhaka',
    bnName: 'ঢাকা',
    deliveryCharge: 120,
    upazilas: [
      { name: 'Dhanmondi', bnName: 'ধানমন্ডি' },
      { name: 'Gulshan', bnName: 'গুলশান' },
      { name: 'Mirpur', bnName: 'মিরপুর' },
      { name: 'Uttara', bnName: 'উত্তরা' },
      { name: 'Savar', bnName: 'সাভার' },
      { name: 'Keraniganj', bnName: 'কেরানীগঞ্জ' }
    ]
  },
  {
    name: 'Mymensingh',
    bnName: 'ময়মনসিংহ',
    deliveryCharge: 100,
    upazilas: [
      { name: 'Mymensingh Sadar', bnName: 'ময়মনসিংহ সদর' },
      { name: 'Phulpur', bnName: 'ফুলপুর' },
      { name: 'Trishal', bnName: 'ত্রিশাল' },
      { name: 'Bhaluka', bnName: 'ভালুকা' },
      { name: 'Gaffargaon', bnName: 'গফরগাঁও' },
      { name: 'Ishwarganj', bnName: 'ঈশ্বরগঞ্জ' }
    ]
  },
  {
    name: 'Chittagong',
    bnName: 'চট্টগ্রাম',
    deliveryCharge: 150,
    upazilas: [
      { name: 'Panchlaish', bnName: 'পাঁচলাইশ' },
      { name: 'Double Mooring', bnName: 'ডবলমুরিং' },
      { name: 'Hathazari', bnName: 'হাটহাজারী' },
      { name: 'Coxs Bazar Sadar', bnName: 'কক্সবাজার সদর' },
      { name: 'Anwara', bnName: 'আনোয়ারা' }
    ]
  },
  {
    name: 'Sylhet',
    bnName: 'সিলেট',
    deliveryCharge: 150,
    upazilas: [
      { name: 'Sylhet Sadar', bnName: 'সিলেট সদর' },
      { name: 'Beanibazar', bnName: 'বিয়ানীবাজার' },
      { name: 'Golapganj', bnName: 'গোলাপগঞ্জ' },
      { name: 'Sreemangal', bnName: 'শ্রীমঙ্গল' }
    ]
  },
  {
    name: 'Rajshahi',
    bnName: 'রাজশাহী',
    deliveryCharge: 150,
    upazilas: [
      { name: 'Boalia', bnName: 'বোয়ালিয়া' },
      { name: 'Rajpara', bnName: 'রাজপাড়া' },
      { name: 'Puthia', bnName: 'পুঠিয়া' },
      { name: 'Godagari', bnName: 'গোদাগাড়ী' }
    ]
  }
];

// Rich Product Dataset
export const PRODUCTS_DATABASE: Product[] = [
  {
    id: 'prod-001',
    name: {
      en: 'Sherpur Premium Tulshimala Rice (Hand-picked)',
      bn: 'শেরপুরের প্রিমিয়াম তুলশীমালা চাল (হাতে বাছা)'
    },
    brand: 'Sherpur Agro Heritage',
    price: 110,
    originalPrice: 130,
    images: [
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1536304997881-a372c179924b?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1626125316492-23c8a37f59d5?auto=format&fit=crop&q=80&w=600'
    ],
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sizes: ['1 KG', '5 KG', '10 KG'],
    colors: [],
    category: 'gift-items',
    rating: 4.9,
    reviewsCount: 148,
    stockStatus: 'in-stock',
    isFeatured: true,
    isBestSeller: true,
    description: {
      en: 'Tulshimala Rice is the pride of Sherpur, Bangladesh. Known for its small grains, exquisite aroma, and elite taste, it is often called the "King of Rice" and is perfect for Polao, Biryani, Payesh, and premium local desserts. Organic and traditionally processed.',
      bn: 'তুলশীমালা চাল শেরপুরের গৌরব। এর ছোট দানা, চমৎকার সুবাস ও রাজকীয় স্বাদের জন্য এটি চালের রাজা হিসেবে পরিচিত। পোলাও, বিরিয়ানি, পায়েস ও উৎসবের রান্নায় এটি সেরা। সম্পূর্ণ অর্গানিক ও ঐতিহ্যবাহী পদ্ধতিতে প্রস্তুতকৃত।'
    },
    specifications: [
      { key: { en: 'Grain Type', bn: 'দানার ধরণ' }, value: { en: 'Aromatic Tiny Grain', bn: 'সুগন্ধি ছোট দানা' } },
      { key: { en: 'Origin', bn: 'উৎপত্তিস্থল' }, value: { en: 'Sherpur District, Bangladesh', bn: 'শেরপুর জেলা, বাংলাদেশ' } },
      { key: { en: 'Cultivation', bn: 'চাষ পদ্ধতি' }, value: { en: 'Organic & Traditional Rainfed', bn: 'জৈব ও প্রাকৃতিক বৃষ্টির পানি' } },
      { key: { en: 'Net Weight', bn: 'নিট ওজন' }, value: { en: '1 KG / 5 KG Available', bn: '১ কেজি / ৫ কেজি উপলভ্য' } }
    ],
    shippingInfo: {
      en: 'Fast shipping across Bangladesh. Delivered in 24-48 hours within Sherpur, and 3-4 days nationwide.',
      bn: 'সমগ্র বাংলাদেশে দ্রুত ডেলিভারি। শেরপুরে ২৪-৪৮ ঘণ্টায় এবং দেশের অন্যান্য স্থানে ৩-৪ দিনে ডেলিভারি।'
    },
    returnPolicy: {
      en: '7-day replacement warranty for quality issues. Food items must be unopened.',
      bn: 'মানসম্মত সমস্যার জন্য ৭ দিনের রিটার্ন গ্যারান্টি। খাদ্যদ্রব্য অবশ্যই অক্ষত থাকতে হবে।'
    },
    reviews: [
      {
        id: 'rev-001-1',
        user: 'Mahmudul Hasan',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-06-15',
        comment: {
          en: 'Incredibly aromatic! The Polao made with this rice was the highlight of our Eid. Highly recommended.',
          bn: 'অসাধারণ সুবাস! এই চালের পোলাও ঈদের সবচেয়ে আকর্ষণীয় খাবার ছিল। অত্যন্ত রেকমেন্ডেড।'
        }
      },
      {
        id: 'rev-001-2',
        user: 'Nusrat Jahan',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-02',
        comment: {
          en: 'Pure authentic Tulshimala rice directly from Sherpur. Fast delivery and premium packaging.',
          bn: 'শেরপুরের খাঁটি তুলশীমালা চাল। চমৎকার প্যাকেজিং ও দ্রুত ডেলিভারি।'
        }
      }
    ],
    questions: [
      {
        id: 'q-001-1',
        user: 'Rakib Ahmed',
        question: { en: 'Is this current season rice?', bn: 'এটি কি এই মৌসুমের নতুন চাল?' },
        answer: { en: 'Yes, this is freshly harvested and processed rice of the latest season.', bn: 'হ্যাঁ, এটি একদম সাম্প্রতিক মৌসুমের নতুন ও ফ্রেশ চাল।' },
        date: '2026-07-10'
      }
    ]
  },
  {
    id: 'prod-002',
    name: {
      en: 'Royal Oud Supreme Premium Perfume (50ml)',
      bn: 'রয়্যাল উদ সুপ্রিম প্রিমিয়াম পারফিউম (৫০ মিলি)'
    },
    brand: 'Trendify Premium Perfumes',
    price: 3200,
    originalPrice: 4500,
    images: [
      'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&q=80&w=600'
    ],
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sizes: ['50ml', '100ml'],
    colors: ['Gold Bottle', 'Midnight Black Bottle'],
    category: 'perfume',
    rating: 4.8,
    reviewsCount: 92,
    stockStatus: 'in-stock',
    isFlashSale: true,
    isFeatured: true,
    flashSaleEndTime: new Date(Date.now() + 86400000 * 2).toISOString(), // 2 days from now
    description: {
      en: 'Unleash the majestic luxury of pure Cambodian Agarwood blended with Bulgarian Rose, Sandalwood, and Spicy Amber. Long-lasting luxury fragrance designed for royalty. Stays fresh up to 48 hours.',
      bn: 'বুলগেরিয়ান রোজ, চন্দন কাঠ এবং মশলাদার অ্যাম্বারের সাথে মিশ্রিত খাঁটি কম্বোডিয়ান আগরউডের রাজকীয় সুবাস। দীর্ঘস্থায়ী এই বিলাসবহুল পারফিউমটি আপনাকে দেবে অনন্য রাজকীয় অনুভূতি। ৪৮ ঘণ্টা পর্যন্ত ঘ্রাণ স্থায়ী হয়।'
    },
    specifications: [
      { key: { en: 'Concentration', bn: 'কনসেন্ট্রেশন' }, value: { en: 'Eau de Parfum (EDP)', bn: 'ওড পারফিউম (EDP)' } },
      { key: { en: 'Fragrance Notes', bn: 'সুগন্ধি নোটসমূহ' }, value: { en: 'Oud, Saffron, Sandalwood, Amber', bn: 'উদ, জাফরান, চন্দন কাঠ, অ্যাম্বার' } },
      { key: { en: 'Longevity', bn: 'স্থায়িত্ব' }, value: { en: 'Up to 24-48 hours', bn: '২৪ থেকে ৪৮ ঘণ্টা পর্যন্ত' } },
      { key: { en: 'Gender', bn: 'লিঙ্গ' }, value: { en: 'Unisex', bn: 'ইউনিসেক্স' } }
    ],
    shippingInfo: {
      en: 'Carefully bubble-wrapped. Secure delivery nationwide with premium carriers.',
      bn: 'নিরাপদ বাবল র‍্যাপড প্যাকেজিং। প্রিমিয়াম কুরিয়ার সার্ভিসের মাধ্যমে নিরাপদ ডেলিভারি।'
    },
    returnPolicy: {
      en: 'Returns accepted within 7 days if the security seal is not broken.',
      bn: 'সিকিউরিটি সিল না ভাঙা থাকলে ৭ দিনের মধ্যে রিটার্ন প্রযোজ্য।'
    },
    reviews: [
      {
        id: 'rev-002-1',
        user: 'Tahsin Khan',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-11',
        comment: {
          en: 'Outstanding longevity! It feels like genuine high-end niche perfume costing four times more.',
          bn: 'অসাধারণ স্থায়ী ঘ্রাণ! চারগুণ বেশি দামের দামী ব্র্যান্ডের পারফিউমের মতো অনুভূতি দেয়।'
        }
      }
    ],
    questions: [
      {
        id: 'q-002-1',
        user: 'Nabil Hasan',
        question: { en: 'Is it sweet or woody?', bn: 'এটি কি মিষ্টি নাকি কাষ্ঠল সুবাস?' },
        answer: { en: 'It is warm, rich, and woody, with a very subtle sweet touch of amber and saffron.', bn: 'এটি উষ্ণ, সমৃদ্ধ ও কাষ্ঠল, সাথে অ্যাম্বার ও জাফরানের হালকা মিষ্টি আভা রয়েছে।' },
        date: '2026-07-14'
      }
    ]
  },
  {
    id: 'prod-003',
    name: {
      en: 'Chronos Elite Automatic Luxury Mechanical Watch',
      bn: 'ক্রোনোস এলিট অটোমেটিক বিলাসবহুল মেকানিক্যাল ঘড়ি'
    },
    brand: 'Chronos Horology',
    price: 18500,
    originalPrice: 24500,
    images: [
      'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&q=80&w=600'
    ],
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sizes: ['41mm Case', '38mm Case'],
    colors: ['Royal Gold Blue', 'Emerald Green Silver', 'Obsidian Black'],
    category: 'watches',
    rating: 4.95,
    reviewsCount: 37,
    stockStatus: 'low-stock',
    isNewArrival: true,
    isFeatured: true,
    description: {
      en: 'Experience absolute Swiss-grade craftsmanship with the Chronos Elite. Featuring a self-winding Japanese automatic movement, anti-scratch sapphire crystal glass, luminous hands, and 100m water resistance.',
      bn: 'ক্রোনোস এলিটের সাথে লাভ করুন সর্বোচ্চ মানের মেকানিক্যাল ঘড়ির অনুভূতি। এতে আছে স্বয়ংক্রিয় জাপানিজ মুভমেন্ট, স্ক্র্যাচ-প্রতিরোধী স্যাফায়ার ক্রিস্টাল গ্লাস এবং ১০০ মিটার ওয়াটার রেজিস্ট্যান্স।'
    },
    specifications: [
      { key: { en: 'Movement', bn: 'মুভমেন্ট' }, value: { en: 'Miyota 21-Jewel Automatic Self-Winding', bn: 'মিয়োটা ২১-জুয়েল অটোমেটিক সেলফ-উইন্ডিং' } },
      { key: { en: 'Glass Material', bn: 'গ্লাস উপাদান' }, value: { en: 'Sapphire Crystal (Anti-Reflective)', bn: 'স্যাফায়ার ক্রিস্টাল (অ্যান্টি-রিফ্লেক্টিভ)' } },
      { key: { en: 'Water Resistance', bn: 'পানি নিরোধক' }, value: { en: '10 ATM (100 Meters / 330 Feet)', bn: '১০ ATM (১০০ মিটার / ৩৩০ ফুট)' } },
      { key: { en: 'Case Material', bn: 'কেস উপাদান' }, value: { en: '316L Surgical Stainless Steel', bn: '৩১৬L সার্জিক্যাল স্টেইনলেস স্টিল' } }
    ],
    shippingInfo: {
      en: 'Insured premium parcel delivery. Comes in a gorgeous leatherette watch box with a 2-year warranty card.',
      bn: 'বীমাকৃত প্রিমিয়াম পার্সেল ডেলিভারি। আকর্ষণীয় চামড়ার বক্সে ২ বছরের ওয়ারেন্টি কার্ডসহ প্রদান করা হবে।'
    },
    returnPolicy: {
      en: '30-day money-back guarantee. The item must remain in un-sized, brand-new condition.',
      bn: '৩০ দিনের মানি-ব্যাক গ্যারান্টি। ঘড়ির বেল্ট কাটা যাবে না এবং স্ক্র্যাচ মুক্ত নতুন অবস্থায় থাকতে হবে।'
    },
    reviews: [
      {
        id: 'rev-003-1',
        user: 'Dr. S. M. Munir',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-05',
        comment: {
          en: 'Breathtaking watch! The sweep of the second hand is absolutely silent and smooth. Sapphire crystal is superb.',
          bn: 'শ্বাসরুদ্ধকর সুন্দর ঘড়ি! সেকেন্ডের কাটার সুইপিং নিখুঁত ও মসৃণ। স্যাফায়ার ক্রিস্টাল গ্লাস অসাধারণ।'
        }
      }
    ],
    questions: [
      {
        id: 'q-003-1',
        user: 'Abrar Zahid',
        question: { en: 'Does it require batteries?', bn: 'এটিতে কি ব্যাটারি লাগে?' },
        answer: { en: 'No, it is an automatic mechanical watch. It winds itself automatically with your arm movement.', bn: 'না, এটি একটি অটোমেটিক মেকানিক্যাল ঘড়ি। আপনার হাতের নড়াচড়ার মাধ্যমে এটি স্বয়ংক্রিয়ভাবে চার্জ নেয়।' },
        date: '2026-07-08'
      }
    ]
  },
  {
    id: 'prod-004',
    name: {
      en: 'Elegant Rajshahi Silk Embroidered Shari',
      bn: 'ঐতিহ্যবাহী মার্জিত রাজশাহী সিল্ক কারচুপি শাড়ি'
    },
    brand: 'Trendify Heritage',
    price: 6800,
    originalPrice: 9500,
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=600'
    ],
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sizes: ['Free Size (12 Haat)'],
    colors: ['Maroon Crimson', 'Royal Blue Gold', 'Emerald Emerald'],
    category: 'women',
    rating: 4.75,
    reviewsCount: 54,
    stockStatus: 'in-stock',
    isFlashSale: true,
    isBestSeller: true,
    flashSaleEndTime: new Date(Date.now() + 86400000).toISOString(),
    description: {
      en: 'Indulge in pure Rajshahi mulberry silk embellished with premium hand embroidery and stone works. An elegant, fast-moving collection perfect for weddings, parties, and special cultural celebrations.',
      bn: 'প্রিমিয়াম হ্যান্ড এমব্রয়ডারি এবং কারচুপির কাজে সাজানো খাঁটি রাজশাহী সিল্ক শাড়ি। বিয়ে, উৎসব বা বিশেষ যেকোনো সামাজিক উদযাপনের জন্য এটি একদম মানানসই এবং আভিজাত্যের প্রতীক।'
    },
    specifications: [
      { key: { en: 'Fabric Material', bn: 'কাপড়ের উপাদান' }, value: { en: '100% Pure Mulberry Silk', bn: '১০০% খাঁটি তুঁত সিল্ক (রাজশাহী)' } },
      { key: { en: 'Work Type', bn: 'কাজের ধরণ' }, value: { en: 'Handcrafted Zardozi & Stone', bn: 'হস্তশিল্প কারচুপি ও পাথরের কাজ' } },
      { key: { en: 'Blouse Piece', bn: 'ব্লাউজ পিস' }, value: { en: 'Included (Unstitched 1 Meter)', bn: 'সাথেই আছে (আনস্টিচড ১ মিটার)' } },
      { key: { en: 'Care', bn: 'যত্ন' }, value: { en: 'Dry Clean Only', bn: 'শুধুমাত্র ড্রাই ক্লিন' } }
    ],
    shippingInfo: {
      en: 'Delivered in a luxury gift box. Perfect for presenting as a gift.',
      bn: 'বিলাসবহুল গিফট বক্সে ডেলিভারি করা হয়। কাউকে উপহার দেওয়ার জন্য দারুণ।'
    },
    returnPolicy: {
      en: '7-day hassle-free exchange if original tags and condition are intact.',
      bn: 'ট্যাগ ও মূল কন্ডিশন অক্ষত থাকলে ৭ দিনের মধ্যে সহজ এক্সচেঞ্জ সুবিধা।'
    },
    reviews: [
      {
        id: 'rev-004-1',
        user: 'Tasnim Sultana',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-01',
        comment: {
          en: 'Pure premium silk indeed. It is very soft and lightweight, and the design looks extremely luxurious.',
          bn: 'সত্যিই চমৎকার প্রিমিয়াম সিল্ক। খুব নরম এবং ওজনে হালকা, কারুকাজটি দারুণ আভিজাত্যপূর্ণ।'
        }
      }
    ],
    questions: [
      {
        id: 'q-004-1',
        user: 'Fatima Farhana',
        question: { en: 'Is the color exactly as shown in photo?', bn: 'রং কি হুবহু ছবির মতোই হবে?' },
        answer: { en: 'Yes, we take professional photos in natural lighting to ensure 98% color accuracy.', bn: 'হ্যাঁ, ৯৮% কালার সঠিকতা নিশ্চিত করতে আমরা প্রাকৃতিক আলোতে পেশাদার ছবি তুলে থাকি।' },
        date: '2026-07-16'
      }
    ]
  },
  {
    id: 'prod-005',
    name: {
      en: 'AcousticPro active ANC Wireless Over-Ear Headphones',
      bn: 'অ্যাকোস্টিকপ্রো অ্যাক্টিভ নয়েজ ক্যানসেলিং হেডফোন'
    },
    brand: 'AcousticPro',
    price: 4500,
    originalPrice: 6500,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&q=80&w=600'
    ],
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sizes: ['Standard Adjustable'],
    colors: ['Carbon Gray', 'Snow White', 'Coral Orange'],
    category: 'electronics',
    rating: 4.85,
    reviewsCount: 112,
    stockStatus: 'in-stock',
    isNewArrival: true,
    isBestSeller: true,
    description: {
      en: 'Immerse yourself in premium studio sound with hybrid Active Noise Cancellation (ANC). Equipped with custom 40mm beryllium drivers, memory foam ear cups, and an ultra-long 60-hour playtime battery life.',
      bn: 'হাইব্রিড অ্যাক্টিভ নয়েজ ক্যান্সেলেশনের সাথে সুরের সাগরে হারিয়ে যান। ৪০ মিমি বেরিলিয়াম ড্রাইভার, মেমরি ফোম ইয়ারকাপ এবং একটানা ৬০ ঘণ্টা ব্যাকআপের দীর্ঘস্থায়ী ব্যাটারি সমৃদ্ধ।'
    },
    specifications: [
      { key: { en: 'ANC Depth', bn: 'নয়েজ ক্যান্সেলেশন গভীরতা' }, value: { en: 'Up to 35dB Hybrid ANC', bn: '৩৫ ডেসিবেল পর্যন্ত হাইব্রিড ANC' } },
      { key: { en: 'Battery Life', bn: 'ব্যাটারি লাইফ' }, value: { en: '60 Hours (ANC Off) / 45 Hours (ANC On)', bn: '৬০ ঘণ্টা (ANC বন্ধ) / ৪৫ ঘণ্টা (ANC চালু)' } },
      { key: { en: 'Bluetooth Version', bn: 'ব্লুটুথ সংস্করণ' }, value: { en: 'Bluetooth 5.3 Quick Connect', bn: 'ব্লুটুথ ৫.৩ কুইক কানেক্ট' } },
      { key: { en: 'Charging Time', bn: 'চার্জিং সময়' }, value: { en: '1.5 Hours Full Charge (USB-C)', bn: '১.৫ ঘণ্টা ফুল চার্জ (USB-C)' } }
    ],
    shippingInfo: {
      en: 'Packed in tough shock-resistant case. Shipped within 24 hours.',
      bn: 'শক-প্রতিরোধী কেসের ভেতর সুরক্ষিত প্যাকিং। ২৪ ঘণ্টার ভেতর কুরিয়ার করা হয়।'
    },
    returnPolicy: {
      en: '6-month official replacement warranty for internal hardware faults.',
      bn: 'অভ্যন্তরীণ হার্ডওয়্যার ত্রুটির জন্য ৬ মাসের অফিসিয়াল রিপ্লেসমেন্ট ওয়ারেন্টি।'
    },
    reviews: [
      {
        id: 'rev-005-1',
        user: 'Afridi Hasan',
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-06-20',
        comment: {
          en: 'Bargain of the year! Soundstage is incredibly wide, bass is punching, and ANC blocks out traffic completely.',
          bn: 'বছরের সেরা ডিল! সাউন্ডস্টেজ অবিশ্বাস্য রকম চমৎকার এবং নয়েজ ক্যান্সেলেশন খুব কার্যকর।'
        }
      }
    ],
    questions: [
      {
        id: 'q-005-1',
        user: 'Sadman Sakib',
        question: { en: 'Can it be used with audio cable too?', bn: 'এটি কি অডিও কেবল দিয়েও চালানো যাবে?' },
        answer: { en: 'Yes! It includes a 3.5mm AUX gold-plated audio cable in the package for wired lossless listening.', bn: 'হ্যাঁ! প্যাকেজের ভেতর ৩.৫ মিমি গোল্ড-প্লেটেড AUX অডিও কেবল রয়েছে।' },
        date: '2026-07-02'
      }
    ]
  },
  {
    id: 'prod-006',
    name: {
      en: 'Premium Suede Leather Men Punjabi',
      bn: 'প্রিমিয়াম সুয়েড লেদার মিক্সড কলার পুরুষদের পাঞ্জাবি'
    },
    brand: 'Trendify Fashion',
    price: 3450,
    originalPrice: 4800,
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1597983073492-bc24058bf2a0?auto=format&fit=crop&q=80&w=600'
    ],
    sizes: ['M (38)', 'L (40)', 'XL (42)', 'XXL (44)'],
    colors: ['Royal Blue', 'Classic White', 'Jet Black'],
    category: 'men',
    rating: 4.8,
    reviewsCount: 79,
    stockStatus: 'in-stock',
    isFlashSale: true,
    isFeatured: true,
    flashSaleEndTime: new Date(Date.now() + 86400000 * 1.5).toISOString(),
    description: {
      en: 'A perfect blending of classic heritage and contemporary elite style. Tailored with high-grade cotton-blend fibers and highlighted with micro-suede collar piping and modern metallic snap buttons.',
      bn: 'ঐতিহ্যবাহী পোশাকের সাথে আধুনিক এলিগ্যান্ট ডিজাইন। প্রিমিয়াম সুতি কাপড়ের বডি এবং কলার ও বোতাম প্লেটে সূক্ষ্ম সুয়েড ফিনিশিং পাঞ্জাবিটিকে অত্যন্ত নিখুঁত রূপ দিয়েছে।'
    },
    specifications: [
      { key: { en: 'Fabric', bn: 'কাপড়' }, value: { en: 'Premium Breathable Cotton-Silk Blend', bn: 'প্রিমিয়াম বাতাস চলাচলাকারী কটন-সিল্ক ব্লেন্ড' } },
      { key: { en: 'Fit Type', bn: 'ফিটিং' }, value: { en: 'Semi-Fit Modern Cut', bn: 'সেমি-ফিট আধুনিক কাট' } },
      { key: { en: 'Ornamentation', bn: 'ডিজাইন হাইলাইট' }, value: { en: 'Suede collar and custom metallic snaps', bn: 'সুয়েড কলার ও কাস্টম মেটালিক স্ন্যাপ বাটন' } }
    ],
    shippingInfo: {
      en: 'Standard delivery in secure shopping pouch.',
      bn: 'সুরক্ষিত শপিং ব্যাগে ডেলিভারি করা হয়।'
    },
    returnPolicy: {
      en: 'Exchange with different size accepted within 7 days of delivery.',
      bn: 'সাইজে সমস্যা হলে ডেলিভারির ৭ দিনের মধ্যে সাইজ এক্সচেঞ্জ গ্রহণযোগ্য।'
    },
    reviews: [
      {
        id: 'rev-006-1',
        user: 'Imran Chowdhury',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-12',
        comment: {
          en: 'Fit was absolutely perfect. The cotton fabric is extremely comfortable even in humid weather.',
          bn: 'ফিটিং একদম নিখুঁত হয়েছে। আর্দ্র আবহাওয়াতেও কাপড়ের আরাম চমৎকার।'
        }
      }
    ],
    questions: [
      {
        id: 'q-006-1',
        user: 'Saif Ahmed',
        question: { en: 'What is the length of size 42?', bn: '৪২ সাইজের ঝুল (লম্বা) কত ইঞ্চি?' },
        answer: { en: 'Size 42 has a standard length of 42 inches and chest circumference of 44 inches.', bn: '৪২ সাইজের লম্বা সাধারণত ৪২ ইঞ্চি এবং ছাতি ৪৪ ইঞ্চি।' },
        date: '2026-07-15'
      }
    ]
  },
  {
    id: 'prod-007',
    name: {
      en: 'MagSafe 10000mAh Ultra Slim Power Bank',
      bn: 'ম্যাগসেফ ১০,০০০ মিলিঅ্যাম্পিয়ার আল্ট্রা স্লিম পাওয়ার ব্যাংক'
    },
    brand: 'Trendify Accs',
    price: 1950,
    originalPrice: 2800,
    images: [
      'https://images.unsplash.com/photo-1609592424109-dd08ffcfc836?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=600'
    ],
    colors: ['Titanium Gray', 'Alpine Green'],
    category: 'mobile-accessories',
    rating: 4.68,
    reviewsCount: 42,
    stockStatus: 'in-stock',
    isBestSeller: true,
    description: {
      en: 'Snap-and-charge wirelessly. Featuring strong 15W MagSafe standard magnetic alignment for iPhone 12/13/14/15/16 series, along with a 22.5W USB-C PD fast charge port for wired Android phones.',
      bn: 'হাতে ধরে চার্জ দেওয়ার ঝামেলা শেষ। আইফোনের জন্য শক্তিশালী ১৫ ওয়াট ম্যাগসেফ ম্যাগনেটিক চার্জিং এবং অ্যান্ড্রয়েড ফোনের জন্য ২২.৫ ওয়াট টাইপ-সি ফাস্ট চার্জিং।'
    },
    specifications: [
      { key: { en: 'Battery Type', bn: 'ব্যাটারি উপাদান' }, value: { en: 'Lithium Polymer Core', bn: 'লিথিয়াম পলিমার কোর' } },
      { key: { en: 'Wireless Output', bn: 'ওয়্যারলেস আউটপুট' }, value: { en: '15W / 10W / 7.5W / 5W MagSafe', bn: '১৫ ওয়াট / ১০ ওয়াট / ৭.৫ ওয়াট / ৫ ওয়াট' } },
      { key: { en: 'Wired Output', bn: 'তারযুক্ত আউটপুট' }, value: { en: '22.5W Power Delivery USB-C', bn: '২২.৫ ওয়াট পাওয়ার ডেলিভারি USB-C' } }
    ],
    shippingInfo: {
      en: 'Safely dispatched nationwide. Flight-safe design compliant.',
      bn: 'সারাদেশে নিরাপদ ডেলিভারি। বিমানে বহনের উপযোগী নিরাপদ ডিজাইন।'
    },
    returnPolicy: {
      en: '3-month warranty against core battery drainage issues.',
      bn: 'ব্যাটারি ড্রেইনেজ ইস্যুর জন্য ৩ মাসের অফিসিয়াল ওয়ারেন্টি।'
    },
    reviews: [
      {
        id: 'rev-007-1',
        user: 'Siam Siddique',
        avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&q=80&w=100',
        rating: 5,
        date: '2026-07-08',
        comment: {
          en: 'The magnets are incredibly strong, doesn\'t slip off my iPhone at all. Charges fast.',
          bn: 'ম্যাগনেটগুলো খুব শক্তিশালী, আইফোন থেকে একদমই স্লিপ কাটে না। দ্রুত চার্জ হয়।'
        }
      }
    ],
    questions: [
      {
        id: 'q-007-1',
        user: 'Jamil Hossain',
        question: { en: 'Can it charge two devices at once?', bn: 'এটি কি একসাথে দুটি ডিভাইস চার্জ করতে পারে?' },
        answer: { en: 'Yes, you can charge one device wirelessly and another device simultaneously via the USB-C cable.', bn: 'হ্যাঁ, আপনি একই সাথে একটি ডিভাইস ওয়্যারলেস এবং আরেকটি টাইপ-সি ক্যাবলের মাধ্যমে চার্জ করতে পারবেন।' },
        date: '2026-07-12'
      }
    ]
  }
];

// Curated Categories List
export interface CategoryData {
  id: string;
  name: Translation;
  iconName: string; // Used to select Lucide icons
}

export const CATEGORIES_LIST: CategoryData[] = [
  { id: 'men', name: { en: 'Men\'s Fashion', bn: 'পুরুষদের ফ্যাশন' }, iconName: 'Shirt' },
  { id: 'women', name: { en: 'Women\'s Fashion', bn: 'নারীদের ফ্যাশন' }, iconName: 'Sparkles' },
  { id: 'watches', name: { en: 'Watches', bn: 'ঘড়ি' }, iconName: 'Watch' },
  { id: 'perfume', name: { en: 'Perfume', bn: 'পারফিউম' }, iconName: 'Flame' },
  { id: 'mobile-accessories', name: { en: 'Mobile Accessories', bn: 'মোবাইল এক্সেসরিজ' }, iconName: 'Smartphone' },
  { id: 'gift-items', name: { en: 'Gift Items & Agro', bn: 'উপহার ও কৃষি পণ্য' }, iconName: 'Gift' },
  { id: 'electronics', name: { en: 'Electronics', bn: 'ইলেকট্রনিক্স' }, iconName: 'Tv' }
];

// Sample Coupon Database
export interface Coupon {
  code: string;
  discountPercentage: number;
  minSpend: number;
}

export const COUPONS_DATABASE: Coupon[] = [
  { code: 'TRENDIFY10', discountPercentage: 10, minSpend: 500 },
  { code: 'SHERPUR50', discountPercentage: 15, minSpend: 1500 },
  { code: 'EIDBONUS', discountPercentage: 20, minSpend: 3000 }
];

// Default Addresses
export const DEFAULT_SAVED_ADDRESSES: SavedAddress[] = [
  {
    id: 'addr-001',
    label: 'Home (শেরপুর সদর)',
    receiverName: 'Md. Maruf Islam',
    phone: '01712345678',
    district: 'Sherpur',
    upazila: 'Sherpur Sadar',
    fullAddress: 'Holding 45, Nayanibazar, Sherpur Town'
  },
  {
    id: 'addr-002',
    label: 'Dhaka Office',
    receiverName: 'Md. Maruf Islam',
    phone: '01712345678',
    district: 'Dhaka',
    upazila: 'Gulshan',
    fullAddress: 'Road 12, Block C, Gulshan-2, Dhaka'
  }
];
